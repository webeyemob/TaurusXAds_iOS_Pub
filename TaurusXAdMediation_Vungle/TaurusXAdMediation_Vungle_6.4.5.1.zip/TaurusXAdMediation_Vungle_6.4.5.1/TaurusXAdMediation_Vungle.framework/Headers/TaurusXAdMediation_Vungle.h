//
//  TaurusXAdMediation_Vungle.h
//  TaurusXAdMediation_Vungle
//
//  Created by TaurusXAds on 2019/8/8.
//  Copyright © 2019 TXAD. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for TaurusXAdMediation_Vungle.
FOUNDATION_EXPORT double TaurusXAdMediation_VungleVersionNumber;

//! Project version string for TaurusXAdMediation_Vungle.
FOUNDATION_EXPORT const unsigned char TaurusXAdMediation_VungleVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TaurusXAdMediation_Vungle/PublicHeader.h>

#import <TaurusXAdMediation_Vungle/TXADVungleInFeedConfig.h>


