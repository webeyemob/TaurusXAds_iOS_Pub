//
//  RichOXFissionLite.h
//  RichOXFissionAdapter_Moblink
//
//  Created by RichOX on 2021/5/27.
//  Copyright © 2021 richox. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface RichOXFissionLite : NSObject

+ (void) start;

+ (void) bindInviter;

+ (void) setGetShareLinkBlock;

@end

NS_ASSUME_NONNULL_END
