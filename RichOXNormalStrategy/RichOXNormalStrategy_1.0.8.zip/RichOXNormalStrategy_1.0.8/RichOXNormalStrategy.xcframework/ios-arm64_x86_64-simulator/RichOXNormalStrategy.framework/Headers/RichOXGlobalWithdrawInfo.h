//
//  RichOXGlobalWithdrawInfo.h
//  RichOX
//
//  Created by RichOX on 2021/10/09.
//  Copyright © 2021 richox. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

/*
 海外现金提现参数，目前支持四种钱包类型的体现
 ** | 国家 ｜walletChannel|            account                    | name｜firstName|lastName|middleName|payRemark|extendedInfo｜
 ** -------------------------------------------------------------------------------------------------------------------------
 ** | 美国 ｜  @"PAYPAL"  | paypal账号                             |  Y  ｜    N    ｜   N   ｜  N      ｜   N    |     N       |
 ** | 印尼 ｜  @"DANA"    | DANA账号（钱包绑定的手机号,08开头9~14位数字）|  N  ｜    N    ｜   N   ｜  N      ｜   N    |     N       |
 ** | 印尼 ｜  @"OVO"     | OVO账号（钱包绑定的手机号,08开头9~14位数字） |  Y  ｜    N    ｜   N   ｜  N      ｜   N    |     N       |
 ** |菲律宾｜  @"GCASH"   | GCash账号（钱包绑定的手机号,09开头11位数字） |  N  ｜    Y    ｜   Y   ｜  Y      ｜   N     |    N       |
 */



@interface RichOXGlobalWithdrawInfo : NSObject

@property (nonatomic, strong, readonly) NSString * walletChannel; //钱包类型
@property (nonatomic, strong, readonly) NSString * account;  //用户收款账号

@property (nonatomic, strong) NSString *name; //用户姓名

@property (nonatomic, strong) NSString *firstName; //用户 first name
@property (nonatomic, strong) NSString *lastName;  //用户 last name
@property (nonatomic, strong) NSString *middleName; //用户 middle name


@property (nonatomic, strong) NSString *extendedInfo;      //电子钱包扩展参数，JSON格式字符串
@property (nonatomic, strong) NSString *payRemark;     //支付备注信息，英文字符

- (instancetype)initWithWalletChannel:(NSString *)walletChannel account:(NSString *)account;

@end

NS_ASSUME_NONNULL_END
