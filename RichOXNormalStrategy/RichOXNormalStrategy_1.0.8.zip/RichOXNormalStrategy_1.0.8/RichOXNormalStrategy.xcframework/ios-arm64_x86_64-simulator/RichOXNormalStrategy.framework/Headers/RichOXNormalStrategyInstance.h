//
//  RichOXNormalStrategy.h
//  RichOX
//
//  Created by RichOX on 2021/1/13.
//  Copyright © 2021 richox. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <RichOXBase/RichOXError.h>
#import <RichOXBase/RichOXWithdrawInfo.h>
#import "RichOXNormalStrategySetting.h"
#import <RichOXBase/RichOXReplenishInfo.h>
#import "RichOXNormalStrategyTypes.h"
#import "RichOXGlobalWithdrawInfo.h"

NS_ASSUME_NONNULL_BEGIN

typedef void (^RichOXGetNormalStrategySettingBlock)(RichOXNormalStrategySetting *setting);
typedef void (^RichOXGetNormalStrategyPrizeBlock)(RichOXNormalStrategyStatus *status);

typedef void (^RichOXNormalStrategyDoMissionBlock)(RichOXNormalStrategyTaskResult *result);
typedef void (^RichOXNormalStrategyAssetExchangeBlock)(RichOXNormalStrategyExchangeResult *result);

typedef void (^RichOXNormalStrategyWithdrawBlock)(RichOXNormalStrategyWithdrawResult *result);

typedef void (^RichOXGetTaskProcessInfoBlock)(RichOXNormalStrategyTaskProcessResult *result);

@interface RichOXNormalStrategyInstance:NSObject

@property (nonatomic) int strategyId;

+ (instancetype) getNormalStrategy:(int)strategyId;

/*!
@method syncList:failure
@abstract 此接口用于同步服务端阶梯红包的配置
@param success 成功的block，参数是用户当下的阶梯红包配置列表
@param failure 失败的block
*/
- (void)syncList:(RichOXGetNormalStrategySettingBlock)success failure:(RichOXFailureBlock)failure;

/*!
@method syncCurrentPrize:failure
@abstract 此接口用于获取阶梯红包用户当前的资产数
@param success 成功的block，参数是用户当下的阶梯红包配置列表
@param failure 失败的block
*/
- (void)syncCurrentPrize: (RichOXGetNormalStrategyPrizeBlock)success failure:(RichOXFailureBlock)failure;

/*!
@method doMission:prizeAmount:success:failure
@abstract 此接口用于领通用任务奖励值
@param taskId 任务id
@param prizeAmount 客户端指定的奖励数量,只有当该Task的prizeType为RICHOX_NR_PRIZE_TYPE_MAX时这个值才生效
@param tid 当该Task的prizeType为RICHOX_NR_PRIZE_TYPE_CUSTOMRULE 且 rewardType为RICHOX_NR_REWARD_TYPE_NEED_TID时需要传入此值
@param success 成功的block，参数是用户领取奖励之后的资产数
@param failure 失败的block
*/
- (void)doMission:(NSString *)taskId prizeAmount:(float)prizeAmount tid:(NSString * _Nullable)tid success:(RichOXNormalStrategyDoMissionBlock)success failure:(RichOXFailureBlock)failure;

/*!
@method doCustomMission:prizeAmount:success:failure
@abstract 此接口用于领通用分润任务奖励值
@param taskId 任务id
@param tid 当该Task的prizeType为RICHOX_NR_PRIZE_TYPE_CUSTOMRULE 且 rewardType为RICHOX_NR_REWARD_TYPE_NEED_TID时需要传入此值
@param extra s2s的参数打包(参考Android代码中Lineitem.getExtraData())
@param success 成功的block，参数是用户领取奖励之后的资产数
@param failure 失败的block
*/
- (void)doCustomMission:(NSString *)taskId tid:(NSString * _Nullable)tid extra:(NSString * _Nullable)extra success:(RichOXNormalStrategyDoMissionBlock)success failure:(RichOXFailureBlock)failure;

/*!
@method exchangeAsset:coin:success:failure
@abstract 此接口用于资产兑换
@param exchangeId 兑换码
@param coin 兑换金额，0表示全部兑换
@param success 成功的block，参数是用户资产兑换之后的result
@param failure 失败的block
*/
- (void)exchangeAsset:(NSString *)exchangeId coin:(float)coin success:(RichOXNormalStrategyAssetExchangeBlock)success failure:(RichOXFailureBlock)failure;


/*!
@method withdraw:success:failure
@abstract 此接口用于用户对已完成进度的通用红包进行提现操作，客户端根据提现方式传入相应的请求参数
@param packetId 提现任务ID
@param info 提现信息
@param success 成功的block，参数提现后的资产信息
@param failure 失败的block
*/
- (void)withdraw:(NSString *)packetId info:(RichOXWithdrawInfo *)info success:(RichOXNormalStrategyWithdrawBlock)success failure:(RichOXFailureBlock)failure;

/*!
@method globalWithdraw:success:failure
@abstract 此接口用于海外产品用户对已完成进度的通用红包进行提现操作，客户端根据提现方式传入相应的请求参数
@param packetId 提现任务ID
@param info 提现信息
@param success 成功的block，参数提现后的资产信息
@param failure 失败的block
*/
- (void)globalWithdraw:(NSString *)packetId info:(RichOXGlobalWithdrawInfo *)info success:(RichOXNormalStrategyWithdrawBlock)success failure:(RichOXFailureBlock)failure;

/*!
@method getTaskProcessInfo:success:failure
@abstract 此接口用于获取对当前用户任务完成进度查询
@param taskIds 任务ID列表，如果为nil则查询所有资产任务的进度
@param success 成功的block，参数是当前版本任务完成进度数组
@param failure 失败的block
*/
- (void)getTaskProcessInfo:(NSArray * _Nullable)taskIds success:(RichOXGetTaskProcessInfoBlock)success failure:(RichOXFailureBlock)failure;

/*!
@method replenish:info:success:failure
@abstract 此接口用于用户兑换话费类型的提现操作，客户端根据提现方式传入相应的请求参数
@param taskId 提现任务ID
@param info 兑换信息
@param success 成功的block，参数无
@param failure 失败的block
*/
- (void)replenish:(NSString *)taskId info:(RichOXReplenishInfo *)info success:(RichOXNormalStrategyWithdrawBlock)success failure:(RichOXFailureBlock)failure;

/*!
@method getSdkVersion
@abstract 获取SDK version
@return  SDK version string
*/
+ (NSString *)getSdkVersion;

// 引用 Unity 的 Client
@property(nonatomic, assign) RichOXNormalStrategyTypeClientRef _Nullable* _Nullable strategyClient;

@end

NS_ASSUME_NONNULL_END
