//
//  RichOXNormalStrategySetting.h
//  RichOXNormalStrategy
//
//  Created by zena.tang on 2021/2/5.
//  Copyright © 2021 richox. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RichOXNormalStrategyItem.h"

NS_ASSUME_NONNULL_BEGIN

@interface RichOXNormalStrategySetting : NSObject

@property (nonatomic, strong, readonly) NSString *strategyId;                              //策略ID
@property (nonatomic, strong, readonly) NSString *name;                                    //策略名字
@property (nonatomic, strong, readonly) NSString *payRemark;                               //支付说明
@property (nonatomic, strong, readonly) NSString *startTime;                               //开始时间
@property (nonatomic, strong, readonly) NSString *endTime;                                 //结束时间
@property (nonatomic, strong, readonly) RichOXNormalStrategyTaskInfo *taskInfo;            //策略任务信息
@property (nonatomic, strong, readonly) NSArray <RichOXNormalStrategyItem *>*withdrawSetting;                          //提现设置

- (instancetype) initWithData:(NSDictionary *)dic;

@end

NS_ASSUME_NONNULL_END
