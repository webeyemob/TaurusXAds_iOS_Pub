//
//  RichOXNormalStrategyItemR.h
//  RichOX
//
//  Created by RichOX on 2021/1/13.
//  Copyright © 2021 richox. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <RichOXBase/RichOXWithdrawData.h>

NS_ASSUME_NONNULL_BEGIN



typedef NS_ENUM(NSInteger, RICHOX_NR_WITHDRAW_TYPE) {
    RICHOX_NR_WITHDRAW_TYPE_NORMAL                              = 0,  //普通
    RICHOX_NR_WITHDRAW_TYPE_WX                                  = 1  //微信极速提现
};

typedef NS_ENUM(NSInteger, RICHOX_NR_FREQUENCY_TYPE) {
    RICHOX_NR_FREQUENCY_TYPE_DAILY                              = 1,  //每日
    RICHOX_NR_FREQUENCY_TYPE_WEEKLY                             = 2,  //每周
    RICHOX_NR_FREQUENCY_TYPE_ALWAYS                             = 3,  //全程
    RICHOX_NR_FREQUENCY_TYPE_NOLIMIT                            = 4   //无限制
};

typedef NS_ENUM(NSInteger, RICHOX_NR_PRIZE_TYPE) {
    RICHOX_NR_PRIZE_TYPE_FIX                                    = 1,  //固定值
    RICHOX_NR_PRIZE_TYPE_MAX                                    = 2,  //指定最大值
};

typedef NS_ENUM(NSInteger, RICHOX_NR_WITHDRAW_AMOUNT_TYPE) {
    RICHOX_NR_WITHDRAW_AMOUNT_TYPE_CASH                         = 1,  //现金
    RICHOX_NR_WITHDRAW_AMOUNT_TYPE_PHONEBILL                    = 2   //话费
};

@interface RichOXNormalStrategyTask : NSObject

@property (nonatomic, strong, readonly) NSString *taskId;                              //任务ID
@property (nonatomic, strong, readonly) NSString *name;                                //任务名字
@property (nonatomic, readonly) int frequency;                                         //频率值
@property (nonatomic, readonly) RICHOX_NR_FREQUENCY_TYPE frequencyType;              //频率类型
@property (nonatomic, readonly) float prizeAmount;                                       //任务完成获取的奖励值
@property (nonatomic, readonly) RICHOX_NR_PRIZE_TYPE prizeType;             //奖励值类型

- (instancetype) initWithData:(NSDictionary *)dic;

@end

@interface RichOXNormalStrategyAssetInfo : NSObject

@property (nonatomic, strong, readonly) NSString *name;                                //资产名字
@property (nonatomic, readonly) float exchangeRate; //如果资产不能兑换，则不返回该字段。

- (instancetype) initWithData:(NSDictionary *)dic;

@end

//兑换关系
@interface RichOXNormalStrategyAssetExchangeInfo : NSObject

@property (nonatomic, strong, readonly) NSString *exchangeId;                                //兑换码
@property (nonatomic, strong, readonly) NSString *fromAssetName;                                //兑换前资产名
@property (nonatomic, readonly) float fromPrizeAmount;  //兑换需要的资产数

@property (nonatomic, strong, readonly) NSString *toAssetName;                                //兑换后资产名
@property (nonatomic, readonly) float toPrizeAmount; //兑换的资产数

- (instancetype) initWithData:(NSDictionary *)dic;

@end

@interface RichOXNormalStrategyTaskInfo : NSObject

@property (nonatomic, strong, readonly) NSArray <RichOXNormalStrategyAssetInfo *> *assetInfos;                                //资产数组

@property (nonatomic, strong, readonly) NSArray <RichOXNormalStrategyAssetExchangeInfo *> *exchangeInfos;                                //兑换关系数组
                                
@property (nonatomic, strong, readonly) NSArray <RichOXNormalStrategyTask *> *tasks;   //任务列表

- (instancetype) initWithData:(NSDictionary *)dic;

@end


@interface RichOXNormalStrategyItem : NSObject

@property (nonatomic) int seq;                                        //获取列表序列，从1开始
@property (nonatomic, strong, readonly) NSString *packageId;          //红包项Id
@property (nonatomic) double amount;                                  //提现数值
@property (nonatomic, readonly) int frequency;                        //提现频率值
@property (nonatomic, readonly) RICHOX_NR_FREQUENCY_TYPE frequencyType; //提现频率类型

@property (nonatomic, readonly) RICHOX_NR_WITHDRAW_TYPE withdrawType;       //提现类型

@property (nonatomic, strong, readonly) NSString *assetName;            //消耗资产名
@property (nonatomic) float costAsset;                                    //消耗资产数量

//@property (nonatomic) RICHOX_NR_WITHDRAW_STATUS withdrawStatus;   //提现状态

@property (nonatomic, readonly) RICHOX_NR_WITHDRAW_AMOUNT_TYPE amountType;       //提现类型
@property (nonatomic, strong, readonly) NSString *currency;       //货币单位

- (instancetype) initWithData:(NSDictionary *)dic;

@end


@interface RichOXNSWithdrawRecordData : RichOXWithdrawRecordData

@property (nonatomic, strong, readonly) NSString *taskId;

- (instancetype) initWithWithdrawRecord:(NSDictionary *)dic;

@end

@interface RichOXNormalStrategyAssetStatus : NSObject

@property (nonatomic, strong, readonly) NSString *name;                                //资产名字
@property (nonatomic) float amount; //资产值。

- (instancetype) initWithData:(NSDictionary *)dic;

@end

@interface RichOXNormalStrategyStatus : NSObject

@property (nonatomic, readonly) int strategyId;
@property (nonatomic, readonly) int abId;
@property (nonatomic, strong, readonly) NSString *abGroup;

@property (nonatomic, strong, readonly) NSArray <RichOXNormalStrategyAssetStatus *>*assetInfos;          //资产信息

@property (nonatomic, strong, readonly) NSArray <RichOXNSWithdrawRecordData *>*withdrawRecord;          //提现记录列表

- (instancetype) initWithData:(NSDictionary *)dic;

@end



@interface RichOXNormalStrategyTaskResult : NSObject

@property (nonatomic, strong, readonly) NSString *assetName; //完成任务后变化的资产名称

@property (nonatomic, readonly) float deltaPrizeValue;  //完成任务后变化的资产值
@property (nonatomic, readonly) float totalPrizeValue;  //完成任务后总的资产值

@property (nonatomic, strong, readonly) NSArray <RichOXNormalStrategyAssetStatus *>*assetStatus;          //资产状态

- (instancetype) initWithData:(NSDictionary *)dic;

@end

@interface RichOXNormalStrategyExchangeResult : NSObject

@property (nonatomic, strong, readonly) NSString *fromAssetName; //兑换的资产名

@property (nonatomic, readonly) float fromAssetDeltaPrizeValue;  //兑换后变化的资产值
@property (nonatomic, readonly) float fromAssetTotalPrizeValue;  //兑换后总的资产值

@property (nonatomic, strong, readonly) NSString *toAssetName; //兑换后资产名

@property (nonatomic, readonly) float toAssetDeltaPrizeValue;  //兑换后变化的资产值
@property (nonatomic, readonly) float toAssetTotalPrizeValue;  //兑换后总的资产值

@property (nonatomic, strong, readonly) NSArray <RichOXNormalStrategyAssetStatus *>*assetStatus;          //资产状态

- (instancetype) initWithData:(NSDictionary *)dic;

@end

@interface RichOXNormalStrategyWithdrawResult : NSObject

@property (nonatomic, strong, readonly) NSArray <RichOXNormalStrategyAssetStatus *>*assetStatus;          //资产状态

- (instancetype) initWithData:(NSDictionary *)dic;

@end

@interface RichOXNormalStrategyTaskProcess : RichOXNormalStrategyTask

@property (nonatomic, readonly) int updateTimes;          //用户做任务的次数 （和频度类型有关。 如果是x次/每天，则为当天做任务的次数;如果是 x次/每周，则为当周做任务的次数;否则为全程做任务的次数）
@property (nonatomic, readonly) long long lastUpdateTime;      //用户上次做任务的时间戳（ms）


- (instancetype) initWithData:(NSDictionary *)dic;

@end

@interface RichOXNormalStrategyTaskProcessResult : NSObject

@property (nonatomic, strong, readonly) NSString *uid;          //用户ID
@property (nonatomic, strong, readonly) NSArray <RichOXNormalStrategyTaskProcess *> *taskProcesses;


- (instancetype) initWithData:(NSDictionary *)dic;

@end

NS_ASSUME_NONNULL_END
