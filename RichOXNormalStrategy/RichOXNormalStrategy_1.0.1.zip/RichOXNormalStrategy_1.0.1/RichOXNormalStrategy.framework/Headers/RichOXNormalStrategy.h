//
//  RichOXNormalStrategy.h
//  RichOXNormalStrategy
//
//  Created by zena.tang on 2021/2/18.
//  Copyright © 2021 richox. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for RichOXNormalStrategy.
FOUNDATION_EXPORT double RichOXNormalStrategyVersionNumber;

//! Project version string for RichOXNormalStrategy.
FOUNDATION_EXPORT const unsigned char RichOXNormalStrategyVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <RichOXNormalStrategy/PublicHeader.h>

#import <RichOXNormalStrategy/RichOXNormalStrategyInstance.h>
#import <RichOXNormalStrategy/RichOXNormalStrategyItem.h>
#import <RichOXNormalStrategy/RichOXNormalStrategySetting.h>
