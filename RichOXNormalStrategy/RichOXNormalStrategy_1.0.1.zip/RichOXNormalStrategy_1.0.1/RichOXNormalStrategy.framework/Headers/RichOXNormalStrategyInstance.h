//
//  RichOXNormalStrategy.h
//  RichOX
//
//  Created by zena.tang on 2021/1/13.
//  Copyright © 2021 richox. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <RichOXBase/RichOXError.h>
#import <RichOXBase/RichOXWithdrawInfo.h>
#import "RichOXNormalStrategySetting.h"

NS_ASSUME_NONNULL_BEGIN

typedef void (^RichOXGetNormalStrategySettingBlock)(RichOXNormalStrategySetting *setting);
typedef void (^RichOXGetNormalStrategyPrizeBlock)(RichOXNormalStrategyStatus *status);

typedef void (^RichOXNormalStrategyDoMissionBlock)(RichOXNormalStrategyTaskResult *result);
typedef void (^RichOXNormalStrategyAssetExchangeBlock)(RichOXNormalStrategyExchangeResult *result);

typedef void (^RichOXNormalStrategyWithdrawBlock)(RichOXNormalStrategyWithdrawResult *result);

@interface RichOXNormalStrategyInstance:NSObject

@property (nonatomic, strong) NSString *strategyId;

+ (instancetype) getNormalStrategy:(NSString *)strategyId;

/*!
@method syncList:failure
@abstract 此接口用于同步服务端阶梯红包的配置
@param success 成功的block，参数是用户当下的阶梯红包配置列表
@param failure 失败的block
*/
- (void)syncList:(RichOXGetNormalStrategySettingBlock)success failure:(RichOXFailureBlock)failure;

/*!
@method syncCurrentPrize:failure
@abstract 此接口用于获取阶梯红包用户当前的资产数
@param success 成功的block，参数是用户当下的阶梯红包配置列表
@param failure 失败的block
*/
- (void)syncCurrentPrize: (RichOXGetNormalStrategyPrizeBlock)success failure:(RichOXFailureBlock)failure;

/*!
@method doMission:prizeAmount:success:failure
@abstract 此接口用于领通用任务奖励值
@param taskId 任务id
@param prizeAmount 客户端指定的奖励数量,如果任务是固定奖励可以设置为0
@param success 成功的block，参数是用户领取奖励之后的资产数
@param failure 失败的block
*/
- (void)doMission:(NSString *)taskId prizeAmount:(float)prizeAmount success:(RichOXNormalStrategyDoMissionBlock)success failure:(RichOXFailureBlock)failure;

/*!
@method exchangeAsset:coin:success:failure
@abstract 此接口用于资产兑换
@param exchangeId 兑换码
@param coin 兑换金额，0表示全部兑换
@param success 成功的block，参数是用户资产兑换之后的result
@param failure 失败的block
*/
- (void)exchangeAsset:(NSString *)exchangeId coin:(float)coin success:(RichOXNormalStrategyAssetExchangeBlock)success failure:(RichOXFailureBlock)failure;


/*!
@method withdraw:success:failure
@abstract 此接口用于用户对已完成进度的通用红包进行提现操作，客户端根据提现方式传入相应的请求参数
@param packetId 提现任务ID
@param info 提现信息
@param success 成功的block，参数提现后的资产信息
@param failure 失败的block
*/
- (void)withdraw:(NSString *)packetId info:(RichOXWithdrawInfo *)info success:(RichOXNormalStrategyWithdrawBlock)success failure:(RichOXFailureBlock)failure;


@end

NS_ASSUME_NONNULL_END
