//
//  RichOXNormalStrategyTypes.h
//  RichOXNormalStrategy
//
//  Created by RichOX on 2021/6/28.
//  Copyright © 2020 RichOX. All rights reserved.
//

/// Common
typedef const void *RichOXNormalStrategyTypeRef;

typedef const void *RichOXNormalStrategyTypeDictionaryRef;

/// RichOXNormalStrategy
typedef const void *RichOXNormalStrategyTypeClientRef;

//RichOXNormalStrategySetting
typedef const void *RichOXNormalStrategyTypeSettingRef;

//RichOXNormalStrategyStatus
typedef const void *RichOXNormalStrategyTypeStatusRef;

//RichOXNormalStrategyTaskResult
typedef const void *RichOXNormalStrategyTypeTaskResultRef;

//RichOXNormalStrategyExchangeResult
typedef const void *RichOXNormalStrategyTypeExchangeResultRef;

//RichOXNormalStrategyWithdrawResult
typedef const void *RichOXNormalStrategyTypeWithdrawResultRef;

//RichOXNormalStrategyTaskProcessResult
typedef const void *RichOXNormalStrategyTypeTaskProcessResultRef;

// RichOXGetNormalStrategySettingBlock callback
typedef void (*RichOXGetNormalStrategyFailedCallback)(RichOXNormalStrategyTypeClientRef *clientRef, int code, char *message);

// RichOXGetNormalStrategySettingBlock callback
typedef void (*RichOXGetNormalStrategySettingCallback)(RichOXNormalStrategyTypeClientRef *clientRef, RichOXNormalStrategyTypeSettingRef settingRef);

// RichOXGetNormalStrategyPrizeBlock callback
typedef void (*RichOXGetNormalStrategySyncPrizeCallback)(RichOXNormalStrategyTypeClientRef *clientRef, RichOXNormalStrategyTypeStatusRef statusRef);

// RichOXNormalStrategyDoMissionBlock callback
typedef void (*RichOXGetNormalStrategyDoMissionCallback)(RichOXNormalStrategyTypeClientRef *clientRef, RichOXNormalStrategyTypeTaskResultRef resultRef);

// RichOXNormalStrategyAssetExchangeBlock callback
typedef void (*RichOXGetNormalStrategyAssetExchangeCallback)(RichOXNormalStrategyTypeClientRef *clientRef, RichOXNormalStrategyTypeExchangeResultRef resultRef);

// RichOXNormalStrategyWithdrawBlock callback
typedef void (*RichOXGetNormalStrategyWithdrawCallback)(RichOXNormalStrategyTypeClientRef *clientRef, RichOXNormalStrategyTypeWithdrawResultRef resultRef);

// RichOXGetTaskProcessInfoBlock callback
typedef void (*RichOXGetNormalStrategyGetTaskProcessInfoCallback)(RichOXNormalStrategyTypeClientRef *clientRef, RichOXNormalStrategyTypeTaskProcessResultRef resultRef);

//RichOXNormalStrategyTaskInfo
typedef const void *RichOXNormalStrategyTypeTaskInfoRef;

//RichOXNormalStrategyAssetInfo
typedef const void *RichOXNormalStrategyTypeAssetInfoRef;

//RichOXNormalStrategyAssetInfo NSArray
typedef const void *RichOXNormalStrategyTypeAssetInfoArrayRef;

//RichOXNormalStrategyAssetExchangeInfo
typedef const void *RichOXNormalStrategyTypeAssetExchangeInfoRef;

//RichOXNormalStrategyAssetExchangeInfo NSArray
typedef const void *RichOXNormalStrategyTypeAssetExchangeInfoArrayRef;

//RichOXNormalStrategyTask
typedef const void *RichOXNormalStrategyTypeTaskRef;

//RichOXNormalStrategyTask NSArray
typedef const void *RichOXNormalStrategyTypeTaskArrayRef;


//RichOXNormalStrategyItem
typedef const void *RichOXNormalStrategyTypeItemRef;

//RichOXNormalStrategyItem NSArray
typedef const void *RichOXNormalStrategyTypeItemArrayRef;

//RichOXNormalStrategyAssetStatus
typedef const void *RichOXNormalStrategyTypeAssetStatusRef;

//RichOXNormalStrategyAssetStatus NSArray
typedef const void *RichOXNormalStrategyTypeAssetStatusArrayRef;

//RichOXNSWithdrawRecordData
typedef const void *RichOXNormalStrategyTypeWithdrawRecordDataRef;

//RichOXNSWithdrawRecordData NSArry
typedef const void *RichOXNormalStrategyTypeWithdrawRecordDataArrayRef;

//RichOXNormalStrategyTaskProcess 继承自RichOXNormalStrategyTypeTaskRef
typedef const void *RichOXNormalStrategyTypeTaskProcessRef;

//RichOXNormalStrategyTaskProcess NSArray
typedef const void *RichOXNormalStrategyTypeTaskProcessArrayRef;
