//
//  RichOXNormalStrategySetting.h
//  RichOXNormalStrategy
//
//  Created by zena.tang on 2021/2/5.
//  Copyright © 2021 richox. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RichOXNormalStrategyItem.h"

NS_ASSUME_NONNULL_BEGIN

@interface RichOXNormalStrategySetting : NSObject

@property (nonatomic, strong, readonly) NSString *strategyId;                              //策略ID
@property (nonatomic, strong, readonly) NSString *strategyVer;                             //策略版本
@property (nonatomic, strong, readonly) NSString *name;                                    //策略名字
@property (nonatomic, strong, readonly) NSString *payRemark;                               //支付说明
@property (nonatomic, strong, readonly) NSString *startTime;                               //开始时间
@property (nonatomic, strong, readonly) NSString *endTime;                                 //结束时间
@property (nonatomic) BOOL isIndefinite;                                                   //是否是无限期任务
@property (nonatomic, readonly) int abId;                                 //（可选）该策略归属的ab测试id,用于客户端打点
@property (nonatomic, strong, readonly) NSString *abGroup;                                 //（可选）流量组
@property (nonatomic, strong, readonly) RichOXNormalStrategyTaskInfo *taskInfo;            //策略任务信息
@property (nonatomic, strong, readonly) NSArray <RichOXNormalStrategyItem *>*withdrawSetting;                          //提现设置

- (instancetype) initWithData:(NSDictionary *)dic;

@end

NS_ASSUME_NONNULL_END
