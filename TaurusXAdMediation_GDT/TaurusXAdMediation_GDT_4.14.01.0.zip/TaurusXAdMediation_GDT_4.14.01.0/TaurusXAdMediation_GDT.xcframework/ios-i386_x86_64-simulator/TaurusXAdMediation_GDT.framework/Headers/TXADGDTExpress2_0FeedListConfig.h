//
//  TXADGDTExpress2_0FeedListConfig.h
//  TaurusXAdMediation_GDT
//
//  Created by TaurusXAds on 2020/7/22.
//  Copyright © 2019年 TaurusXAds. All rights reserved.
//

#import <TaurusXAds/TaurusXAds.h>
@class GDTVideoConfig;

@interface TXADGDTExpress2_0FeedListConfig : TXADNetworkConfig

@property (nonatomic, strong) GDTVideoConfig *videoConfig;
@property (nonatomic) NSInteger minVideoDuration;
@property (nonatomic) NSInteger maxVideoDuration;

@end
