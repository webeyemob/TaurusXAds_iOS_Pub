//
//  TXADGDTRewardedVideoConfig.h
//  TaurusXAdMediation_GDT
//
//  Created by 王航 on 2020/1/2.
//  Copyright © 2020年 TaurusXAds. All rights reserved.
//

#import <TaurusXAds/TaurusXAds.h>

@interface TXADGDTRewardedVideoConfig : TXADNetworkConfig

// 设置激励视频是否静音，默认 NO
@property (nonatomic) BOOL videoMuted;

@end
