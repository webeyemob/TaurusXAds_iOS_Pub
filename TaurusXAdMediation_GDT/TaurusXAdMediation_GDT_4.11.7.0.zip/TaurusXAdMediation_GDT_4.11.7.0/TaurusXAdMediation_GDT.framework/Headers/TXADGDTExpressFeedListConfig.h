//
//  TXADGDTExpressFeedListConfig.h
//  TaurusXAdMediation_GDT
//
//  Created by TaurusXAds on 2019/10/9.
//  Copyright © 2019年 TaurusXAds. All rights reserved.
//

#import <TaurusXAds/TaurusXAds.h>
@class GDTVideoConfig;

@interface TXADGDTExpressFeedListConfig : TXADNetworkConfig

@property (nonatomic) CGSize adSize DEPRECATED_MSG_ATTRIBUTE("Use [TXADFeedList setExpressAdSize:]");

@property (nonatomic, strong) GDTVideoConfig *videoConfig;
@property (nonatomic) NSInteger minVideoDuration;
@property (nonatomic) NSInteger maxVideoDuration;

@end
