//
//  TXADGDTExpress2_0InterstitialConfig.h
//  TaurusXAdMediation_GDT
//
//  Created by TaurusXAds on 2021/5/10.
//  Copyright © 2021 TaurusXAds. All rights reserved.
//

#import <TaurusXAds/TaurusXAds.h>
@class GDTVideoConfig;

NS_ASSUME_NONNULL_BEGIN

@interface TXADGDTExpress2_0InterstitialConfig : TXADNetworkConfig

@property (nonatomic, strong) GDTVideoConfig *videoConfig;
@property (nonatomic) NSInteger minVideoDuration;
@property (nonatomic) NSInteger maxVideoDuration;


@end

NS_ASSUME_NONNULL_END
