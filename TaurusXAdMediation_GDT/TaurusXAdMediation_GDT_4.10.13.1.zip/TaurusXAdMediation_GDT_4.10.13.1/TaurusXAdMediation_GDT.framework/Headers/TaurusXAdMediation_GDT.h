//
//  TaurusXAdMediation_GDT.h
//  TaurusXAdMediation_GDT
//
//  Created by Matthew on 2019/8/2.
//  Copyright © 2019年 TXAD. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for TaurusXAdMediation_GDT.
FOUNDATION_EXPORT double TaurusXAdMediation_GDTVersionNumber;

//! Project version string for TaurusXAdMediation_GDT.
FOUNDATION_EXPORT const unsigned char TaurusXAdMediation_GDTVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TaurusXAdMediation_GDT/PublicHeader.h>


#import <TaurusXAdMediation_GDT/TXADGDTExpressFeedListConfig.h>
#import <TaurusXAdMediation_GDT/TXADGDTExpressNativeConfig.h>
#import <TaurusXAdMediation_GDT/TXADGDTSplashConfig.h>
