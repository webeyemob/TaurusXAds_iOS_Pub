//
//  TXADMediation_GDT.h
//  TXADMediation_GDT
//
//  Created by Matthew on 2019/8/2.
//  Copyright © 2019年 TXAD. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for TXADMediation_GDT.
FOUNDATION_EXPORT double TXADMediation_GDTVersionNumber;

//! Project version string for TXADMediation_GDT.
FOUNDATION_EXPORT const unsigned char TXADMediation_GDTVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TXADMediation_GDT/PublicHeader.h>


#import <TXADMediation_GDT/TXADGDTExpressFeedListConfig.h>
#import <TXADMediation_GDT/TXADGDTExpressNativeConfig.h>
#import <TXADMediation_GDT/TXADGDTSplashConfig.h>
