//
//  TXADGDTRewardedVideoConfig.h
//  TaurusXAdMediation_GDT
//
//  Created by TaurusXAds on 2020/1/2.
//  Copyright © 2020年 TaurusXAds. All rights reserved.
//

#import <TaurusXAds/TaurusXAds.h>

@interface TXADGDTRewardedVideoConfig : TXADNetworkConfig

@end
