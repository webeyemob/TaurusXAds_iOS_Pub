//
//  TXADGDTSplashConfig.h
//  TaurusXAdMediation_GDT
//
//  Created by TaurusXAds on 2019/10/9.
//  Copyright © 2019年 TaurusXAds. All rights reserved.
//

#import <TaurusXAds/TaurusXAds.h>

@interface TXADGDTSplashConfig : TXADNetworkConfig

-(void)setBottomView:(UIView *)bottomView;
-(UIView *)getBottomView;

@end
