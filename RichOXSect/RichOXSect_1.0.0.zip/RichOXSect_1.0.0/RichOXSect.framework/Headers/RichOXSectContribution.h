//
//  RichOXSectContribution.h
//  RichOXSect
//
//  Created by zena.tang on 2021/1/28.
//  Copyright © 2021 richox. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RichOXSectData.h"
#import <RichOXBase/RichOXError.h>

NS_ASSUME_NONNULL_BEGIN

//贡献值
typedef void (^RichOXSectGenContributionSuccessBlock)(int contribution);
typedef void (^RichOXSectGetContributionSuccessBlock)(int contribution, int deltaContribution); //star: 领取后当前宗门贡献值, deltaContribution:本次领取的贡献值
typedef void (^RichOXSectGetContributionDayRecordSuccessBlock)(NSDictionary *record);

//现金兑换
typedef void (^RichOXSectGetTransTimesPacketSuccessBlock)(RichOXSectTransformTimesPacket *packet);
typedef void (^RichOXSectGetRedPacketRecordSuccessBlock)(RichOXSectRedPacketRecord *record);
typedef void (^RichOXSectTransformSuccessBlock)(RichOXSectTransformResult *result);


@interface RichOXSectContribution : NSObject

/*!
@method genContribution:success:failure
@abstract 此接口用于通过上报某种动作产生贡献值(未领取状态，目前仅有观看视频广告)
@param actionId 动作id, 0-观看视频
@param success 成功的block，参数是贡献值
@param failure 失败的block，返回失败的原因
*/
+ (void)genContribution:(int)actionId success:(RichOXSectGenContributionSuccessBlock)success failure:(RichOXFailureBlock)failure;

/*!
@method getContribution:studentUid:success:failure
@abstract 此接口用于领取贡献值
@param masterUid 宗主uid
@param apprenticeUid 指定弟子(包括自己)的uid, 不填则为一键领取
@param success 成功的block，参数是领取后当前宗门贡献值和本次领取的贡献值
@param failure 失败的block，返回失败的原因
*/
+ (void)getContribution:(NSString *)masterUid apprenticeUid:(NSString * _Nullable)apprenticeUid success:(RichOXSectGetContributionSuccessBlock)success failure:(RichOXFailureBlock)failure;

/*!
@method getContributionDayRecord:year:month:success:failure
@abstract 此接口用于获取贡献记录(按月)
@param year 年 *2021
@param month 月 *1
@param success 成功的block，参数是: key为日期，value为内容的字典，比如  {"2020-08-11": {"total": 123,"0": 10,"1": 100,"2": 13}}
@param failure 失败的block，返回失败的原因
*/
+ (void)getContributionDayRecord:(int)year month: (int)month success: (RichOXSectGetContributionDayRecordSuccessBlock)success failure:(RichOXFailureBlock)failure;

/*!
@method getTransformTimesPacket:success:failure
@abstract 此接口用于领取完成现金兑换次数红包
@param count 第几个红包，从1开始
@param success 成功的block，参数是:RichOXSectTransformTimesPacket
@param failure 失败的block，返回失败的原因
*/
+ (void)getTransformTimesPacket:(int)count success:(RichOXSectGetTransTimesPacketSuccessBlock)success failure:(RichOXFailureBlock)failure;

/*!
@method getRedPacketRecord:curPage:success:failure
@abstract 此接口用于获取红包记录
@param pageSize 每页大小，0表示使用默认50，最大200
@param curPage 当前页，默认0
@param success 成功的block，参数是:RichOXSectTransformResult
@param failure 失败的block，返回失败的原因
*/
+ (void)getRedPacketRecord:(int)pageSize curPage:(int)curPage success:(RichOXSectGetRedPacketRecordSuccessBlock)success failure:(RichOXFailureBlock)failure;

/*!
@method transform:failure
@abstract 此接口用于进行现金兑换
@param success 成功的block，参数是:RichOXSectTransformResult
@param failure 失败的block，返回失败的原因
*/
+ (void)transform:(RichOXSectTransformSuccessBlock)success failure:(RichOXFailureBlock)failure;

@end

NS_ASSUME_NONNULL_END
