//
//  RichOXSectMission.h
//  RichOXSect
//
//  Created by zena.tang on 2021/1/28.
//  Copyright © 2021 richox. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RichOXSectData.h"
#import <RichOXBase/RichOXError.h>
#import <RichOXBase/RichOXMissionData.h>


NS_ASSUME_NONNULL_BEGIN

typedef void (^RichOXSectGetMissionSuccessBlock)(NSArray <RichOXMissionData *> *data);
typedef void (^RichOXSectMissionSubmitSuccessBlock)(RichOXSectMissionSubmitResult *result);
typedef void (^RichOXSectQueryMissionSuccessBlock)(RichOXSectQueryMissionResult *result);

@interface RichOXSectMission : NSObject

/*!
@method getSectMission:failure
@abstract 此接口用于获取宗门配置的任务信息
@param success 成功的block，参数是:RichOXMissionData 数组
@param failure 失败的block，返回失败的原因
*/
+ (void)getSectMission:(RichOXSectGetMissionSuccessBlock)success failure:(RichOXFailureBlock)failure;

/*!
@method submitSectMission:missionId:bonus:success:failure
@abstract 此接口用于宗门用户完成宗门任务后领取相应的奖励
@param missionId 宗门任务id
@param bonus 客户端指定的奖励数量(仅对支持客户端控制的任务有效)
@param success 成功的block，参数是:RichOXSectMissionSubmitResult
@param failure 失败的block，返回失败的原因
*/
+ (void)submitSectMission:(NSString *)missionId bouns:(float)bonus success:(RichOXSectMissionSubmitSuccessBlock)success failure:(RichOXFailureBlock)failure;

/*!
@method quaryMission:missionId:days:pageSize:pageIndex:success:failure
@abstract 此接口用于查询指定天数内的特定类型宗门任务记录，返回按任务完成时间倒序排列，比如查询7天内的签到记录
@param missionId 宗门任务id，不填返回全部任务记录
@param days  天数，1表示查当天
@param pageSize 每页数量，0表示使用默认30
@param pageIndex 页码，从1开始，0表示使用默认1
@param success 成功的block，参数是:RichOXMissionData 数组
@param failure 失败的block，返回失败的原因
*/
+ (void)quaryMission:(NSString * _Nullable)missionId days:(int)days pageSize:(int)pageSize pageIndex:(int)pageIndex success:(RichOXSectQueryMissionSuccessBlock)success failure:(RichOXFailureBlock)failure;

@end

NS_ASSUME_NONNULL_END
