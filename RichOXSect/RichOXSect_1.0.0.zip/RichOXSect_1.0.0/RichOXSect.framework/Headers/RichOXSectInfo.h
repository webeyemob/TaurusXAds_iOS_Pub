//
//  RichOXSect.h
//  RichOX
//
//  Created by zena.tang on 2021/1/14.
//  Copyright © 2021 richox. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RichOXSectData.h"
#import <RichOXBase/RichOXError.h>
#import "RichOXBase/RichOXMissionData.h"

NS_ASSUME_NONNULL_BEGIN


typedef void (^RichOXSectGetSectInfoSuccessBlock)(RichOXSectData *data);
typedef void (^RichOXSectGetApprenticeListSuccessBlock)(RichOXSectApprenticeList *data);
typedef void (^RichOXSectGetApprenticeInfoSuccessBlock)(RichOXSectApprenticeInfo *data);

typedef void (^RichOXSectGetSettingSuccessBlock)(RichOXSectSettingData *data);


@interface RichOXSectInfo : NSObject

/*!
@method getSectInfo:failure
@abstract 此接口用于获取当前用户的宗门信息
@param success 成功的block，参数是RichOXSectData
@param failure 失败的block，返回失败的原因
*/
+ (void)getSectInfo:(RichOXSectGetSectInfoSuccessBlock)success failure:(RichOXFailureBlock)failure;

/*!
@method getApprenticeList:pageSize:currentPage:success:failure
@abstract 此接口用于分页获取某级弟子的信息
@param level 弟子级数 ，1为掌门弟子
@param pageSize 每页大小，0表示使用默认的50，最大200
@param currentPage 当前页，默认0
@param success 成功的block，参数是RichOXSectApprenticeListLevel
@param failure 失败的block，返回失败的原因
*/
+ (void)getApprenticeList:(int)level pageSize:(int)pageSize currentPage:(int)currentPage success:(RichOXSectGetApprenticeListSuccessBlock)success failure:(RichOXFailureBlock)failure;

/*!
@method getApprenticeInfo:success:failure
@abstract 此接口用于获取某个弟子的详细信息
@param apprenticeUid 弟子uid
@param success 成功的block，参数是RichOXSectApprenticeInfo
@param failure 失败的block，返回失败的原因
*/
+ (void)getApprenticeInfo:(NSString *)apprenticeUid success:(RichOXSectGetApprenticeInfoSuccessBlock)success failure:(RichOXFailureBlock)failure;

/*!
@method getSetting:failure
@abstract 此接口用于获取宗门设置
@param success 成功的block，参数是:RichOXSectSettingData
@param failure 失败的block，返回失败的原因
*/
+ (void)getSetting:(RichOXSectGetSettingSuccessBlock)success failure:(RichOXFailureBlock)failure;

@end

NS_ASSUME_NONNULL_END
