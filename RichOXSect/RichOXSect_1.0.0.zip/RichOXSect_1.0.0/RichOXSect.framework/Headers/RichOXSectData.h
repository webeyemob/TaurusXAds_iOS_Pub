//
//  RichOXSectData.h
//  RichOX
//
//  Created by zena.tang on 2021/1/15.
//  Copyright © 2021 richox. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(int, RICHOX_SECT_INVITE_AWARD_TYPE) {
    RICHOX_SECT_INVITE_AWARD_TYPE_STAR        = 0,    //贡献值
    RICHOX_SECT_INVITE_AWARD_TYPE_CASH         = 1,   //现金
};

typedef NS_ENUM(int, RICHOX_SECT_RED_PACKET_TYPE) {
    RICHOX_SECT_RED_PACKET_TYPE_TRANSFORM        = 0,    //领取现金奖励
    RICHOX_SECT_RED_PACKET_TYPE_TRANSFORM_TIMES  = 1,    //领取现金奖励次数
};


@interface RichOXSectApprenticeData : NSObject

@property (nonatomic, strong, readonly) NSString *apprenticeUid;                //弟子uid
@property (nonatomic, readonly) BOOL verified;                               //是否验证
@property (nonatomic, readonly) int contribution;                                    //未领取的贡献值
@property (nonatomic, readonly) int totalContribution;                                //总贡献值
@property (nonatomic, strong, readonly) NSDictionary *dailyContribution;             //最近2天贡献值大于0的记录， key是日期“2020-08-10”， value是贡献值 int类型

- (instancetype) initWithResponse:(NSDictionary *)dic;

@end


@interface RichOXSectApprenticeList : NSObject

@property (nonatomic, readonly) int total;                                   //该级别的弟子数

@property (nonatomic, readonly) int pageSize;                                //每页大小，默认50，最大200
@property (nonatomic, readonly) int currentPage;                             //当前页，默认0

@property (nonatomic, strong, readonly) NSArray <RichOXSectApprenticeData *> *apprenticeList;   //弟子信息

- (instancetype) initWithResponse:(NSDictionary *)dic;

@end



@interface RichOXSectData : NSObject

@property (nonatomic, strong, readonly) NSString *masterUid;                 //宗主uid
@property (nonatomic, readonly) BOOL verified;                               //是否验证
@property (nonatomic, readonly) int verifiedApprenticeCount;                 //验证弟子数
@property (nonatomic, readonly) int inviteApprenticeCount;                   //邀请的弟子数，包含未验证的
@property (nonatomic, readonly) int level;                                   //宗门等级
@property (nonatomic, readonly) int contribution;                            //当前贡献值
@property (nonatomic, readonly) int transformCount;                          //现金兑换次数
@property (nonatomic, readonly) int timesPacketCount;                        //现金兑换次数领取个数
@property (nonatomic, strong, readonly) NSDictionary *inviteAwardInfo;       //邀请奖励领取状态   {  "1": true, "2": false, "3": false }
@property (nonatomic, strong, readonly) NSString *teacherUid;                //师傅uid


@property (nonatomic, strong, readonly) NSDictionary *apprenticeList;        //弟子字典，key：“1”，“2” ("1"表示掌门弟子)， value为RichOXSectApprenticeList结构

- (instancetype) initWithResponse:(NSDictionary *)dic;

@end

@interface RichOXSectApprenticeInfo : RichOXSectApprenticeData

@property (nonatomic, strong, readonly) NSString *teacherUid;                //师父uid
@property (nonatomic, readonly) int level;                                   //弟子级别
@property (nonatomic, readonly) int invitedApprenticeCount;                     //该弟子的弟子数

- (instancetype) initWithResponse:(NSDictionary *)dic;

@end

@interface RichOXSectInviteAward : NSObject

@property (nonatomic, readonly) RICHOX_SECT_INVITE_AWARD_TYPE awardType;//奖励类型 0 - 贡献值 1 - 现金
@property (nonatomic, readonly) int contribution;                           //贡献值
@property (nonatomic, readonly) int deltaContribution;                      //本次领取的奖励值
@property (nonatomic, readonly) float cash;                                 //领取后当前现金账户余额

- (instancetype) initWithResponse:(NSDictionary *)dic;

@end


@interface RichOXSectTransformTimesPacket : NSObject

@property (nonatomic, readonly) float packet;                                //红包里的金额
@property (nonatomic, readonly) int count;                                   //第几个红包，从1开始
@property (nonatomic, readonly) float deltaCash;                             //现金账户的变动
@property (nonatomic, readonly) float cash;                                  //领取后当前现金账户余额

- (instancetype) initWithResponse:(NSDictionary *)dic;

@end


@interface RichOXSectRedPacketData : NSObject

@property (nonatomic, strong, readonly) NSString *masterUid;                    //宗主uid
@property (nonatomic, readonly) RICHOX_SECT_RED_PACKET_TYPE packetType;     //红包类型, 0-领取现金奖励红包, 1-领取现金奖励次数红包
@property (nonatomic, readonly) int tongLevel;                                  //领取时的宗门等级，从1开始
@property (nonatomic, readonly) float amount;                                   //红包金额
@property (nonatomic, readonly) int timesPacketCount;                           //次数红包对应的次数，红包类型为1时才有值
@property (nonatomic, readonly) int transformCount;                             //领取现金奖励的次数，红包类型为0时才有值
@property (nonatomic, readonly) long long getTime;                              //红包获取时间, ms

- (instancetype) initWithResponse:(NSDictionary *)dic;

@end


@interface RichOXSectRedPacketRecord : NSObject

@property (nonatomic, readonly) int total;                                      //红包总个数
@property (nonatomic, readonly) int pageSize;                                   //记录 page size
@property (nonatomic, readonly) int curPage;                                    //记录当前页
@property (nonatomic, strong, readonly) NSArray <RichOXSectRedPacketData *> *items;                         //记录数组

- (instancetype) initWithResponse:(NSDictionary *)dic;

@end


@interface RichOXSectTransformResult : NSObject

@property (nonatomic, strong, readonly) NSArray <NSNumber *>*packets;         //现金兑换产生的红包金额数组，单位元
@property (nonatomic, readonly) int contribution;                             //现金兑换后当前贡献值
@property (nonatomic, readonly) int transformCount;                           //现金兑换次数
@property (nonatomic, readonly) float deltaCash;                              //现金账户的变动
@property (nonatomic, readonly) float cash;                                   //领取后当前现金账户余额

- (instancetype) initWithResponse:(NSDictionary *)dic;

@end

@interface RichOXSectInviteAwardsSettingData : NSObject

@property (nonatomic, readonly) int count;                                      //邀请人数
@property (nonatomic, readonly) RICHOX_SECT_INVITE_AWARD_TYPE awardType;    //奖励类型，0 贡献值 1 现金
@property (nonatomic, readonly) float value;                                    //奖励数值

- (instancetype) initWithCount:(int)count awardType:(RICHOX_SECT_INVITE_AWARD_TYPE)awardType value:(float)value;

@end

@interface RichOXSectSettingData : NSObject

@property (nonatomic, readonly) int hierarchy;                              //宗门阶层，徒弟级数，从1开始
@property (nonatomic, readonly) int transformContribution;                  //现金兑换消耗贡献值
@property (nonatomic, readonly) int maxPoolContribution;                    //未领取贡献最大值
@property (nonatomic, strong, readonly) NSArray *grades;                    //宗门各等级需要邀请人数，从1开始
@property (nonatomic, strong, readonly) NSArray <RichOXSectInviteAwardsSettingData *>*inviteAwards;         //邀请人数对应的贡献奖励
@property (nonatomic, strong, readonly) NSArray *transformTimesPackets;     //现金兑换次数红包参数


- (instancetype) initWithResponse:(NSDictionary *)dic;

@end


@interface RichOXSectMissionRecord : NSObject

@property (nonatomic, strong, readonly) NSString *recordId;             //record id
@property (nonatomic, strong, readonly) NSString *masterUid;            //宗主ID
@property (nonatomic, strong, readonly) NSString *missionId;            //任务ID

@property (nonatomic, strong, readonly) NSString *bonusType;            //奖励类型 ，contribution
@property (nonatomic, readonly) float bonus;                            //奖励数值
@property (nonatomic, strong, readonly) NSString *executedAt;           //执行时间 "2020-09-11T11:06:57.697+08:00"


- (instancetype) initWithResponse:(NSDictionary *)dic;

@end


@interface RichOXSectMissionSubmitResult : NSObject

@property (nonatomic, strong, readonly) RichOXSectMissionRecord *record;

@property (nonatomic, readonly) int contributionDelta;                                  //本次领取的宗门贡献值
@property (nonatomic, readonly) int currentContribution;                                //当前用户账户的宗门贡献值余额
@property (nonatomic, readonly) int restCount;                                //当前的宗门任务剩余的可领取次数。-1表示不限制领取次数

- (instancetype) initWithResponse:(NSDictionary *)dic;

@end

@interface RichOXSectQueryMissionResult : NSObject

@property (nonatomic, strong, readonly) NSArray <RichOXSectMissionRecord *>* records;

@property (nonatomic, readonly) int total;                                     //总数
@property (nonatomic, readonly) int pageIndex;                                 //记录开始index
@property (nonatomic, readonly) int pageSize;                                  //记录每页的大小
@property (nonatomic, strong, readonly) NSString *begin;                       //开始时间
@property (nonatomic, strong, readonly) NSString *end;                         //结束时间

- (instancetype) initWithResponse:(NSDictionary *)dic;

@end


NS_ASSUME_NONNULL_END
