//
//  RichOXSectApprenticeData.h
//  RichOXSect
//
//  Created by zena.tang on 2021/5/13.
//  Copyright © 2021 richox. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface RichOXSectApprenticeData : NSObject

@property (nonatomic, strong, readonly) NSString *apprenticeUid;                //弟子uid
@property (nonatomic, readonly) BOOL verified;                                  //是否验证
@property (nonatomic, readonly) int contribution;                               //未领取的贡献值
@property (nonatomic, readonly) int totalContribution;                          //总贡献值
@property (nonatomic, strong, readonly) NSDictionary *dailyContribution;        //最近2天贡献值大于0的记录， key是日期“2020-08-10”， value是贡献值 int类型

- (instancetype) initWithResponse:(NSDictionary *)dic;

@end

@interface RichOXSectApprenticeList : NSObject

@property (nonatomic, readonly) int total;                                   //该级别的弟子数

@property (nonatomic, readonly) int pageSize;                                //每页大小，默认50，最大200
@property (nonatomic, readonly) int currentPage;                             //当前页，默认0

@property (nonatomic, strong, readonly) NSArray <RichOXSectApprenticeData *> *apprenticeList;   //弟子信息

- (instancetype) initWithResponse:(NSDictionary *)dic;

@end

@interface RichOXSectApprenticeInfo : RichOXSectApprenticeData

@property (nonatomic, strong, readonly) NSString *teacherUid;                //师父uid
@property (nonatomic, readonly) int level;                                   //弟子级别
@property (nonatomic, readonly) int invitedApprenticeCount;                     //该弟子的弟子数

- (instancetype) initWithResponse:(NSDictionary *)dic;

@end

NS_ASSUME_NONNULL_END
