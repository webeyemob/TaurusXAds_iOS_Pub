//
//  RichOXSectInviteAward.h
//  RichOXSect
//
//  Created by RichOX on 2021/5/13.
//  Copyright © 2021 richox. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(int, RICHOX_SECT_INVITE_AWARD_TYPE) {
    RICHOX_SECT_INVITE_AWARD_TYPE_STAR        = 0,    //贡献值
    RICHOX_SECT_INVITE_AWARD_TYPE_CASH         = 1,   //现金
};

@interface RichOXSectInviteAward : NSObject

@property (nonatomic, readonly) RICHOX_SECT_INVITE_AWARD_TYPE awardType;//奖励类型 0 - 贡献值 1 - 现金
@property (nonatomic, readonly) int contribution;                           //贡献值
@property (nonatomic, readonly) int deltaContribution;                      //本次领取的奖励值
@property (nonatomic, readonly) double cash;                                 //领取后当前现金账户余额

- (instancetype) initWithResponse:(NSDictionary *)dic;

@end

NS_ASSUME_NONNULL_END
