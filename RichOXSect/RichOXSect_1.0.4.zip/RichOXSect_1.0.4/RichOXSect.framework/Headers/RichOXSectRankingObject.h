//
//  RichOXSectRankingObject.h
//  RichOXSect
//
//  Created by RichOX on 2021/5/13.
//  Copyright © 2021 richox. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface RichOXSectRankingObject : NSObject

@property (nonatomic, readonly) int index;                      //排行，从1开始
@property (nonatomic, strong, readonly) NSString *masterUid;    //宗主ID
@property (nonatomic, readonly) int inviteCount;                //邀请人数

- (instancetype) initWithResponse:(NSDictionary *)dic;

@end

NS_ASSUME_NONNULL_END
