//
//  RichOXSectSettingData.h
//  RichOXSect
//
//  Created by RichOX on 2021/5/13.
//  Copyright © 2021 richox. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RichOXSectInviteAward.h"

NS_ASSUME_NONNULL_BEGIN

@interface RichOXSectInviteAwardsSettingData : NSObject

@property (nonatomic, readonly) int count;                                      //邀请人数
@property (nonatomic, readonly) RICHOX_SECT_INVITE_AWARD_TYPE awardType;    //奖励类型，0 贡献值 1 现金
@property (nonatomic, readonly) float value;                                    //奖励数值

- (instancetype) initWithCount:(int)count awardType:(RICHOX_SECT_INVITE_AWARD_TYPE)awardType value:(float)value;

@end


@interface RichOXSectTransformStep : NSObject

@property (nonatomic, readonly) int step;                           //档位，以1开始
@property (nonatomic, readonly) int transformContribution;          //该档位现金兑换消耗贡献值

@end

@interface RichOXSectSettingData : NSObject

@property (nonatomic, readonly) int hierarchy;                              //宗门阶层，徒弟级数，从1开始
@property (nonatomic, readonly) int transformContribution;                  //现金兑换消耗贡献值,老版本使用此字段
@property (nonatomic, readonly) int maxPoolContribution;                    //未领取贡献最大值
@property (nonatomic, strong, readonly) NSArray *grades;                    //宗门各等级需要邀请人数，从1开始
@property (nonatomic, strong, readonly) NSArray <RichOXSectInviteAwardsSettingData *>*inviteAwards;         //邀请人数对应的贡献奖励
@property (nonatomic, strong, readonly) NSArray *transformTimesPackets;     //现金兑换次数红包参数

@property (nonatomic, strong, readonly) NSArray <RichOXSectTransformStep *>  *transfromSteps; //新接口用来设置现金兑换的档次，不同的档次有不同的兑换策略


- (instancetype) initWithResponse:(NSDictionary *)dic;

@end

NS_ASSUME_NONNULL_END
