//
//  RichOXSectData.h
//  RichOX
//
//  Created by RichOX on 2021/1/15.
//  Copyright © 2021 richox. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RichOXSectApprenticeData.h"

NS_ASSUME_NONNULL_BEGIN


@interface RichOXSectData : NSObject

@property (nonatomic, strong, readonly) NSString *masterUid;                 //宗主uid
@property (nonatomic, readonly) BOOL verified;                               //是否验证
@property (nonatomic, readonly) int verifiedApprenticeCount;                 //验证弟子数
@property (nonatomic, readonly) int inviteApprenticeCount;                   //邀请的弟子数，包含未验证的
@property (nonatomic, readonly) int level;                                   //宗门等级
@property (nonatomic, readonly) int contribution;                            //当前贡献值
@property (nonatomic, readonly) int transformCount;                          //现金兑换次数
@property (nonatomic, readonly) int timesPacketCount;                        //现金兑换次数领取个数
@property (nonatomic, strong, readonly) NSDictionary *inviteAwardInfo;       //邀请奖励领取状态   {  "1": true, "2": false, "3": false }
@property (nonatomic, strong, readonly) NSString *teacherUid;                //师傅uid


@property (nonatomic, strong, readonly) NSDictionary *apprenticeList;        //弟子字典，key：“1”，“2” ("1"表示掌门弟子)， value为RichOXSectApprenticeList结构

- (instancetype) initWithResponse:(NSDictionary *)dic;

@end

NS_ASSUME_NONNULL_END
