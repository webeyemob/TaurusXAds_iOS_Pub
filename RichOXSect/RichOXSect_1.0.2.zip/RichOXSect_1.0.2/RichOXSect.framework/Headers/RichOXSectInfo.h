//
//  RichOXSect.h
//  RichOX
//
//  Created by RichOX on 2021/1/14.
//  Copyright © 2021 richox. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RichOXSectData.h"
#import <RichOXBase/RichOXError.h>
#import "RichOXBase/RichOXMissionData.h"
#import "RichOXSectSettingData.h"
#import "RichOXSectRankingObject.h"

NS_ASSUME_NONNULL_BEGIN


typedef void (^RichOXSectGetSectInfoSuccessBlock)(RichOXSectData *data);
typedef void (^RichOXSectGetApprenticeListSuccessBlock)(RichOXSectApprenticeList *data);
typedef void (^RichOXSectGetApprenticeInfoSuccessBlock)(RichOXSectApprenticeInfo *data);

typedef void (^RichOXSectGetSettingSuccessBlock)(RichOXSectSettingData *data);


typedef void (^RichOXSectGenContributionSuccessBlock)(int contribution);
typedef void (^RichOXSectGetContributionSuccessBlock)(int contribution, int deltaContrition);

typedef void (^RichOXSectGetInviteCountSuccessBlock)(int inviteCount);

typedef void (^RichOXSectGetRankingListSuccessBlock)(NSArray <RichOXSectRankingObject *>*rankingList);

@interface RichOXSectInfo : NSObject

/*!
@method getSectInfo:failure
@abstract 此接口用于获取当前用户的宗门信息
@param success 成功的block，参数是RichOXSectData
@param failure 失败的block，返回失败的原因
*/
+ (void)getSectInfo:(RichOXSectGetSectInfoSuccessBlock)success failure:(RichOXFailureBlock)failure;

/*!
@method getApprenticeList:pageSize:currentPage:success:failure
@abstract 此接口用于分页获取某级弟子的信息
@param level 弟子级数 ，1为掌门弟子
@param pageSize 每页大小，0表示使用默认的50，最大200
@param currentPage 当前页，默认0
@param success 成功的block，参数是RichOXSectApprenticeListLevel
@param failure 失败的block，返回失败的原因
*/
+ (void)getApprenticeList:(int)level pageSize:(int)pageSize currentPage:(int)currentPage success:(RichOXSectGetApprenticeListSuccessBlock)success failure:(RichOXFailureBlock)failure;

/*!
@method getApprenticeInfo:success:failure
@abstract 此接口用于获取某个弟子的详细信息
@param apprenticeUid 弟子uid
@param success 成功的block，参数是RichOXSectApprenticeInfo
@param failure 失败的block，返回失败的原因
*/
+ (void)getApprenticeInfo:(NSString *)apprenticeUid success:(RichOXSectGetApprenticeInfoSuccessBlock)success failure:(RichOXFailureBlock)failure;

/*!
@method getSetting:failure
@abstract 此接口用于获取宗门设置
@param success 成功的block，参数是:RichOXSectSettingData
@param failure 失败的block，返回失败的原因
*/
+ (void)getSetting:(RichOXSectGetSettingSuccessBlock)success failure:(RichOXFailureBlock)failure;

/*!
@method genContribution:success:failure
@abstract 此接口用于通过上报某种动作产生贡献值(未领取状态，目前仅有观看视频广告)
@param actionId 动作id, 0-观看视频
@param success 成功的block，参数是贡献值
@param failure 失败的block，返回失败的原因
*/
+ (void)genContribution:(int)actionId success:(RichOXSectGenContributionSuccessBlock)success failure:(RichOXFailureBlock)failure;

/*!
@method getContribution:success:failure
@abstract 此接口用于领取贡献值
@param studentUid 不为空表示指定弟子，为nil表示所有弟子产生的贡献值
@param success 成功的block，参数是领取后当前宗门的贡献值，和本次领取的贡献值
@param failure 失败的block，返回失败的原因
*/
+ (void)getContribution:(NSString * _Nullable)studentUid success:(RichOXSectGetContributionSuccessBlock)success failure:(RichOXFailureBlock)failure;

/*!
@method getInviteCount:onlyVerified:success:failure
@abstract 此接口用于获取指定用户某个时间段后裂变邀请人数
@param sinceTime Timestamp, 精确到毫秒, 传入0则默认拉取所有人数
@param onlyVerified  YES：则只拉取验证弟子数，默认不过滤
@param success 成功的block，参数是邀请的人数
@param failure 失败的block，返回失败的原因
*/
+ (void)getInviteCount:(long)sinceTime onlyVerified:(BOOL)onlyVerified success:(RichOXSectGetInviteCountSuccessBlock)success failure:(RichOXFailureBlock)failure;

/*!
@method getRankingList:failure
@abstract 此接口用于获取邀请弟子排行榜
@param success 成功的block，参数是排行列表
@param failure 失败的block，返回失败的原因
*/
+ (void)getRankingList:(RichOXSectGetRankingListSuccessBlock)success failure:(RichOXFailureBlock)failure;

/*!
@method getSdkVersion
@abstract 获取SDK version
@return  SDK version string
*/
+ (NSString *)getSdkVersion;

@end

NS_ASSUME_NONNULL_END
