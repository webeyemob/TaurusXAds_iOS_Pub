//
//  RichOXSectTransformData.h
//  RichOXSect
//
//  Created by zena.tang on 2021/5/13.
//  Copyright © 2021 richox. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN


typedef NS_ENUM(int, RICHOX_SECT_RED_PACKET_TYPE) {
    RICHOX_SECT_RED_PACKET_TYPE_TRANSFORM        = 0,    //领取现金奖励
    RICHOX_SECT_RED_PACKET_TYPE_TRANSFORM_TIMES  = 1,    //领取现金奖励次数
};

@interface RichOXSectTransformTimesPacket : NSObject

@property (nonatomic, readonly) double packet;                                //红包里的金额
@property (nonatomic, readonly) int count;                                   //第几个红包，从1开始
@property (nonatomic, readonly) double deltaCash;                             //现金账户的变动
@property (nonatomic, readonly) double cash;                                  //领取后当前现金账户余额

- (instancetype) initWithResponse:(NSDictionary *)dic;

@end


@interface RichOXSectTransformData : NSObject

@property (nonatomic, strong, readonly) NSString *masterUid;                    //宗主uid
@property (nonatomic, readonly) RICHOX_SECT_RED_PACKET_TYPE packetType;     //红包类型, 0-领取现金奖励红包, 1-领取现金奖励次数红包
@property (nonatomic, readonly) int tongLevel;                                  //领取时的宗门等级，从1开始
@property (nonatomic, readonly) double amount;                                   //红包金额
@property (nonatomic, readonly) int timesPacketCount;                           //次数红包对应的次数，红包类型为1时才有值
@property (nonatomic, readonly) int transformCount;                             //领取现金奖励的次数，红包类型为0时才有值
@property (nonatomic, readonly) long long getTime;                              //红包获取时间, ms

- (instancetype) initWithResponse:(NSDictionary *)dic;

@end


@interface RichOXSectRedPacketRecord : NSObject

@property (nonatomic, readonly) int total;                                      //红包总个数
@property (nonatomic, readonly) int pageSize;                                   //记录 page size
@property (nonatomic, readonly) int curPage;                                    //记录当前页
@property (nonatomic, strong, readonly) NSArray <RichOXSectTransformData *> *items;                         //记录数组

- (instancetype) initWithResponse:(NSDictionary *)dic;

@end


@interface RichOXSectTransformResult : NSObject

@property (nonatomic, strong, readonly) NSArray <NSNumber *>*packets;         //现金兑换产生的红包金额数组，单位元
@property (nonatomic, readonly) int contribution;                             //现金兑换后当前贡献值
@property (nonatomic, readonly) int transformCount;                           //现金兑换次数
@property (nonatomic, readonly) double deltaCash;                              //现金账户的变动
@property (nonatomic, readonly) double cash;                                   //领取后当前现金账户余额

- (instancetype) initWithResponse:(NSDictionary *)dic;

@end

NS_ASSUME_NONNULL_END
