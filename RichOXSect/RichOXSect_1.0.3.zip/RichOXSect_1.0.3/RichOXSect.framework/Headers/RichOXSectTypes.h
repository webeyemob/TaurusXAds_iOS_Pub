//
//  RichOXSectTypes.h
//  RichOXSect
//
//  Created by RichOX on 2021/6/28.
//  Copyright © 2020 RichOX. All rights reserved.
//


//Common
typedef const void *RichOXSectTypeRef;

// RichOXFailureBlock callback
typedef void (*RichOXSectFailedCallback)(int code, char *message);


//RichOXSectData
typedef const void *RichOXSectDataTypeRef;
//getSectInfo callback
typedef void (*RichOXSectGetSectInfoCallback)(RichOXSectDataTypeRef sectDataRef);

//RichOXSectApprenticeList
typedef const void *RichOXSectApprenticeListTypeRef;

//RichOXSectApprenticeData
typedef const void *RichOXSectApprenticeDataTypeRef;

//RichOXSectApprenticeData Array
typedef const void *RichOXSectApprenticeDataTypeArrayRef;

//getApprenticeList callback
typedef void (*RichOXSectGetApprenticeListCallback)(RichOXSectApprenticeListTypeRef listRef);

//RichOXSectApprenticeInfo
typedef const void *RichOXSectApprenticeInfoTypeRef;
//getApprenticeInfo callback
typedef void (*RichOXSectGetApprenticeInfoCallback)(RichOXSectApprenticeInfoTypeRef infoRef);

//RichOXSectSettingData
typedef const void *RichOXSectSettingDataTypeRef;
//getSetting callback
typedef void (*RichOXSectGetSettingCallback)(RichOXSectSettingDataTypeRef settingRef);

typedef const void *RichOXSectArrayTypeRef;

//RichOXSectInviteAwardsSettingData
typedef const void *RichOXSectInviteAwardsSettingDataTypeRef;

//RichOXSectInviteAwardsSettingData array
typedef const void *RichOXSectInviteAwardsSettingDataArrayTypeRef;

//RichOXSectTransformStep
typedef const void *RichOXSectTransformStepTypeRef;

//RichOXSectTransformStep Array
typedef const void *RichOXSectTransformStepArrayTypeRef;

//genContribution callback
typedef void (*RichOXSectGenContributionCallback)(int contribution);

//getContribution callback
typedef void (*RichOXSectGetContributionCallback)(int contribution, int deltaContribution);

//getInviteCount callback
typedef void (*RichOXSectGetInviteCountCallback)(int inviteCount);

//RichOXSectRankingObject
typedef const void *RichOXSectRankingObjectTypeRef;

//RichOXSectRankingObject NSArray
typedef const void *RichOXSectRankingObjectTypeArrayRef;

//getRankingList callback
typedef void (*RichOXSectGetRankingListCallback)(RichOXSectRankingObjectTypeArrayRef arrayRef);

//NSDictionary
typedef const void *RichOXSectDictionaryTypeRef;

//NSArray
typedef const void *RichOXSectArrayTypeRef;


//国内的宗门系统数据定义
//RichOXSectGetContributionDayRecordSuccessBlock
typedef void (*RichOXSectGetContributionDayRecordCallback)(RichOXSectDictionaryTypeRef recordDicRef);

//RichOXSectTransformTimesPacket
typedef const void *RichOXSectTransformTimesPacketTypeRef;
//RichOXSectGetContributionDayRecordSuccessBlock
typedef void (*RichOXSectGetTransformTimesPacketCallback)(RichOXSectTransformTimesPacketTypeRef packetRef);



//RichOXSectRedPacketRecord
typedef const void *RichOXSectRedPacketRecordTypeRef;
//RichOXSectGetRedPacketRecordSuccessBlock
typedef void (*RichOXSectGetPacketRecordCallback)(RichOXSectTransformTimesPacketTypeRef recordRef);

//RichOXSectTransformData
typedef const void *RichOXSectTransformDataTypeRef;



//RichOXSectTransformResult
typedef const void *RichOXSectTransformResultTypeRef;
//RichOXSectTransformSuccessBlock
typedef void (*RichOXSectTransformCallback)(RichOXSectTransformResultTypeRef resultRef);

//RichOXSectInviteAward
typedef const void *RichOXSectInviteAwardTypeRef;
//RichOXSectGetInviteAwardSuccessBlock
typedef void (*RichOXSectGetInviteAwardCallback)(RichOXSectInviteAwardTypeRef awardRef);

//RichOXSectInviteAwardsSettingData
typedef const void *RichOXSectInviteAwardsSettingDataTypeRef;
//RichOXSectGetInviteAwardSettingSuccessBlock
typedef void (*RichOXSectGetInviteAwardSettingCallback)(RichOXSectArrayTypeRef settingRef);

//RichOXSectGetInviteAwardSettingSuccessBlock
typedef void (*RichOXSectGetSectStatusCallback)(int status);
