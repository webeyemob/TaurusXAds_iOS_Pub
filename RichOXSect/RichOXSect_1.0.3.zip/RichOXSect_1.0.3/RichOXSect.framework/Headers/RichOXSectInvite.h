//
//  RichOXSectInvite.h
//  RichOXSect
//
//  Created by zena.tang on 2021/1/28.
//  Copyright © 2021 richox. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RichOXSectSettingData.h"
#import "RichOXSectInviteAward.h"
#import <RichOXBase/RichOXError.h>

NS_ASSUME_NONNULL_BEGIN

typedef void (^RichOXSectGetInviteAwardSuccessBlock)(RichOXSectInviteAward *award);

typedef void (^RichOXSectGetInviteAwardSettingSuccessBlock)(NSArray <RichOXSectInviteAwardsSettingData *> *list);

@interface RichOXSectInvite : NSObject

/*!
@method getInviteAward:success:failure
@abstract 此接口用于领取招募奖励
@param count 奖励对应的招募用户数
@param success 成功的block，参数是RichOXSectInviteAward
@param failure 失败的block，返回失败的原因
*/
+ (void)getInviteAward:(int)count success: (RichOXSectGetInviteAwardSuccessBlock)success failure:(RichOXFailureBlock)failure;


/*!
@method getInviteAwardSetting:failure
@abstract 此接口用于获取招募奖励设置列表
@param success 成功的block，参数是:NSArray <RichOXSectInviteAwardsSettingData *> *
@param failure 失败的block，返回失败的原因
*/
+ (void)getInviteAwardSetting:(RichOXSectGetInviteAwardSettingSuccessBlock)success failure:(RichOXFailureBlock)failure;

@end

NS_ASSUME_NONNULL_END
