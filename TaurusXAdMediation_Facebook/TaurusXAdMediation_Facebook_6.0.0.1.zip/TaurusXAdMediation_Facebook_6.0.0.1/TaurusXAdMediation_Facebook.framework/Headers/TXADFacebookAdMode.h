//
//  TXADFacebookAdMode.h
//  TaurusXAdMediation_Facebook
//
//  Created by TaurusXAds on 2020/2/3.
//  Copyright © 2020 TaurusXAds. All rights reserved.
//

typedef NS_ENUM(NSUInteger, TXADFacebookNativeMode) {
    TXAD_FACEBOOK_NATIVE_NORMAL = 0, // normal native
    TXAD_FACEBOOK_NATIVE_BANNER = 1 // native banner
};

typedef NS_ENUM(NSUInteger, TXADFacebookFeedListMode) {
    TXAD_FACEBOOK_FEEDLIST_NATIVE = 0, // normal native
    TXAD_FACEBOOK_FEEDLIST_NATIVE_BANNER = 1 // native banner
};
