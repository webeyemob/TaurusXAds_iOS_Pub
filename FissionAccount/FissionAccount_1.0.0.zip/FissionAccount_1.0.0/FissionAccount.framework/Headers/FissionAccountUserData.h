//
//  FissionAccountUserData.h
//  FissionAccount
//
//  Created by zena.tang on 2020/12/14.
//  Copyright © 2020 TaurusXAds. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FissionAccountSocialAccount.h"

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, FISSIONACCOUNT_BINDTYPE) {
    FISSIONACCOUNT_BINDTYPE_WECHAT                      = 0, //微信
    FISSIONACCOUNT_BINDTYPE_FACEBOOK                    = 1,  // facebook
    FISSIONACCOUNT_BINDTYPE_GOOGLE                      = 2,  // google
    FISSIONACCOUNT_BINDTYPE_APPLE                       = 3,  // apple
    FISSIONACCOUNT_BINDTYPE_ALIPAY                      = 4   // 支付宝
};

typedef NS_ENUM(int, FISSIONACCOUNT_GENDER_TYPE) {
    FISSIONACCOUNT_GENDER_UNKNOWN                       = 0, //未知
    FISSIONACCOUNT_GENDER_MALE                          = 1,  // 男
    FISSIONACCOUNT_GENDER_FEMALE                        = 2   // 女
};


typedef NS_ENUM(int, FISSIONACCOUNT_INVITATE_STATUS) {
    FISSIONACCOUNT_INVITATE_STATUS_OK                   = 1,    //绑定成功
    FISSIONACCOUNT_INVITATE_STATUS_INVALIDED            = 50,   // 邀请无效
    FISSIONACCOUNT_INVITATE_STATUS_VALIDED              = 100   // 邀请有效
};

@interface FissionAccountUserData : NSObject

@property (nonatomic, strong, readonly) NSString *id;                 //用户唯一标识
@property (nonatomic, strong, readonly) NSString *name;               //用户昵称自动生成，绑定facebook后更新为facebook用户的name
@property (nonatomic, strong, readonly) NSString *avatar;             //头像URL,绑定微信后设置
@property (nonatomic, strong, readonly) NSString *deviceId;           //设备唯一id
@property (nonatomic, strong, readonly) NSString *phone;


//微信信息
@property (nonatomic, strong, readonly) NSString *wechatOpenId;       //微信用户openid    绑定微信后设置
@property (nonatomic, strong, readonly) NSString *wechatAppId;        //微信开发者账号appid    绑定微信后设置
@property (nonatomic, strong, readonly) NSString *wechatBoundAt;      //微信bind时间
@property (nonatomic, readonly) FISSIONACCOUNT_GENDER_TYPE gender;        //性别，1:男，2：女


@property (nonatomic, readonly) int coin;                             //金币数量
@property (nonatomic, readonly) float cash;                           //现金数量

@property (nonatomic, readonly) BOOL hasWithdrawn;                    //是否提现过


@property (nonatomic, strong, readonly) NSString *installAt;          //安装时间
@property (nonatomic, strong, readonly) NSString *inviterId;          //邀请者ID（师傅）
@property (nonatomic, strong, readonly) NSString *invitationCode;     //邀请码

@property (nonatomic, readonly) BOOL isNew;                           //是否新创建用户

//fb信息
@property (nonatomic, strong, readonly) NSString *fbOpenId;           //facebook用户标识
@property (nonatomic, strong, readonly) NSString *fbName;             //facebook用户名
@property (nonatomic, strong, readonly) NSString *fbFirstName;          //用户名
@property (nonatomic, strong, readonly) NSString *fbLastName;           //用户姓氏
@property (nonatomic, strong, readonly) NSString *fbEmail;            //用户email

//google信息
@property (nonatomic, strong, readonly) NSString *googleSub;          //google账号唯一标示    google开关必须打开
@property (nonatomic, strong, readonly) NSString *googleName;         //google账号用户名    google开关必须打开


//apple信息
@property (nonatomic, strong, readonly) NSString *appleSub;           //apple账号唯一标示    apple开关必须打开
@property (nonatomic, strong, readonly) NSString *appleName;          //apple账号用户名    apple开关必须打开

//支付宝账号信息
@property (nonatomic, strong, readonly) NSString *alipayId;           //支付宝账号唯一标示
@property (nonatomic, strong, readonly) NSString *alipayName;          //支付宝账号名

- (instancetype) initWithResponse:(NSDictionary *)dic;


@end


@interface FissionAccountUserBindResult : FissionAccountUserData

@property (nonatomic, readonly) FISSIONACCOUNT_BINDTYPE bindType;                           //bind type
@property (nonatomic, readonly) long long createdAt;                                     //用户创建时间，毫秒时间戳

@property (nonatomic, strong, readonly) FissionAccountSocialAccount *socialAccountInfo;     //社交账号信息

- (instancetype) initWithResponse:(NSDictionary *)dic bindType: (FISSIONACCOUNT_BINDTYPE)bindType;

@end

@interface FissionAccountUserTokenData : NSObject

@property (nonatomic, strong, readonly) NSString *userId;             //id
@property (nonatomic, strong, readonly) NSString *token;              //token
@property (nonatomic, readonly) long long refreshTime;                //刷新时间

- (instancetype) initWithResponse:(NSDictionary *)dic;

@end


@interface FissionAccountUserBasicData : NSObject

@property (nonatomic, strong, readonly) NSString *userId;             //id
@property (nonatomic, strong, readonly) NSString *name;              //name
@property (nonatomic, strong, readonly) NSString *avatar;            //头像

- (instancetype) initWithResponse:(NSDictionary *)dic;

@end


NS_ASSUME_NONNULL_END
