//
//  FissionAccountUser.h
//  FissionAccount
//
//  Created by zena.tang on 2020/12/12.
//  Copyright © 2020 TaurusXAds. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FissionAccountError.h"
#import "FissionAccountUserData.h"

NS_ASSUME_NONNULL_BEGIN

typedef void (^FissionAccountUserGetUserDataSuccessBlock)(FissionAccountUserData *userData);
typedef void (^FissionAccountUserBindSuccessBlock)(FissionAccountUserBindResult *result);

typedef void (^FissionAccountGetUserBasicInfosSuccessBlock)(NSArray <FissionAccountUserBasicData *> *data);

typedef void (^FissionAccountGetAlipayAuthInfoSuccessBlock)(NSString *authInfo);

/*!
包含用户 API.的类
*/
@interface FissionAccountUser : NSObject

/*!
@method registerUserId:initInfo:success:failure
@abstract 此接口用于新安装用户获取游客身份
@param inviterId 邀请者ID
@param initInfo 客户端存储的用户的初始信息，仅首次注册有效，一般不用，除非是应用在没使用fission之前有本地存储的用户信息
@param success 成功的block，参数是用户信息
@param failure 失败的block
*/
+ (void)registerUserId:(NSString * _Nullable)inviterId initInfo:(FissionAccountInitUserData * _Nullable)initInfo success: (FissionAccountUserGetUserDataSuccessBlock)success failure:(FissionAccountFailureBlock)failure;

/*!
@method bindUser:bindType:bindCode:success:failure:
@abstract 社交账号绑定
@param appId  google用户该值为google id 微信用户是微信应用的app_id, facebook用户是facebook用户的open_id, apple用户是apple user Id, alipay用户填入alipay
@param bindType 社交账号类型，参见FISSIONACCOUNT_BINDTYPE
@param bindCode 微信用户为微信绑定code, Facebook用户为 facebook用户的授权码token, google用户为用户的id_token, Apple用户是登录后获取的token, alipay用户是authCode
@param success 成功的block，参数是绑定之后的用户信息
@param failure 失败的block
*/
+ (void)bindUser: (NSString *)appId bindType:(FISSIONACCOUNT_BINDTYPE)bindType bindCode:(NSString *)bindCode success:(FissionAccountUserBindSuccessBlock)success failure:(FissionAccountFailureBlock)failure;

/*!
@method checkBind:bindType:bindCode:success:failure:
@abstract 社交账号绑定检查
@param appId google用户该值为google id 微信用户是微信应用的app_id, facebook用户是facebook用户的open_id, apple用户是apple user Id，alipay用户填入alipay
@param bindType 社交账号类型，参见FISSIONACCOUNT_BINDTYPE
@param bindCode 微信用户为微信绑定code, Facebook用户为 facebook用户的授权码token, google用户为用户的id_token, Apple用户是登录后获取的token，alipay用户是authCode
@param success 成功的block，参数是绑定之后的用户信息
@param failure 失败的block
*/
+ (void)checkBind: (NSString *)appId bindType:(FISSIONACCOUNT_BINDTYPE)bindType bindCode:(NSString *)bindCode success:(FissionAccountUserBindSuccessBlock)success failure:(FissionAccountFailureBlock)failure;

/*!
@method getUserInfo:failure:
@abstract 此接口用于获取用户昵称、头像、金币数等信息
@param success 成功的block，参数是用户信息
@param failure 失败的block
*/
+ (void)getUserInfo: (FissionAccountUserGetUserDataSuccessBlock)success failure:(FissionAccountFailureBlock)failure;

/*!
@method getUserBaseInfo:success:failure:
@abstract 此接口用于获取指定用户微信昵称、头像等信息
@param targetUserId  指定的用户ID
@param success 成功的block，参数是FissionAccountUserBasicData的数组
@param failure 失败的block
*/
+ (void)getUserBaseInfo: (NSArray *)targetUserId success:(FissionAccountGetUserBasicInfosSuccessBlock)success failure:(FissionAccountFailureBlock)failure;

/*!
@method logOutUser:failure
@abstract 此接口用于注销指定用户，用户注销成功后，该用户设备将无法再次使用产品
@param success 成功的block，参数无
@param failure 失败的block
*/
+ (void)logOutUser:(FissionAccountCommonSuccessBlock)success failure:(FissionAccountFailureBlock)failure;


/*!
@method registerByWeChat:bindCode:success:failure:
@abstract 此接口用于新安装用户直接使用微信注册
@param appId  微信应用的app_id
@param bindCode 微信绑定code
@param success 成功的block，参数是绑定之后的用户信息
@param failure 失败的block
*/
+ (void)registerByWeChat:(NSString *)appId bindCode:(NSString *)bindCode inviterUid: (NSString * _Nullable)inviterUid success:(FissionAccountUserBindSuccessBlock)success failure:(FissionAccountFailureBlock)failure;

/*!
@method syncWeChat:oopenId:unionId:nickName:headImgUrl:success:failure:
@abstract 此接口用于三方用户中心同步微信用户信息
@param appId  微信应用的app_id
@param openId  微信用户open_id
@param unionId  微信用户union_id
@param nickName  微信用户的昵称
@param headImgUrl  微信用户的头像
@param success 成功的block，参数是绑定之后的用户信息
@param failure 失败的block
*/
+ (void)syncWeChat:(NSString *)appId openId:(NSString *)openId unionId:(NSString *)unionId nickName:(NSString *)nickName headImgUrl:(NSString *)headImgUrl success:(FissionAccountUserBindSuccessBlock)success failure:(FissionAccountFailureBlock)failure;

/*!
@method registerByFacebook:accessToken:success:failure:
@abstract 此接口用于新安装用户直接使用Facebook注册
@param openId  facebook用户的open_id
@param accessToken facebook用户的授权码token
@param success 成功的block，参数是绑定之后的用户信息
@param failure 失败的block
*/
+ (void)registerByFacebook:(NSString *)openId accessToken:(NSString *)accessToken success:(FissionAccountUserBindSuccessBlock)success failure:(FissionAccountFailureBlock)failure;

/*!
@method registerByGoogle:success:failure:
@abstract 此接口用于新安装用户直接使用Google账号注册
@param idToken  google用户的id_token
@param success 成功的block，参数是绑定之后的用户信息
@param failure 失败的block
*/
+ (void)registerByGoogle:(NSString *)idToken success:(FissionAccountUserBindSuccessBlock)success failure:(FissionAccountFailureBlock)failure;

/*!
@method registerByApple:appleToken:success:failure:
@abstract 此接口用于新安装用户直接使用Apple注册
@param appleName  apple用户名，可为nil
@param appleToken Apple用户登录后获取的token
@param success 成功的block，参数是绑定之后的用户信息
@param failure 失败的block
*/
+ (void)registerByApple:(NSString * _Nullable)appleName appleToken:(NSString *)appleToken success:(FissionAccountUserBindSuccessBlock)success failure:(FissionAccountFailureBlock)failure;

/*!
@method bindInviter:successfailure:
@abstract 此接口用于异步绑定邀请者, (为避免师徒关系出现环，后端会检测调用此接口的用户不能有徒弟，否则绑定失败)
@param inviterId  师傅ID
@param success 成功的block，参数是邀请记录
@param failure 失败的block
*/
+ (void)bindInviter:(NSString *)inviterId success: (FissionAccountCommonSuccessBlock)success failure:(FissionAccountFailureBlock)failure;

@end

NS_ASSUME_NONNULL_END
