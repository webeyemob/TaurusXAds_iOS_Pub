//
//  FissionAccountError.h
//  FissionAccount
//
//  Created by zena.tang on 2020/12/14.
//  Copyright © 2020 TaurusXAds. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, FissionAccountErrorCode) {
    FISSIONACCOUNT_ERRORCODE_INTERNAL                                   = -10000, //no code or response is nil
    FISSIONACCOUNT_ERRORCODE_NETWORK_ERROR                              = -10001, //network error
    FISSIONACCOUNT_ERRORCODE_NO_USERID                                  = -10002, //用户ID为nil
};

typedef void (^FissionAccountFailureBlock)(NSError *error);
typedef void (^FissionAccountCommonSuccessBlock)(void);


@interface FissionAccountError : NSObject

+ (NSError *)createError: (NSInteger)code message: (NSString * _Nullable)message;

@end

NS_ASSUME_NONNULL_END
