//
//  FissionAccountManager.h
//  FissionAccount
//
//  Created by zena.tang on 2020/12/12.
//  Copyright © 2020 TaurusXAds. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface FissionAccountManager : NSObject


+ (void) initWithHost:(NSString *)host key:(NSString *)key deviceId:(NSString * _Nullable)deviceId userId: (NSString *_Nullable)userId;


+ (NSString *)hostUrl;
+ (NSString *)keyStr;
+ (NSString *)deviceId;
+ (NSString *)fissionPlatform;

+ (NSInteger)appVersion;

+ (void) setTestMode:(BOOL)testMode;
+ (BOOL) isTestMode;

+ (NSString *)userId;

+ (void)cancelUser;

+ (void)setFissionPlatform: (NSString *)fissionPlatform;
+ (void)setAppVersion:(NSInteger)appVersion;

+ (void)saveUserId:(NSString *)userId;

+ (void)setHost:(NSString *)host;
+ (void)setKey: (NSString *)key;

+ (void)setDeviceId: (NSString *)deviceId;

@end

NS_ASSUME_NONNULL_END
