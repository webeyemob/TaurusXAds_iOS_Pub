//
//  TaurusXAdMediation_DUAdPlatform.h
//  TaurusXAdMediation_DUAdPlatform
//
//  Created by TaurusXAds on 2019/11/2.
//  Copyright © 2019年 TaurusXAds. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for TaurusXAdMediation_DUAdPlatform.
FOUNDATION_EXPORT double TaurusXAdMediation_DUAdPlatformVersionNumber;

//! Project version string for TaurusXAdMediation_DUAdPlatform.
FOUNDATION_EXPORT const unsigned char TaurusXAdMediation_DUAdPlatformVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TaurusXAdMediation_DUAdPlatform/PublicHeader.h>


