//
//  ABUAdPersonaliseCfgAdapter.m
//  ABUDemo
//
//  Created by wangchao on 2020/4/16.
//  Copyright © 2020 wangchao. All rights reserved.
//


#import <BUAdSDK/BUAdSDK.h>
#import <ABUAdSDK/ABUAdapterPersonaliseConfigProtocol.h>

#import "ABUPanglePersonaliseConfigAdapter.h"


@interface ABUPanglePersonaliseConfigAdapter () <ABUAdapterPersonaliseConfigProtocol>

@end


@implementation ABUPanglePersonaliseConfigAdapter
#pragma mark ---<ABUAdapterPersonaliseConfigProtocol>---
+ (void)setupPersonaliseConfiguration {
    // 第三方开发者在这设置BuAdSDK一些个性化配置
    // 不要在此写初始化代码！！！聚合SDK已完成初始化
//    [BUAdSDKManager setLoglevel:BUAdSDKLogLevelDebug];
    [BUAdSDKManager setOfflineType:BUOfflineTypeNone];
}


@end
