//
//  ABUKsPersonaliseConfigAdapter.m
//  ABUAdKsAdapter
//
//  Created by XuQingJia on 2020/10/13.
//

#import "ABUKsPersonaliseConfigAdapter.h"
#import <ABUAdSDK/ABUAdapterPersonaliseConfigProtocol.h>

@interface ABUKsPersonaliseConfigAdapter()<ABUAdapterPersonaliseConfigProtocol>


@end


@implementation ABUKsPersonaliseConfigAdapter

+ (void)setupPersonaliseConfiguration {

}

@end
