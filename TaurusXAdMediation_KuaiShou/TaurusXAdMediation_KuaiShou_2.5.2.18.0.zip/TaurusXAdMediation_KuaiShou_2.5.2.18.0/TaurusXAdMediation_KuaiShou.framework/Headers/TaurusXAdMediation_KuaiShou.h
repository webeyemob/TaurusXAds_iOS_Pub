//
//  TaurusXAdMediation_KuaiShou.h
//  TaurusXAdMediation_KuaiShou
//
//  Created by 汤正 on 2019/11/22.
//  Copyright © 2019 TaurusXAds. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for TaurusXAdMediation_KuaiShou.
FOUNDATION_EXPORT double TaurusXAdMediation_KuaiShouVersionNumber;

//! Project version string for TaurusXAdMediation_KuaiShou.
FOUNDATION_EXPORT const unsigned char TaurusXAdMediation_KuaiShouVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TaurusXAdMediation_KuaiShou/PublicHeader.h>

#import <TaurusXAdMediation_KuaiShou/TXADKuaiShouRewardedVideoConfig.h>
#import <TaurusXAdMediation_KuaiShou/TXADKuaiShouVideoConfig.h>
#import <TaurusXAdMediation_KuaiShou/TXADKuaiShouExpressFeedListConfig.h>

