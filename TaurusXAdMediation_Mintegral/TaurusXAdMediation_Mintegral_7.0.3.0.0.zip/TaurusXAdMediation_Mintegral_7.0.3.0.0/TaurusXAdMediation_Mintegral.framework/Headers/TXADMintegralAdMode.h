//
//  TXADMobvistaAdMode.h
//  TaurusXAdMediation_Mintegral
//
//  Created by TaurusXAds on 2020/2/3.
//  Copyright © 2020 TaurusXAds. All rights reserved.
//

typedef NS_ENUM(NSUInteger, TXADMintegralInterstitialMode) {
    TXAD_MOBVISTA_INTERSTITIAL_NORMAL = 0, // 插屏
    TXAD_MOBVISTA_INTERSTITIAL_VIDEO = 1 // video插屏
};

typedef NS_ENUM(NSUInteger, TXADMintegralRewardedVideoMode) {
    TXAD_MOBVISTA_REWARDEDVIDEO_NORMAL = 0, // 激励视频
    TXAD_MOBVISTA_REWARDEDVIDEO_INTERACTIVE = 1 // 交互式广告
};

typedef NS_ENUM(NSUInteger, TXADMintegralFeedListMode) {
    TXAD_MOBVISTA_FEEDLIST_CUSTOM = 0, // 自定义渲染
    TXAD_MOBVISTA_FEEDLIST_AUTO_RENDERING = 1 // 自动渲染
};
