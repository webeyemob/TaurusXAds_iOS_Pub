//
//  TaurusXAdMediation_Mintegral.h
//  TaurusXAdMediation_Mintegral
//
//  Created by TaurusXAds on 2019/11/13.
//  Copyright © 2019 TaurusXAds. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for TaurusXAdMediation_Mintegral.
FOUNDATION_EXPORT double TaurusXAdMediation_MintegralVersionNumber;

//! Project version string for TaurusXAdMediation_Mintegral.
FOUNDATION_EXPORT const unsigned char TaurusXAdMediation_MintegralVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TaurusXAdMediation_Mintegral/PublicHeader.h>

#import <TaurusXAdMediation_Mintegral/TXADMintegralAdMode.h>
