//
//  Embeded.h
//  EmbededSdk
//
//  Created by zena.tang on 2021/1/5.
//  Copyright © 2021 TaurusXAds. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Embeded : NSObject

+ (void)start;
+ (void)setOverSea:(BOOL)overSea;

+ (void)start:(NSString *)appleId DEPRECATED_MSG_ATTRIBUTE("Please set TGCAppleID to plist and use [Embeded start] and [Embeded setOverSea] replace");

+ (void)setTestMode;

+ (void)setLogEnable;

@end

NS_ASSUME_NONNULL_END
