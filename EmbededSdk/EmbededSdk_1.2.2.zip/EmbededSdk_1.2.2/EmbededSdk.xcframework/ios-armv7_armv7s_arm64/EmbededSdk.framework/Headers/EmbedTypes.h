//
//  EmbedTypes.h
//  EmbededSdk
//
//  Created by Embed on 2021/7/6.
//  Copyright © 2021 Embed. All rights reserved.
//

#ifndef EmbedTypes_h
#define EmbedTypes_h

#pragma mark - Common
typedef const void *EmbedTypeRef;


#pragma mark - iOS
typedef const void *EmbedTypeNSMutableDictionaryRef;

#endif /* EmbedTypes_h */
