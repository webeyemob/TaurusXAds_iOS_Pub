//
//  Embeded.h
//  EmbededSdk
//
//  Created by zena.tang on 2021/1/5.
//  Copyright © 2021 TaurusXAds. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef enum : NSInteger {
    EMBEDEDSDK_PLAY_END_RESULT_UNCOMPLETED = 0,
    EMBEDEDSDK_PLAY_END_RESULT_SUCCESS = 1,
    EMBEDEDSDK_PLAY_END_RESULT_FAIL = 2,
} EMBEDEDSDK_PLAY_END_RESULT;


@protocol EmbededEventDelegate <NSObject>

@required
- (void)onEventReport:(NSString *)eventName eventValue:(NSDictionary *)eventValue;

@end

@interface Embeded : NSObject

/*!
@brief 启动 embeded SDK.
*/
+ (void)start;

+ (void)setEventDelegate:(id<EmbededEventDelegate>)delegate;

/*!
@brief 设置APP是海外应用或国内应用，默认国内应用
@param overSea YES: 海外应用 NO: 国内应用
*/
+ (void)setOverSea:(BOOL)overSea;

+ (void)start:(NSString *)appleId DEPRECATED_MSG_ATTRIBUTE("Please set TGCAppleID to plist and use [Embeded start] and [Embeded setOverSea] replace");

/*!
@brief 设置事件发送到测试服务器
*/
+ (void)setTestMode;

/*!
@brief 打开Log
*/
+ (void)setLogEnable;

/*!
@brief 开始关卡，每次开始关卡时调用，带上关卡名称
@param itemId 关卡名称，针对闯关性质玩法，标注关卡名称。如无特定名称，也可填关卡ID数字
*/
+ (void)startPlay:(NSString *)itemId;

/*!
@brief 结束关卡，每次结束关卡时调用
@param itemId 关卡名称
@param result 关卡结果
@param time 关卡时长（单位秒）
*/
+ (void)endPlay:(NSString *)itemId result:(EMBEDEDSDK_PLAY_END_RESULT)result time:(long)time;

/*!
@brief 激励视频广告场景展示
@param itemId 场景名字
*/
+ (void)adSceneShow:(NSString *)itemId;

/*!
@brief 激励视频广告点击，点击激励视频时按钮上报，带场景名字
@param itemId 场景名字
*/
+ (void)adRewardClick:(NSString *)itemId;

/*!
@brief 每次获得资源时调用
@param type 资源名称(如金币/现金/红包券/视频币等)
@param value 数量
@param source 来源(如新手红包/闯关/转盘/签到等)
*/
+ (void)coinAcquired:(NSString *)type value:(double)value source:(NSString *)source;

/*!
@brief 每次资源消耗时调用
@param type 资源名称(如金币/现金/红包券/视频币等)
@param value 数量
*/
+ (void)coinUsed:(NSString *)type value:(double)value;

/*!
@brief 每次提现成功调用
@param type 提现任务ID
@param value 金额
*/
+ (void)withdraw:(NSString *)type value:(double)value;

/*!
@brief 每次页面打开时调用
@param page 页面名称信息
*/
+ (void)pageView:(NSString *)page;

/*!
@brief 每次点击按钮时调用，和按钮名称信息必须带上
@param page 页面名称信息
@param description 携带的信息：如复制的内容，翻译的内容，提交的信息，选择的内容
@param clickType 当点击指向功能实现：to_func；当指向为页面：to_page
@param target 1. 指向功能的名称；如：cancel(取消), choose(选择), reward_video(激励视频), copy(复制), delete(删除), translate(翻译), turn_on/trun_off(开关), submit(提交), launch(启动游戏之类的), restore_purchased(回复内购)；2. 按钮的名称；3. 指向页面的名称或url
@param source 点击发生的页面来源：1. 可以是上一个页面，2. 可以是推送等来源， 3. 可以是url
*/
+ (void)click:(NSString *)page description:(NSString *)description clickType:(NSString *)clickType target:(NSString *)target source:(NSString *)source;

@end

NS_ASSUME_NONNULL_END
