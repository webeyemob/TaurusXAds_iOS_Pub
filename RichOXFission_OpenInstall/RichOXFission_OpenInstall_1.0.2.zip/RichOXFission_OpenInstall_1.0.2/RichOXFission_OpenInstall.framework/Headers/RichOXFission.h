//
//  RichOXFission.h
//  FissionSdk
//
//  Created by zena.tang on 2021/1/8.
//  Copyright © 2021 richox. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

typedef void(^RichOXFissionSuccessHandler)(NSString *shareUrl);
typedef void(^RichOXFissionFailHandler)(NSError *error);

@protocol RichOXFissionDelegate <NSObject>

@required
/*!
@method getInstallParams:params
@abstract SDK通过调用该方法返回邀请者的ID
@param params 师傅分享ID时自定义的参数
*/
- (void)getInstallParams: (NSDictionary *)params;

@end

@interface RichOXFission : NSObject

/**
 获取单例对象
 
 @return 单例对象
 */
+ (RichOXFission *)shareInstance;

/*!
@method start:
@abstract 启动Link功能获取分享链接里的自定义的参数
@param delegate  设置代理方法用于分享时自定义的参数
@param isOverSea  海外产品需要设置此参数为YES
*/
- (void) start:(id <RichOXFissionDelegate>)delegate isOverSea:(BOOL)isOverSea;

/*!
@method getShareLink:params:success:fail
@abstract 获取本人的分享连接
@param host  web端地址
@param params 师傅分享ID时自定义的参数，fission_activity_name（活动名称）没有用default，和fission_share_channel_id（H5渠道信息，使用@“01”），
@param success 成功的block，参数是邀请链接
@param fail 失败的block，返回失败的原因
*/
+ (void)genShareURL: (NSString *)host params:(NSDictionary *)params success:(RichOXFissionSuccessHandler)success fail:(RichOXFissionFailHandler)fail;

/*!
@method getQRCodeView:linkUrl
@abstract 给分享链接生成二维码 view
@param frame  view的大小
@param linkUrl  分享链接
*/
+ (UIView *)getQRCodeView:(CGRect)frame linkUrl:(NSString *)linkUrl;

/*!
@method getQRCodeData:linkUrl
@abstract 给分享链接生成二维码Data
@param frame  view的大小
@param linkUrl  分享链接
*/
+ (NSData *)getQRCodeData:(CGRect)frame linkUrl:(NSString *)linkUrl;

/*!
@method showShare
@abstract App显示分享入口时调用此接口通知SDK
*/
+ (void)showShare;

/*!
@method openSharePage
@abstract 用户打开分享页面时调用此接口通知SDK
*/
+ (void)openSharePage;

/*!
@method startShare
@abstract 用户点击分享时调用此接口通知SDK
*/
+ (void)startShare;

/*!
@method shareSuccess
@abstract 用户分享成功后调用此接口通知SDK
*/
+ (void)shareSuccess;

@end

NS_ASSUME_NONNULL_END
