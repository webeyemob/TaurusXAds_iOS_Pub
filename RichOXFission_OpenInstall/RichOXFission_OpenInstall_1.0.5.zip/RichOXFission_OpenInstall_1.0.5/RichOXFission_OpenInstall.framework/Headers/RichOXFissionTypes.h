//
//  RichOXFissionTypes.h
//  RichOXFission
//
//  Created by RichOX on 2021/6/28.
//  Copyright © 2020 RichOX. All rights reserved.
//

/// Common
typedef const void *RichOXFissionTypeRef;

typedef const void *RichOXFissionTypeManagerRef;
typedef const void *RichOXFissionTypeMutableDictionaryRef;

/// RichOXFission
typedef const void *RichOXFissionTypeClientRef;

// getInstallParams callback
typedef void (*RichOXFissionGetInstallParamsCallback)(RichOXFissionTypeClientRef *clientRef, char *paramJson);

//genShareLink callback
typedef void (*RichOXFissionGenShareLinkCallback)(char *shareUrl);
typedef void (*RichOXFissionFailureCallback)(int code, char *message);




