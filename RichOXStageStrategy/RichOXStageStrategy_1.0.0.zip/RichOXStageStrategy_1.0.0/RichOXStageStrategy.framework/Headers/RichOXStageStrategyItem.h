//
//  RichOXStageStrategyItem.h
//  RichOX
//
//  Created by zena.tang on 2021/1/13.
//  Copyright © 2021 richox. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, RICHOX_STAGESTRATEGY_WITHDRAW_STATUS) {
    RICHOX_STAGESTRATEGY_WITHDRAW_STATUS_UNKNOWN                           = 0, //未提现
    RICHOX_STAGESTRATEGY_WITHDRAW_STATUS_FAIL                              = 1, //提现失败
    RICHOX_STAGESTRATEGY_WITHDRAW_STATUS_IN_PROGRESS                       = 2, //处理中
    RICHOX_STAGESTRATEGY_WITHDRAW_STATUS_AUDIT_UNPASS                      = 3, //审核驳回
    RICHOX_STAGESTRATEGY_WITHDRAW_STATUS_PAY_SUCCESS                       = 100 //提现成功
};

typedef NS_ENUM(NSInteger, RICHOX_STAGESTRATEGY_PRECONDITION_STATUS) {
    RICHOX_STAGESTRATEGY_PRECONDITION_STATUS_NO              = 0, //无前置条件
    RICHOX_STAGESTRATEGY_PRECONDITION_STATUS_OK              = 1  //前置红包已提现
};

typedef NS_ENUM(NSInteger, RICHOX_STAGESTRATEGY_WITHDRAW_TYPE) {
    RICHOX_STAGESTRATEGY_WITHDRAW_TYPE_NORMAL                              = 0,  //普通
    RICHOX_STAGESTRATEGY_WITHDRAW_TYPE_WX                                  = 1  //微信极速提现
    
};


@interface RichOXStageStrategyItem : NSObject

@property (nonatomic, readonly) int seq;                              //获取列表序列，从1开始
@property (nonatomic, strong, readonly) NSString *packageId;          //红包项Id
@property (nonatomic, strong, readonly) NSString *name;               //红包项名字
@property (nonatomic, readonly) RICHOX_STAGESTRATEGY_WITHDRAW_TYPE withdrawType;       //提现类型
@property (nonatomic, readonly) RICHOX_STAGESTRATEGY_PRECONDITION_STATUS precondition;           //前置条件
@property (nonatomic, readonly) NSInteger targetDegree;               //目标等级
@property (nonatomic, strong, readonly) NSString *detail;             //自定义信息
@property (nonatomic) double percent;                      //提现进度

@property (nonatomic) RICHOX_STAGESTRATEGY_WITHDRAW_STATUS withdrawStatus;   //提现状态

- (instancetype) initWithData:(NSDictionary *)dic;

@end

NS_ASSUME_NONNULL_END
