//
//  RichOXStageStrategy.h
//  RichOX
//
//  Created by zena.tang on 2021/1/13.
//  Copyright © 2021 richox. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RichOXStageStrategyItem.h"
#import <RichOXBase/RichOXError.h>
#import <RichOXBase/RichOXWithdrawInfo.h>

NS_ASSUME_NONNULL_BEGIN

typedef void (^RichOXGetStrategyListBlock)(NSArray <RichOXStageStrategyItem *> *strategyList);

@interface RichOXStageStrategyInstance:NSObject

@property (nonatomic, strong) NSString *strategyId;

+ (instancetype) getStageStrategy:(NSString *)strategyId;

/*!
@method syncList:failure
@abstract 此接口用于同步服务端阶梯红包用户的进度
@param success 成功的block，参数是用户当下的阶梯红包进度列表
@param failure 失败的block
*/
- (void)syncList:(RichOXGetStrategyListBlock)success failure:(RichOXFailureBlock)failure;

/*!
@method getListl
@abstract 此接口用于获取阶梯红包用户的缓存进度
@return 用户阶梯红包进度列表
*/
- (NSArray <RichOXStageStrategyItem *> *)getList;

/*!
@method doMission:missionId:bonus:success:failure
@abstract 此接口用于领取阶梯任务奖励值
@param itemId 阶梯红包id
@param missionId 任务id
@param bonus 客户端指定的奖励数量，仅对支持客户端控制的任务有效
@param success 成功的block，参数是用户领取奖励之后的阶梯红包进度列表
@param failure 失败的block
*/
- (void)doMission:(NSString *)itemId missionId:(NSString *)missionId bonus:(float)bonus success:(RichOXGetStrategyListBlock)success failure:(RichOXFailureBlock)failure;

/*!
@method withdraw:success:failure
@abstract 此接口用于用户对已完成进度的阶梯红包进行提现操作，客户端根据提现方式传入相应的请求参数
@param packetId 阶梯红包id
@param userDegree 用户等级
@param info 提现信息
@param success 成功的block，参数无
@param failure 失败的block
*/
- (void)withdraw:(NSString *)packetId userDegree: (int)userDegree info:(RichOXWithdrawInfo *)info success:(RichOXCommonSuccessBlock)success failure:(RichOXFailureBlock)failure;


@end

NS_ASSUME_NONNULL_END
