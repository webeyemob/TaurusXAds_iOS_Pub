//
//  TaurusXAdMediation_TikTok.h
//  TaurusXAdMediation_TikTok
//
//  Created by Mathew on 2019/7/3.
//  Copyright © 2019年 TXAD. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for TaurusXAdMediation_TikTok.
FOUNDATION_EXPORT double TaurusXAdMediation_TikTokVersionNumber;

//! Project version string for TaurusXAdMediation_TikTok.
FOUNDATION_EXPORT const unsigned char TaurusXAdMediation_TikTokVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TaurusXAdMediation_TikTok/PublicHeader.h>

#import <TaurusXAdMediation_TikTok/TXADTikTokExpressFeedListConfig.h>
#import <TaurusXAdMediation_TikTok/TXADTikTokSplashConfig.h>
