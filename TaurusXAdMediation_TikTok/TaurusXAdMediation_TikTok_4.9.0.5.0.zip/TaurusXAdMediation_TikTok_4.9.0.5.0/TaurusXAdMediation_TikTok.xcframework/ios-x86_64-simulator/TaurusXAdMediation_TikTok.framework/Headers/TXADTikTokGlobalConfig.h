//
//  TXADTikTokGlobalConfig.h
//  TaurusXAdMediation_TikTok
//
//  Created by TaurusXAds on 2021/3/1.
//  Copyright © 2021 TaurusXAds. All rights reserved.
//

#import <TaurusXAds/TaurusXAds.h>
#import "TXADTikTokDislikeAction.h"

NS_ASSUME_NONNULL_BEGIN

@interface TXADTikTokGlobalConfig : TXADNetworkConfig

@property (nonatomic) TXADTikTokDislikeAction dislikeAction;

@end

NS_ASSUME_NONNULL_END
