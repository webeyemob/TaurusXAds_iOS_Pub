//
//  TaurusXAdMediation_Nend.h
//  TaurusXAdMediation_Nend
//
//  Created by TaurusXAds on 2019/6/27.
//  Copyright © 2019年 TaurusXAds. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for TaurusXAdMediation_Nend.
FOUNDATION_EXPORT double TaurusXAdMediation_NendVersionNumber;

//! Project version string for TaurusXAdMediation_Nend.
FOUNDATION_EXPORT const unsigned char TaurusXAdMediation_NendVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TaurusXAdMediation_Nend/PublicHeader.h>

#import <TaurusXAdMediation_Nend/TXADNendAdMode.h>
