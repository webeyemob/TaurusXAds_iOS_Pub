//
//  TXADNendAdMode.h
//  TaurusXAdMediation_Nend
//
//  Created by TaurusXAds on 2020/2/3.
//  Copyright © 2020 TaurusXAds. All rights reserved.
//

typedef NS_ENUM(NSUInteger, TXADNendNativeMode) {
    TXAD_NEND_NATIVE_NORMAL = 0,
    TXAD_NEND_NATIVE_VIDEO = 1
};

typedef NS_ENUM(NSUInteger, TXADNendInterstitialMode) {
    TXAD_NEND_INTERSTITIAL_NORMAL = 0,
    TXAD_NEND_INTERSTITIAL_VIDEO = 1,
    TXAD_NEND_INTERSTITIAL_FULLSCREEN = 2
};
