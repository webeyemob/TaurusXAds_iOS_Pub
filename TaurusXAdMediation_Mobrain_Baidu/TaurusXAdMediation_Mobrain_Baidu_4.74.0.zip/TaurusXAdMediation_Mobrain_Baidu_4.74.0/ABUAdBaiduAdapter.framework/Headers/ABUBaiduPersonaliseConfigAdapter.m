//
//  ABUPanglePersonaliseConfigAdapter.m
//  ABUAdBaiduAdapter
//
//  Created by wangchao on 2020/5/20.
//  Copyright © 2020 wangchao. All rights reserved.
//


#import <BaiduMobAdSDK/BaiduMobAdSetting.h>
#import <ABUAdSDK/ABUAdapterPersonaliseConfigProtocol.h>

#import "ABUBaiduPersonaliseConfigAdapter.h"


@interface ABUBaiduPersonaliseConfigAdapter () <ABUAdapterPersonaliseConfigProtocol>

@end


@implementation ABUBaiduPersonaliseConfigAdapter

#pragma mark ---<ABUAdapterPersonaliseConfigProtocol>---
+ (void)setupPersonaliseConfiguration {
    // 第三方开发者在这设置BaiduMobAdSDK一些个性化配置
    // 不要在此写初始化代码！！！聚合SDK已完成初始化
//    [BaiduMobAdSetting sharedInstance].supportHttps = NO;
    [[BaiduMobAdSetting sharedInstance] setDebugLogEnable:YES];
}

@end
