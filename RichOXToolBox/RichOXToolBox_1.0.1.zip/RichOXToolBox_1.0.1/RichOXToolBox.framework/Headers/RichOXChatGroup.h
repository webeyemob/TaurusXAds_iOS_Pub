//
//  RichOXChatGroup.h
//  RichOXToolBox
//
//  Created by richox on 2021/7/21.
//  Copyright © 2021 richox. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <RichOXBase/RichOXError.h>
#import "RichOXGroupInfo.h"
#import "RichOXChatMessage.h"

NS_ASSUME_NONNULL_BEGIN

typedef void (^RichOXGetGroupInfoBlock)(NSArray<RichOXGroupInfo *> *groups);
typedef void (^RichOXGetChatMessageBlock)(NSArray<RichOXChatMessage *> *messages);
typedef void (^RichOXPostMessageBlock)(RichOXChatMessage *message);

@interface RichOXChatGroup : NSObject

/*!
@method setInterval:
@abstract 此接口用于设置聊天群自动拉取聊天记录时间间隔
@param interval 时间间隔，单位秒，默认10s
*/
+ (void)setInterval:(int)interval;

/*!
@method init
@abstract 此接口用于初始化聊天功能
@param 无
*/
+ (void)init;

/*!
@method getGroupInfo:failure
@abstract 此接口用于获取当前用户的聊天群群组信息
@param success 成功的block，参数是群组信息数组
@param failure 失败的block
*/
+ (void)getGroupInfo:(RichOXGetGroupInfoBlock)success failure:(RichOXFailureBlock _Nullable)failure;

/*!
@method getChatMessage:count:success:failure
@abstract 此接口用于获取指定群聊天记录
@param groupId 群组ID
@param count 获取消息条数
@param success 成功的block，参数是聊天消息数组
@param failure 失败的block
*/
+ (void)getChatMessage:(NSString *)groupId count:(int)count success:(RichOXGetChatMessageBlock)success failure:(RichOXFailureBlock _Nullable)failure;

/*!
@method sendChatMessage:nickName:avatar:type:content:success:failure
@abstract 此接口用于发送群消息
@param groupId 群组ID
@param nickName 发送人昵称
@param avatar 发送人头像
@param type 消息类型 10-消息 20-红包
@param content 消息内容
@param success 成功的block，参数是发送成功的聊天消息信息
@param failure 失败的block
*/
+ (void)sendChatMessage:(NSString *)groupId nickName:(NSString *)nickName avatar:(NSString * _Nullable)avatar type:(NSString *)type content:(NSString *)content success:(RichOXPostMessageBlock)success failure:(RichOXFailureBlock _Nullable)failure;

@end

NS_ASSUME_NONNULL_END
