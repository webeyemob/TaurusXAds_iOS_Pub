//
//  RichOXChatGroup.h
//  RichOXToolBox
//
//  Created by richox on 2021/7/21.
//  Copyright © 2021 richox. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <RichOXBase/RichOXError.h>
#import "RichOXGroupInfo.h"
#import "RichOXChatMessage.h"

NS_ASSUME_NONNULL_BEGIN

typedef void (^RichOXGetGroupInfoBlock)(NSArray<RichOXGroupInfo *> *groups);
typedef void (^RichOXGetChatMessageBlock)(NSArray<RichOXChatMessage *> *messages);
typedef void (^RichOXPostMessageBlock)(RichOXChatMessage *message);

@interface RichOXChatGroup : NSObject

+ (void)setInterval:(int)interval;
+ (void)init;

+ (void)getGroupInfo:(RichOXGetGroupInfoBlock)success failure:(RichOXFailureBlock _Nullable)failure;

+ (void)getChatMessage:(NSString *)groupId count:(int)count success:(RichOXGetChatMessageBlock)success failure:(RichOXFailureBlock _Nullable)failure;

+ (void)sendChatMessage:(NSString *)groupId nickName:(NSString *)nickName avatar:(NSString * _Nullable)avatar type:(NSString *)type content:(NSString *)content success:(RichOXPostMessageBlock)success failure:(RichOXFailureBlock _Nullable)failure;

@end

NS_ASSUME_NONNULL_END
