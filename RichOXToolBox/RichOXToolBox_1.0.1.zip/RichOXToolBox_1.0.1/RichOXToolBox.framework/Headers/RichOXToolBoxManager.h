//
//  RichOXToolBoxManager.h
//  RichOXToolBox
//
//  Created by richox on 2021/6/29.
//  Copyright © 2021 richox. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface RichOXToolBoxManager : NSObject

/*!
@method getSdkVersion
@abstract 获取SDK version
@return  SDK version string
*/
+ (NSString *)getSdkVersion;

@end

NS_ASSUME_NONNULL_END
