//
//  RichOXChatMessage.h
//  RichOXToolBox
//
//  Created by zena.tang on 2021/7/21.
//  Copyright © 2021 richox. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

#define RICHOX_CHAT_MESSAGE_TYPE_TEXT_PLAIN @"10"  //文字消息
#define RICHOX_CHAT_MESSAGE_TYPE_RED_PACKET @"20"   //红包消息


@interface RichOXChatMessage : NSObject

@property (nonatomic, strong) NSString *content; //聊天内容
@property (nonatomic, strong) NSString *groupId;  //聊天群Id

@property (nonatomic) long messageId;    // 消息ID
@property (nonatomic) long messageTime;  // 消息生成时间
@property (nonatomic, strong) NSString *messageType;  // 消息类型：红包@"20"、文字消息@"10"

@property (nonatomic, strong) NSString *senderId;     // 发送者用户Id
@property (nonatomic, strong) NSString *senderName;   // 发送者用户名
@property (nonatomic, strong, nullable) NSString *senderImage;  // 发送者头像

//@property (nonatomic) int messageStatus;   // 消息状态

- (instancetype)initWithData:(NSDictionary *)data;


@end

NS_ASSUME_NONNULL_END
