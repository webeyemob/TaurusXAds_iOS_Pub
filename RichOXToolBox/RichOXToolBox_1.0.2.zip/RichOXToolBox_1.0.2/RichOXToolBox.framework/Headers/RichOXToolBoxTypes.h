//
//  RichOXToolBoxTypes.h
//  RichOXToolBox
//
//  Created by RichOX on 2021/6/28.
//  Copyright © 2020 RichOX. All rights reserved.
//


//Common
typedef const void *RichOXToolBoxTypeRef;

// RichOXFailureBlock callback
typedef void (*RichOXToolBoxFailedCallback)(int code, char *message);


typedef const void *RichOXToolBoxPiggyBankObjectTypeArrayRef;
//RichOXPiggyBankObject
typedef const void *RichOXToolBoxPiggyBankObjectTypeRef;

// RichOXGetToolBoxSettingBlock callback
typedef void (*RichOXToolBoxQueryPiggyBankListCallback)(RichOXToolBoxPiggyBankObjectTypeArrayRef arrayRef);

// RichOXCommonSuccessBlock callback
typedef void (*RichOXToolBoxCommonSuccessBlock)(void);


//RichOXGroupInfo
typedef const void *RichOXToolBoxGroupInfoTypeRef;

//RichOXGroupInfo Array
typedef const void *RichOXToolBoxGroupInfoTypeArrayRef;

//RichOXChatMessage
typedef const void *RichOXToolBoxChatMessageTypeRef;

//RichOXChatMessage Array
typedef const void *RichOXToolBoxChatMessageTypeArrayRef;

//RichOXGetGroupInfoBlock
typedef void (*RichOXToolBoxGetGroupInfoCallback)(RichOXToolBoxGroupInfoTypeArrayRef arrayRef);

//RichOXGetChatMessageBlock
typedef void (*RichOXToolBoxGetChatMessageCallback)(RichOXToolBoxChatMessageTypeArrayRef arrayRef);

//RichOXPostMessageBlock
typedef void (*RichOXToolBoxPostMessageCallback)(RichOXToolBoxChatMessageTypeRef messageRef);


//RichOXUserPrivacyData
typedef const void *RichOXUserPrivacyDataRef;

// RichOXGetToolBoxSettingBlock callback
typedef void (*RichOXToolBoxQueryPrivacyDataCallback)(RichOXUserPrivacyDataRef dataRef);
