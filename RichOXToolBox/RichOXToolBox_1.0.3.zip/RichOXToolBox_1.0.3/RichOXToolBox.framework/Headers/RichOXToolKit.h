//
//  RichOXToolKit.h
//  RichOXToolBox
//
//  Created by RichOX on 2021/8/27.
//  Copyright © 2021 richox. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <RichOXBase/RichOXError.h>

NS_ASSUME_NONNULL_BEGIN

@interface RichOXUserPrivacyData : NSObject

@property (nonatomic, strong) NSString *key;                     //key，最大支持64字符
@property (nonatomic, strong, nullable) NSString *value;         //value, nil表示没有找到该值
@property (nonatomic) long createTime;                           //毫秒，创建时间
@property (nonatomic) long updateTime;                           //毫秒，更新时间

@end

typedef void (^RichOXToolKitQueryUserPrivacyKeyBlock)(RichOXUserPrivacyData *userData);

@interface RichOXToolKit : NSObject

/*!
@method saveUserPrivacyKey:value:success:failure
@abstract 此接口用于存储app内的用户的私有数据
@param key 数据key值，最大支持64字符
@param value 数据value值
@param success 成功的block，参数无
@param failure 失败的block
*/
+ (void)saveUserPrivacyKey:(NSString *)key value:(NSString *)value success:(RichOXCommonSuccessBlock)success failure:(RichOXFailureBlock _Nullable)failure;

/*!
@method queryUserPrivacyKey:success:failure
@abstract 此接口用于查询app内的用户的私有数据
@param key 数据key值
@param success 成功的block，参数是RichOXUserPrivacyData
@param failure 失败的block
*/
+ (void)queryUserPrivacyKey:(NSString *)key success:(RichOXToolKitQueryUserPrivacyKeyBlock)success failure:(RichOXFailureBlock _Nullable)failure;

@end

NS_ASSUME_NONNULL_END
