//
//  RichOXGroupInfo.h
//  RichOXToolBox
//
//  Created by richox on 2021/7/21.
//  Copyright © 2021 richox. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RichOXChatMessage.h"

NS_ASSUME_NONNULL_BEGIN

#define RICHOX_CHAT_GROUP_CATEGORY_GUIDE                  @"10" //引导群
#define RICHOX_CHAT_GROUP_CATEGORY_WORLD                  @"20"  //未使用
#define RICHOX_CHAT_GROUP_CATEGORY_REGION                 @"30"  //省份群
#define RICHOX_CHAT_GROUP_CATEGORY_AREA                   @"40"  //大区群
#define RICHOX_CHAT_GROUP_CATEGORY_UNKNOWN_REGION         @"50"   //未获取到地址位置的群
#define RICHOX_CHAT_GROUP_CATEGORY_FAMILY_MY              @"60"   //未使用
#define RICHOX_CHAT_GROUP_CATEGORY_FAMILY_TEACHER         @"70"   //未使用
#define RICHOX_CHAT_GROUP_CATEGORY_FAMILY_TEACHER_TEACHER @"80"   //未使用
#define RICHOX_CHAT_GROUP_CATEGORY_SYSTEM                 @"10000" //系统消息群


typedef NS_ENUM(int, RICHOX_TOOLBOX_GROUPINFO_RULE) {
    RICHOX_TOOLBOX_GROUPINFO_RULE_EMPTY            = 0,   //不可以收，也不可以发，比如引导群和系统消息群
    RICHOX_TOOLBOX_GROUPINFO_RULE_READ_ONLY        = 1,   //只可以收消息，暂时未使用
    RICHOX_TOOLBOX_GROUPINFO_RULE_WRITE_ONLY       = 2,   //只可以发消息，暂时未使用
    RICHOX_TOOLBOX_GROUPINFO_RULE_READ_AND_WRITE   = 3    //可以收，也可以发，比如同城群、大区群
};

@interface RichOXGroupInfo : NSObject

@property (nonatomic, strong, readonly) NSString *category; //群组类别,RICHOX_CHAT_GROUP_CATEGORY_
@property (nonatomic, strong, readonly) NSString *displayName; //默认群组名称，服务端提供，如华东大区群

@property (nonatomic, strong, readonly) NSString *groupId; // 群组Id

@property (nonatomic, strong) RichOXChatMessage *lastChatMessage; //当前群组最新一条消息

@property (nonatomic, strong, readonly) NSString *name; // 群名称，对应默认名称如华东大区群，该字段返回华东，客户端可自行定制

@property (nonatomic, readonly) RICHOX_TOOLBOX_GROUPINFO_RULE rule; // 群规则


- (instancetype)initWithData:(NSDictionary *)data;

@end

NS_ASSUME_NONNULL_END
