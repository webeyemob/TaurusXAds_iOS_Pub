//
//  RichOXToolBoxTypes.h
//  RichOXToolBox
//
//  Created by RichOX on 2021/6/28.
//  Copyright © 2020 RichOX. All rights reserved.
//


//Common
typedef const void *RichOXToolBoxTypeRef;

// RichOXFailureBlock callback
typedef void (*RichOXToolBoxFailedCallback)(int code, char *message);


typedef const void *RichOXToolBoxPiggyBankObjectTypeArrayRef;
//RichOXPiggyBankObject
typedef const void *RichOXToolBoxPiggyBankObjectTypeRef;

// RichOXGetToolBoxSettingBlock callback
typedef void (*RichOXToolBoxQueryPiggyBankListCallback)(RichOXToolBoxPiggyBankObjectTypeArrayRef arrayRef);

// RichOXCommonSuccessBlock callback
typedef void (*RichOXToolBoxCommonSuccessBlock)(void);





