//
//  TaurusXAdMediation_AppLovinMax.h
//  TaurusXAdMediation_AppLovinMax
//
//  Created by hang.wang on 2021/2/22.
//  Copyright © 2021 TaurusXAds. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for TaurusXAdMediation_AppLovinMax.
FOUNDATION_EXPORT double TaurusXAdMediation_AppLovinMaxVersionNumber;

//! Project version string for TaurusXAdMediation_AppLovinMax.
FOUNDATION_EXPORT const unsigned char TaurusXAdMediation_AppLovinMaxVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TaurusXAdMediation_AppLovinMax/PublicHeader.h>


