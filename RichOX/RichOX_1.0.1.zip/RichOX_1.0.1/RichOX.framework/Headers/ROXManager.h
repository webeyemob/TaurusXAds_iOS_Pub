//
//  ROXManager.h
//  RichOX
//
//  Created by zena.tang on 2020/4/7.
//  Copyright © 2020 RichOX. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "ROXTypes.h"

NS_ASSUME_NONNULL_BEGIN

typedef void (^ROXBindWeChatCallBack)(BOOL status);

typedef void (^ROXBindWeChatBlock)(ROXBindWeChatCallBack block);

typedef void (^ROXThirdEventBlock)(NSString *eventName, NSDictionary * _Nullable param);

@protocol ROXManagerDelegate  <NSObject>

@optional
- (void)trackCustomEvent: (NSDictionary *)message;

@end

@interface ROXManager : NSObject

@property (nonatomic, readonly) NSString *appId;
@property (nonatomic, readonly) NSString *userId;
@property (nonatomic, readonly) NSString *deviceId;

@property (nonatomic, weak) id<ROXManagerDelegate> delegate;

+ (instancetype)getManager;

+ (void) initWithAppId: (NSString *)appId userId: (NSString * _Nullable)userId  deviceId:(NSString * _Nullable)deviceId;

+ (void)setEventBlock:(ROXThirdEventBlock)block;
+ (void)setBindWeChatBlock:(ROXBindWeChatBlock)block;

+ (void) setLogEnable:(BOOL)enable;
+ (BOOL) isLogEnable;

+ (void) setTestMode:(BOOL)testMode;
+ (BOOL) isTestMode;

+ (int)getSdkVersion;

#pragma mark - Unity
@property(nonatomic, assign) ROXTypeEventClientRef _Nullable* _Nullable eventClient;
@property(nonatomic, assign) ROXEventCallback eventCallback;

@end

NS_ASSUME_NONNULL_END
