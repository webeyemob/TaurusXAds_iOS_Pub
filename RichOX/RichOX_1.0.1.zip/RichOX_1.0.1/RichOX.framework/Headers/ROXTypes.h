//
//  ROXTypes.h
//  RichOX
//
//  Created by RichOX on 2020/7/16.
//  Copyright © 2020 RichOX. All rights reserved.
//

/// Common
typedef const void *ROXTypeRef;


// Event Statistic
typedef const void *ROXTypeEventClientRef;
typedef const void *ROXTypeEventRef;
typedef void (*ROXEventCallback)(ROXTypeEventClientRef *eventClientRef, char *eventName, char *value, char *param);


/// FloatScene
// 对 Unity 中 FloatScene 和 FloatSceneClient 的引用。
typedef const void *ROXTypeFloatSceneClientRef;
typedef const void *ROXTypeFloatSceneRef;
// iOS ROXFloatScene 加载后回调 Unity 的接口。
typedef void (*ROXFloatSceneDidReceiveCallback)(ROXTypeFloatSceneClientRef *floatSceneClient);
typedef void (*ROXFloatSceneDidFailToReceiveWithErrorCallback)(ROXTypeFloatSceneClientRef *floatSceneClient, int error, char *message);
typedef void (*ROXFloatSceneWillPresentScreenCallback)(ROXTypeFloatSceneClientRef *floatSceneClient);
typedef void (*ROXFloatSceneDidDismissScreenCallback)(ROXTypeFloatSceneClientRef *floatSceneClient);
typedef void (*ROXFloatSceneWillLeaveApplicationCallback)(ROXTypeFloatSceneClientRef *floatSceneClient);


/// DialogScene
// 对 Unity 中 DialogScene 和 DialogSceneClient 的引用。
typedef const void *ROXTypeDialogSceneClientRef;
typedef const void *ROXTypeDialogSceneRef;
// iOS ROXDialogScene 加载后回调 Unity 的接口。
typedef void (*ROXDialogSceneDidReceiveCallback)(ROXTypeDialogSceneClientRef *DialogSceneClient);
typedef void (*ROXDialogSceneDidFailToReceiveWithErrorCallback)(ROXTypeDialogSceneClientRef *DialogSceneClient, int error, char *message);
typedef void (*ROXDialogSceneWillPresentScreenCallback)(ROXTypeDialogSceneClientRef *DialogSceneClient);
typedef void (*ROXDialogSceneDidDismissScreenCallback)(ROXTypeDialogSceneClientRef *DialogSceneClient);
typedef void (*ROXDialogSceneWillLeaveApplicationCallback)(ROXTypeDialogSceneClientRef *DialogSceneClient);
