//
//  ROXSceneDelegate.h
//  ROX
//
//  Created by zena.tang on 2020/6/22.
//  Copyright © 2020 RichOX. All rights reserved.
//

#ifndef ROXSceneDelegate_h
#define ROXSceneDelegate_h

#import "ROXError.h"

typedef NS_ENUM(NSInteger, ROX_SCENE_ENTRANCE_TYPE) {
    ROX_SCENE_ENTRANCE_TYPE_NO =0, // 无
    ROX_SCENE_ENTRANCE_TYPE_FLOATICON =1, // 浮标
    ROX_SCENE_ENTRANCE_TYPE_BANNER = 2, // banner
    ROX_SCENE_ENTRANCE_TYPE_DIALOG  = 3, // dialog
    ROX_SCENE_ENTRANCE_TYPE_TAB  = 4, // tab
};

@protocol ROXSceneDelegate  <NSObject>

@optional
- (void)sceneDidLoaded:(NSObject *)scene;
- (void)scene:(NSObject *)scene didLoadedFailWithError:(ROXError *)error;
- (void)sceneWillPresentScreen:(NSObject *)scene;
- (void)sceneDidPresentScreen:(NSObject *)scene;
- (void)sceneWillDismissScreen:(NSObject *)scene;
- (void)sceneDidDismissScreen:(NSObject *)scene;

@end

#endif /* ROXSceneDelegate_h */
