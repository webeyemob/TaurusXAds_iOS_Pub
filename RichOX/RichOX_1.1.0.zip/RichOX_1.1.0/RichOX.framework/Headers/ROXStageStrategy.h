//
//  ROXStageStrategy.h
//  RichOX
//
//  Created by zena.tang on 2021/1/13.
//  Copyright © 2021 TaurusXAds. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ROXStageStrategyItem.h"
#import "ROXWithdrawInfo.h"
#import "ROXError.h"

NS_ASSUME_NONNULL_BEGIN

typedef void (^ROXGetStrategyListBlock)(NSArray <ROXStageStrategyItem *> *strategyList);
typedef void (^ROXCommonSuccessBlock)(void);

@interface ROXStageStrategy:NSObject

@property (nonatomic, strong) NSString *strategyId;

+ (instancetype) getStageStrategy:(NSString *)strategyId;

- (void)syncList:(ROXGetStrategyListBlock)success fail:(ROXFailureBlock)fail;
- (NSArray <ROXStageStrategyItem *> *)getList;

- (void)doMission:(NSString *)itemId missionId:(NSString *)missionId bonus:(float)bouns success:(ROXGetStrategyListBlock)success fail:(ROXFailureBlock)fail;

- (void)withdraw:(ROXWithdrawInfo *)info success:(ROXCommonSuccessBlock)success fail:(ROXFailureBlock)fail;


@end

NS_ASSUME_NONNULL_END
