//
//  ROXManager.h
//  RichOX
//
//  Created by zena.tang on 2020/4/7.
//  Copyright © 2020 RichOX. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "ROXTypes.h"

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, ROX_GIFT_TYPE) {
    ROX_GIFT_TYPE_COIN           = 0, // 金币
    ROX_GIFT_TYPE_CHANGE         = 1, // 零钱
    ROX_GIFT_TYPE_POINTS         = 2, // 积分
};

typedef void (^ROXBindWeChatCallBack)(BOOL status, NSString *msg);

typedef void (^ROXBindWeChatBlock)(ROXBindWeChatCallBack block);

typedef void (^ROXThirdEventBlock)(NSString *eventName, NSDictionary * _Nullable param);

typedef void (^ROXGiftUpdateBlock)(ROX_GIFT_TYPE type, NSString *activityTitle, NSInteger amount);

@protocol ROXManagerDelegate  <NSObject>

@optional
- (void)trackCustomEvent: (NSDictionary *)message;

@end

@interface ROXManager : NSObject

@property (nonatomic, readonly) NSString *appId;
@property (nonatomic, readonly) NSString *userId;
@property (nonatomic, readonly) NSString *deviceId;
@property (nonatomic, readonly) NSInteger appVerCode;

@property (nonatomic, weak) id<ROXManagerDelegate> delegate;

+ (instancetype)getManager;

+ (BOOL)richOXInited;

+ (void) initWithAppId: (NSString *)appId userId: (NSString * _Nullable)userId  deviceId:(NSString * _Nullable)deviceId;

+ (void)setEventBlock:(ROXThirdEventBlock)block;
+ (void)setBindWeChatBlock:(ROXBindWeChatBlock)block;
+ (void)setGiftUpdateBlock:(ROXGiftUpdateBlock)block;


+ (void) setLogEnable:(BOOL)enable;
+ (BOOL) isLogEnable;

+ (void) setTestMode:(BOOL)testMode;
+ (BOOL) isTestMode;

+ (void) setAppVerCode:(NSInteger) appVerCode;

+ (int)getSdkVersion;

#pragma mark - Unity
@property(nonatomic, assign) ROXTypeEventClientRef _Nullable* _Nullable eventClient;
@property(nonatomic, assign) ROXEventCallback eventCallback;

@end

NS_ASSUME_NONNULL_END
