//
//  ROXUnityManager.h
//  RichOX
//
//  Created by RichOX on 2020/8/17.
//  Copyright © 2020 richox. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ROXTypes.h"

NS_ASSUME_NONNULL_BEGIN

@interface ROXUnityManager : NSObject

+ (ROXUnityManager *)sharedInstance;

@property(nonatomic, assign) ROXTypeManagerClientRef _Nullable* _Nullable managerClient;

@property(nonatomic, assign) ROXEventCallback eventCallback;
@property(nonatomic, assign) ROXUnityBindWeChatCallback unityBindWeChatCallback;
@property(nonatomic, assign) ROXGiftUpdateCallback giftUpdateCallback;

@property(nonatomic, assign) ROXUnityShareCallback unityShareCallback;
@property(nonatomic, assign) ROXUnityGetShareLinkCallback unityGetShareLinkCallback;

- (void)notifyBindWeChatStatus:(BOOL)status withResult:(NSString *)result;
- (void)notifyGetShareLinkResult:(NSString *)shareUrl code:(int)code message:(NSString *)message;
- (void)notifyShareResult:(int)code message:(NSString *)message;

@end

NS_ASSUME_NONNULL_END
