//
//  ROXManager.h
//  RichOX
//
//  Created by RichOX on 2020/4/7.
//  Copyright © 2020 RichOX. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "ROXTypes.h"
#import <RichOXBase/RichOXBaseManager.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, ROX_GIFT_TYPE) {
    ROX_GIFT_TYPE_COIN           = 0, // 金币
    ROX_GIFT_TYPE_CHANGE         = 1, // 零钱
    ROX_GIFT_TYPE_POINTS         = 2, // 积分
};

typedef void (^ROXBindWeChatCallBack)(BOOL status, NSString *msg);

typedef void (^ROXBindWeChatBlock)(ROXBindWeChatCallBack block);


typedef void (^ROXGiftUpdateBlock)(ROX_GIFT_TYPE type, NSString *activityTitle, NSInteger amount);

typedef void (^ROXGetShareLinkCallBack)(NSString *_Nullable shareLink, int code, NSString *_Nonnull message); //code为0表示成功，否则失败
typedef void (^ROXGetShareLinkBlock)(NSString *host, NSDictionary *shareParam, ROXGetShareLinkCallBack block);

typedef void (^ROXShareCallBack)(int code, NSString *_Nonnull message); //code为0表示成功，否则失败
typedef void (^ROXShareBlock)(NSString *_Nullable title, NSString *_Nullable content, NSString *_Nullable imageBase64Str, NSString *_Nullable shareUrl, ROXShareCallBack block);

@protocol ROXManagerDelegate  <NSObject>

@optional
- (void)trackCustomEvent: (NSDictionary *)message;

@end

@interface ROXManager : NSObject

@property (nonatomic, readonly) NSString *appId;

@property (nonatomic, weak) id<ROXManagerDelegate> delegate;

+ (instancetype)getManager;

+ (BOOL)richOXInited;

/**
@deprecated Please use [RichOXBaseManager initWithAppId:initSuccess:] instead
*/

+ (void) initWithAppId: (NSString *)appId userId: (NSString * _Nullable)userId __deprecated_msg("this method has deprecated, please use [RichOXBaseManager initWithAppId:initSuccess:] instead");

/**
@deprecated Please use [RichOXBaseManager initWithAppId:initSuccess:], [RichOXBaseManager setDeviceId]; and  [RichOXBaseManager saveUserId]; instead
*/
+ (void) initWithAppId: (NSString *)appId userId: (NSString * _Nullable)userId  deviceId:(NSString * _Nullable)deviceId  __deprecated_msg("this method has deprecated, please use [RichOXBaseManager initWithAppId:initSuccess:] and [RichOXBaseManager setDeviceId] and [RichOXBaseManager saveUserId] instead");

+ (void)setEventBlock:(RichOXThirdEventBlock)block;
+ (void)setBindWeChatBlock:(ROXBindWeChatBlock)block;
+ (void)setGiftUpdateBlock:(ROXGiftUpdateBlock)block;

//分享活动需要设置
+ (void)setGetShareLinkBlock:(ROXGetShareLinkBlock)block;
+ (void)setShareBlock:(ROXShareBlock)block;

//海外产品有语言设置需求的可以自己设置语言吗，默认使用设备语言
+ (void)setLanguageCode:(NSString *)languageCode;
+ (NSString *)getLanguageCode; //zh-Hans-US

+ (int)getSdkVersionCode;
+ (NSString *)getSdkVersion;

+ (void) start: (NSString *)appId;

/**
@deprecated Please use [RichOXBaseManager setWDExtendInfo:]; instead
*/
+ (void)setWDExtendInfo:(NSString *)extendInfo __deprecated_msg("this method has deprecated, please use [RichOXBaseManager setWDExtendInfo:] instead");

/**
@deprecated Please use [RichOXBaseManager setLogEnable:]; instead
*/
+ (void) setLogEnable:(BOOL)enable __deprecated_msg("this method has deprecated, please use [RichOXBaseManager setLogEnable:] instead");
/**
@deprecated Please use [RichOXBaseManager isLogEnable];  instead
*/
+ (BOOL) isLogEnable __deprecated_msg("this method has deprecated, please use [RichOXBaseManager isLogEnable] instead");
/**
@deprecated Please use [RichOXBaseManager setTestMode:] instead
*/
+ (void) setTestMode:(BOOL)testMode __deprecated_msg("this method has deprecated, please use [RichOXBaseManager setTestMode:] instead");
/**
@deprecated Please use [RichOXBaseManager isTestMode]; instead
*/
+ (BOOL) isTestMode __deprecated_msg("this method has deprecated, please use [RichOXBaseManager isTestMode] instead");

/**
@deprecated Please use [RichOXBaseManager setAppVerCode:] instead
*/
+ (void) setAppVerCode:(NSInteger) appVerCode __deprecated_msg("this method has deprecated, please use [RichOXBaseManager setAppVerCode:] instead");

/**
@deprecated Please use [RichOXBaseManager setFissionPlatform];  instead
*/
+ (void) setFissionPlatform:(NSString *)platform __deprecated_msg("this method has deprecated, please use [RichOXBaseManager setFissionPlatform:] instead");

@end

NS_ASSUME_NONNULL_END
