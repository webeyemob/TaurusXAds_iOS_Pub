//
//  ROXAdUnitObject.h
//  RichOX
//
//  Created by zena.tang on 2020/6/18.
//  Copyright © 2020 RichOX. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, ROX_ADUNIT_ADTYPE) {
    ROX_ADUNIT_ADTYPE_UNKNOWN = 0,
    ROX_ADUNIT_ADTYPE_BANNER = 1,
    ROX_ADUNIT_ADTYPE_INTERSTITIAL = 2,
    ROX_ADUNIT_ADTYPE_NATIVE = 3,
    ROX_ADUNIT_ADTYPE_REWARDED_VIDEO = 4,
    ROX_ADUNIT_ADTYPE_MIXVIEW = 5,
    ROX_ADUNIT_ADTYPE_MIXFULLSCREEN = 6,
    ROX_ADUNIT_ADTYPE_SPLASH = 7,
    ROX_ADUNIT_ADTYPE_FEEDLIST = 8
};

@interface ROXAdUnitObject : NSObject

@property (nonatomic, readonly) NSString *key;
@property (nonatomic, readonly) NSString *adUnitId;
@property (nonatomic, readonly) ROX_ADUNIT_ADTYPE adType;
@property (nonatomic, strong) NSString *layoutClassName;

- (instancetype)initWithAdUnitData: (NSDictionary *)data;

@end


NS_ASSUME_NONNULL_END
