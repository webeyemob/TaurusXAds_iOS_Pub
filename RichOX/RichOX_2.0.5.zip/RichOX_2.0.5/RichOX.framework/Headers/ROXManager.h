//
//  ROXManager.h
//  RichOX
//
//  Created by RichOX on 2020/4/7.
//  Copyright © 2020 RichOX. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "ROXTypes.h"
#import <RichOXBase/RichOXBaseManager.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, ROX_GIFT_TYPE) {
    ROX_GIFT_TYPE_COIN           = 0, // 金币
    ROX_GIFT_TYPE_CHANGE         = 1, // 零钱
    ROX_GIFT_TYPE_POINTS         = 2, // 积分
};

typedef void (^ROXBindWeChatCallBack)(BOOL status, NSString *msg);

typedef void (^ROXBindWeChatBlock)(ROXBindWeChatCallBack block);


typedef void (^ROXGiftUpdateBlock)(ROX_GIFT_TYPE type, NSString *activityTitle, NSInteger amount);

typedef void (^ROXGetShareLinkCallBack)(NSString *_Nullable shareLink, int code, NSString *_Nonnull message); //code为0表示成功，否则失败
typedef void (^ROXGetShareLinkBlock)(NSString *host, NSDictionary *shareParam, ROXGetShareLinkCallBack block);

typedef void (^ROXShareCallBack)(int code, NSString *_Nonnull message); //code为0表示成功，否则失败
typedef void (^ROXShareBlock)(NSString *title, NSString *content, NSString *imageBase64Str, ROXShareCallBack block);

@protocol ROXManagerDelegate  <NSObject>

@optional
- (void)trackCustomEvent: (NSDictionary *)message;

@end

@interface ROXManager : NSObject

@property (nonatomic, readonly) NSString *appId;

@property (nonatomic, weak) id<ROXManagerDelegate> delegate;

+ (instancetype)getManager;

+ (BOOL)richOXInited;

+ (void) initWithAppId: (NSString *)appId userId: (NSString * _Nullable)userId __deprecated;

/**
@deprecated Please use [RichOXBaseManager setDeviceId]; and  [RichOXBaseManager saveUserId]; replace
*/
+ (void) initWithAppId: (NSString *)appId userId: (NSString * _Nullable)userId  deviceId:(NSString * _Nullable)deviceId  __deprecated;

+ (void)setEventBlock:(RichOXThirdEventBlock)block;
+ (void)setBindWeChatBlock:(ROXBindWeChatBlock)block;
+ (void)setGiftUpdateBlock:(ROXGiftUpdateBlock)block;

//分享活动需要设置
+ (void)setGetShareLinkBlock:(ROXGetShareLinkBlock)block;
+ (void)setShareBlock:(ROXShareBlock)block;

//海外产品有语言设置需求的可以自己设置语言吗，默认使用设备语言
+ (void)setLanguageCode:(NSString *)languageCode;
+ (NSString *)getLanguageCode; //zh-Hans-US

+ (int)getSdkVersionCode;
+ (NSString *)getSdkVersion;

+ (void) start: (NSString *)appId;

/**
@deprecated Please use [RichOXBaseManager setWDExtendInfo:]; replace
*/
+ (void)setWDExtendInfo:(NSString *)extendInfo __deprecated;

/**
@deprecated Please use [RichOXBaseManager setLogEnable:]; replace
*/
+ (void) setLogEnable:(BOOL)enable __deprecated;
/**
@deprecated Please use [RichOXBaseManager isLogEnable];  replace
*/
+ (BOOL) isLogEnable __deprecated;
/**
@deprecated Please use [RichOXBaseManager setTestMode:] replace
*/
+ (void) setTestMode:(BOOL)testMode __deprecated;
/**
@deprecated Please use [RichOXBaseManager setDeviceId]; and  [RichOXBaseManager saveUserId]; replace
*/
+ (BOOL) isTestMode __deprecated;

/**
@deprecated Please use [RichOXBaseManager setAppVerCode:] replace
*/
+ (void) setAppVerCode:(NSInteger) appVerCode __deprecated;

/**
@deprecated Please use [RichOXBaseManager setFissionPlatform];  replace
*/
+ (void) setFissionPlatform:(NSString *)platform __deprecated;

@end

NS_ASSUME_NONNULL_END
