//
//  ROXTabView.h
//  RichOX
//
//  Created by zena.tang on 2020/6/29.
//  Copyright © 2020 TaurusXAds. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ROXSceneDelegate.h"

NS_ASSUME_NONNULL_BEGIN

@interface ROXTabView : UIView

@property (nonatomic, weak) id<ROXSceneDelegate> delegate;

- (instancetype)initWithSceneEntryId: (NSString *)sceneEntryId containerView: (UIView *) containerView viewController: (UIViewController *)viewController delegate: (id<ROXSceneDelegate> _Nullable)delegate;

- (void)load;

- (BOOL)sceneRenderReady;

- (NSString * _Nullable)getTabTitle;
- (NSString *_Nullable)getTabIcon;

- (void)start;
- (void)pause;
- (void)resume;

@end

NS_ASSUME_NONNULL_END
