//
//  ROXEntranceView.h
//  RichOX
//
//  Created by zena.tang on 2020/6/16.
//  Copyright © 2020 TaurusXAds. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ROXScenceDelegate.h"


NS_ASSUME_NONNULL_BEGIN

@interface ROXEntranceView : UIView

@property (nonatomic, weak) id<ROXScenceDelegate> delegate;

- (instancetype)initWithScenceEntryId: (NSString *)scenceEntryId entranceType: (ROX_SCENCE_ENTRANCE_TYPE)entranceType containerView: (UIView *) containerView viewController: (UIViewController *)viewController delegate: (id<ROXScenceDelegate>)delegate;

- (void)load;

- (BOOL)scenceRenderReady;

@end

NS_ASSUME_NONNULL_END
