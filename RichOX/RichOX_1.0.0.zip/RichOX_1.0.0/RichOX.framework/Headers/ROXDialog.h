//
//  ROXDialog.h
//  RichOX
//
//  Created by zena.tang on 2020/6/29.
//  Copyright © 2020 TaurusXAds. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ROXScenceDelegate.h"

NS_ASSUME_NONNULL_BEGIN

@interface ROXDialog : NSObject

@property (nonatomic, weak) id<ROXScenceDelegate> delegate;

- (instancetype)initWithScenceEntryId: (NSString *)scenceEntryId delegate: (id<ROXScenceDelegate> _Nullable)delegate;

- (void)load;

- (BOOL)scenceRenderReady;

- (void)showFromViewController: (UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
