//
//  ROXBannerView.h
//  RichOX
//
//  Created by zena.tang on 2020/6/28.
//  Copyright © 2020 TaurusXAds. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ROXEntranceView.h"

NS_ASSUME_NONNULL_BEGIN

@interface ROXBannerView : ROXEntranceView

- (instancetype)initWithSceneEntryId: (NSString *)sceneEntryId containerView: (UIView *) containerView viewController: (UIViewController *)viewController delegate: (id<ROXSceneDelegate> _Nullable)delegate;

- (void)load;

- (BOOL)sceneRenderReady;


@end

NS_ASSUME_NONNULL_END
