//
//  ROXError.h
//  RichOX
//
//  Created by zena.tang on 2020/4/23.
//  Copyright © 2020 TaurusXAds. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, ROX_ERROR) {
    ROX_ERROR_CUSTOM =0, // custom错误
    ROX_ERROR_RENDER = 1, // 渲染错误
    ROX_ERROR_READY  = 2, // 准备错误
    ROX_ERROR_INIT = 3,     // 初始化错误
};

@interface ROXError : NSObject

@property (readonly, copy) NSString   *message;
@property (readonly)       NSInteger  errorCode;
@property (readonly)       ROX_ERROR  errorType;

+ (instancetype)renderError: (NSInteger)code message:(NSString *)message;
+ (instancetype)readyError: (NSInteger)code message:(NSString *)message;
+ (instancetype)customError: (NSInteger)code message:(NSString *)message;
+ (instancetype)initError;

@end

NS_ASSUME_NONNULL_END
