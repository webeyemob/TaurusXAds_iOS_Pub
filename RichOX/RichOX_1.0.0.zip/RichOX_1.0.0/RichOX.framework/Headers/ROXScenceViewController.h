//
//  ROXScenceViewController.h
//  RichOX
//
//  Created by zena.tang on 2020/6/16.
//  Copyright © 2020 TaurusXAds. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ROXScenceDelegate.h"

NS_ASSUME_NONNULL_BEGIN


@interface ROXScenceViewController : UIViewController

@property (nonatomic, weak) id<ROXScenceDelegate> delegate;

- (instancetype)initWithScenceEntryId: (NSString *)scenceEntryId delegate: (id<ROXScenceDelegate> _Nullable)delegate;

- (instancetype)initWithScenceObject: (NSObject *)scenceObject delegate: (id<ROXScenceDelegate> _Nullable)delegate;

- (void)load;

- (BOOL)scenceRenderReady;

- (void)presentFromRootViewController:(UIViewController *)rootViewController;

@end

NS_ASSUME_NONNULL_END
