//
//  ROXScenceDelegate.h
//  ROX
//
//  Created by zena.tang on 2020/6/22.
//  Copyright © 2020 TaurusXAds. All rights reserved.
//

#ifndef ROXScenceDelegate_h
#define ROXScenceDelegate_h

#import "ROXError.h"

typedef NS_ENUM(NSInteger, ROX_SCENCE_ENTRANCE_TYPE) {
    ROX_SCENCE_ENTRANCE_TYPE_NO =0, // 无
    ROX_SCENCE_ENTRANCE_TYPE_FLOATICON =1, // 浮标
    ROX_SCENCE_ENTRANCE_TYPE_BANNER = 2, // banner
    ROX_SCENCE_ENTRANCE_TYPE_DIALOG  = 3, // dialog
    ROX_SCENCE_ENTRANCE_TYPE_TAB  = 4, // tab
};


@protocol ROXScenceDelegate  <NSObject>

@optional
- (void)scenceDidLoaded:(NSObject *)scence;
- (void)scence:(NSObject *)scence didLoadedFailWithError:(ROXError *)error;
- (void)scenceWillPresentScreen:(NSObject *)scence;
- (void)scenceDidPresentScreen:(NSObject *)scence;
- (void)scenceWillDismissScreen:(NSObject *)scence;
- (void)scenceDidDismissScreen:(NSObject *)scence;

@end

#endif /* ROXScenceDelegate_h */
