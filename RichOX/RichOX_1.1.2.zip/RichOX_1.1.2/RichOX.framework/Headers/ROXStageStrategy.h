//
//  ROXStageStrategy.h
//  RichOX
//
//  Created by zena.tang on 2021/1/13.
//  Copyright © 2021 TaurusXAds. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ROXStageStrategyItem.h"
#import "ROXWithdrawInfo.h"
#import "ROXError.h"

NS_ASSUME_NONNULL_BEGIN

typedef void (^ROXGetStrategyListBlock)(NSArray <ROXStageStrategyItem *> *strategyList);
typedef void (^ROXCommonSuccessBlock)(void);

@interface ROXStageStrategy:NSObject

@property (nonatomic, strong) NSString *strategyId;

+ (instancetype) getStageStrategy:(NSString *)strategyId;

/*!
@method syncList:fail
@abstract 此接口用于同步服务端阶梯红包用户的进度
@param success 成功的block，参数是用户当下的阶梯红包进度列表
@param fail 失败的block
*/
- (void)syncList:(ROXGetStrategyListBlock)success fail:(ROXFailureBlock)fail;

/*!
@method getListl
@abstract 此接口用于获取阶梯红包用户的缓存进度
@return 用户阶梯红包进度列表
*/
- (NSArray <ROXStageStrategyItem *> *)getList;

/*!
@method doMission:missionId:bonus:success:fail
@abstract 此接口用于领取阶梯任务奖励值
@param itemId 阶梯红包id
@param missionId 任务id
@param bonus 客户端指定的奖励数量，仅对支持客户端控制的任务有效
@param success 成功的block，参数是用户领取奖励之后的阶梯红包进度列表
@param fail 失败的block
*/
- (void)doMission:(NSString *)itemId missionId:(NSString *)missionId bonus:(float)bonus success:(ROXGetStrategyListBlock)success fail:(ROXFailureBlock)fail;

/*!
@method withdraw:success:fail
@abstract 此接口用于用户对已完成进度的阶梯红包进行提现操作，客户端根据提现方式传入相应的请求参数
@param info 提现信息
@param success 成功的block，参数无
@param fail 失败的block
*/
- (void)withdraw:(ROXWithdrawInfo *)info success:(ROXCommonSuccessBlock)success fail:(ROXFailureBlock)fail;


@end

NS_ASSUME_NONNULL_END
