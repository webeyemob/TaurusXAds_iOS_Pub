//
//  ROXDialog.h
//  RichOX
//
//  Created by zena.tang on 2020/6/29.
//  Copyright © 2020 RichOX. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ROXSceneDelegate.h"

NS_ASSUME_NONNULL_BEGIN

@interface ROXDialog : NSObject

@property (nonatomic, weak) id<ROXSceneDelegate> delegate;

- (instancetype)initWithSceneEntryId: (NSString *)sceneEntryId delegate: (id<ROXSceneDelegate> _Nullable)delegate;

- (void)load;

- (BOOL)sceneRenderReady;

- (void)showFromViewController: (UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
