//
//  TaurusXAdMediation_AppLovin.h
//  TaurusXAdMediation_AppLovin
//
//  Created by TaurusXAds on 2018/9/28.
//

#import <UIKit/UIKit.h>

//! Project version number for TaurusXAdMediation_AppLovin.
FOUNDATION_EXPORT double TaurusXAdMediation_AppLovinVersionNumber;

//! Project version string for TaurusXAdMediation_AppLovin.
FOUNDATION_EXPORT const unsigned char TaurusXAdMediation_AppLovinVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TaurusXAdMediation_AppLovin/PublicHeader.h>

#import <TaurusXAdMediation_AppLovin/TXADAppLovinGlobalConfig.h>
#import <TaurusXAdMediation_AppLovin/TXADAppLovinNativeConfig.h>
