//
//  TXADAppLovinGlobalConfig.h
//  TaurusXAdMediation_AppLovin
//
//  Created by TaurusXAds on 2020/2/23.
//  Copyright © 2020 TaurusXAds. All rights reserved.
//

#import <TaurusXAds/TaurusXAds.h>

NS_ASSUME_NONNULL_BEGIN

@interface TXADAppLovinGlobalConfig : TXADNetworkConfig

@end

NS_ASSUME_NONNULL_END
