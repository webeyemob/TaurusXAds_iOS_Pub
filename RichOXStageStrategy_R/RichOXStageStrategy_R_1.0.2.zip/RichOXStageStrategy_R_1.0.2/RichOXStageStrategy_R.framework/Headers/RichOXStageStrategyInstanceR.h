//
//  RichOXStageStrategyR.h
//  RichOX
//
//  Created by zena.tang on 2021/1/13.
//  Copyright © 2021 richox. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <RichOXBase/RichOXError.h>
#import <RichOXBase/RichOXWithdrawInfo.h>
#import "RichOXStageStrategySetting.h"

NS_ASSUME_NONNULL_BEGIN

typedef void (^RichOXGetStrategySettingBlock)(RichOXStageStrategySetting *strategySetting);
typedef void (^RichOXGetStrategyProgressBlock)(RichOXStageStrategyStatus *status);

typedef void (^RichOXStrategyDoTaskBlock)(RichOXStageStrategyTaskResult *result);

@interface RichOXStageStrategyInstanceR:NSObject

@property (nonatomic, strong) NSString *strategyId;

+ (instancetype) getStageStrategy:(NSString *)strategyId;

/*!
@method syncList:failure
@abstract 此接口用于同步服务端阶梯红包的配置
@param success 成功的block，参数是用户当下的阶梯红包配置列表
@param failure 失败的block
*/
- (void)syncList:(RichOXGetStrategySettingBlock)success failure:(RichOXFailureBlock)failure;

/*!
@method syncCurrentPrize:failure
@abstract 此接口用于获取阶梯策略用户当前的资产数
@param success 成功的block，参数是用户当下的阶梯红包配置列表
@param failure 失败的block
*/
- (void)syncCurrentPrize: (RichOXGetStrategyProgressBlock)success failure:(RichOXFailureBlock)failure;

/*!
@method doTask:taskId:bonus:success:failure
@abstract 此接口用于领取阶梯任务奖励值
@param missionId 任务id
@param prizeAmount 客户端指定的奖励数量,如果是固定奖励可以将此值设为0
@param success 成功的block，参数是用户领取奖励之后的资产数
@param failure 失败的block
*/
- (void)doMission:(NSString *)missionId prizeAmount:(double)prizeAmount success:(RichOXStrategyDoTaskBlock)success failure:(RichOXFailureBlock)failure;

/*!
@method withdraw:userTarget:info:success:failure
@abstract 此接口用于用户对已完成进度的阶梯红包进行提现操作，客户端根据提现方式传入相应的请求参数
@param packetId 提现任务ID
@param info 提现信息
@param success 成功的block，参数无
@param failure 失败的block
*/
- (void)withdraw:(NSString *)packetId info:(RichOXWithdrawInfo *)info success:(RichOXCommonSuccessBlock)success failure:(RichOXFailureBlock)failure;


@end

NS_ASSUME_NONNULL_END
