//
//  RichOXStageStrategyItemR.h
//  RichOX
//
//  Created by zena.tang on 2021/1/13.
//  Copyright © 2021 richox. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <RichOXBase/RichOXWithdrawData.h>

NS_ASSUME_NONNULL_BEGIN


typedef NS_ENUM(NSInteger, RICHOX_SS_R_WITHDRAW_TYPE) {
    RICHOX_SS_R_WITHDRAW_TYPE_NORMAL                              = 0,  //普通
    RICHOX_SS_R_WITHDRAW_TYPE_WX                                  = 1  //微信极速提现
    
};

typedef NS_ENUM(NSInteger, RICHOX_SS_R_FREQUENCY_TYPE) {
    RICHOX_SS_R_FREQUENCY_TYPE_DAILY                              = 1,  //每日
    RICHOX_SS_R_FREQUENCY_TYPE_WEEKLY                             = 2,  //每周
    RICHOX_SS_R_FREQUENCY_TYPE_ALWAYS                             = 3,  //全程
    RICHOX_SS_R_FREQUENCY_TYPE_NOLIMIT                            = 4   //无限制
};

typedef NS_ENUM(NSInteger, RICHOX_SS_R_PRIZE_TYPE) {
    RICHOX_SS_R_PRIZE_TYPE_FIX                                    = 1,  //固定值
    RICHOX_SS_R_PRIZE_TYPE_MAX                                    = 2,  //指定最大值
};

typedef NS_ENUM(NSInteger, RICHOX_SS_R_WITHDRAW_STATUS) {
    RICHOX_SS_R_WITHDRAW_STATUS_NO                                = 0,  //未提现
    RICHOX_SS_R_WITHDRAW_STATUS_FAIL                              = 1,  //提现失败
    RICHOX_SS_R_WITHDRAW_STATUS_PROCESSING                        = 2,  //处理中
    RICHOX_SS_R_WITHDRAW_STATUS_REFUSE                            = 3,   //驳回
    RICHOX_SS_R_WITHDRAW_STATUS_SUCCESS                           = 100  //提现成功
};

@interface RichOXStageStrategyTask : NSObject

@property (nonatomic, strong, readonly) NSString *taskId;                              //任务ID
@property (nonatomic, strong, readonly) NSString *name;                                //任务名字
@property (nonatomic, readonly) int frequency;                                         //频率值
@property (nonatomic, readonly) RICHOX_SS_R_FREQUENCY_TYPE frequencyType;     //频率类型
@property (nonatomic, readonly) float prizeAmount;                                       //任务完成获取的奖励值
@property (nonatomic, readonly) RICHOX_SS_R_PRIZE_TYPE prizeType;             //奖励值类型
@property (nonatomic, strong, readonly) NSString *progressTypeId; //奖励值类型ID

- (instancetype) initWithData:(NSDictionary *)dic;

@end

@interface RichOXSSProgress: NSObject

@property (nonatomic, strong, readonly) NSString *progressId;   //进度值类型ID
@property (nonatomic, strong, readonly) NSString *progressName; //进度值类型名字

- (instancetype) initWithData:(NSDictionary *)dic;

@end

@interface RichOXSSProgressSetting: NSObject

@property (nonatomic, strong, readonly) NSString *progressId;   //进度值类型ID
@property (nonatomic, readonly) double progressRank;            //提现任务需要的进度值

- (instancetype) initWithData:(NSDictionary *)dic;

@end

@interface RichOXSSProgressInfo: RichOXSSProgress

@property (nonatomic, readonly) double  progressValue;            //当前进度值

- (instancetype) initWithData:(NSDictionary *)dic;

@end

@interface RichOXSSProgressStatus: RichOXSSProgress

@property (nonatomic, readonly) double  progressRank;            //所需进度值，提现任务和状态中有这个值

@property (nonatomic, readonly) double  progressValue;            //当前进度值

- (instancetype) initWithData:(NSDictionary *)dic;

@end


@interface RichOXStageStrategyItemR : NSObject

@property (nonatomic) int seq;                                        //获取列表序列，从1开始
@property (nonatomic, strong, readonly) NSString *packageId;          //红包项Id
@property (nonatomic, strong, readonly) NSString *name;               //红包项名字
@property (nonatomic) double amount;                                  //提现数值
@property (nonatomic, readonly) RICHOX_SS_R_WITHDRAW_TYPE withdrawType;

@property (nonatomic, strong, readonly) NSArray <RichOXSSProgressSetting *> *progressSetting; //每个提现任务可以关联多个进度值类型

@property (nonatomic, readonly) int needInviteUserCount;                   //邀请用户数量 0 表示没有邀请用户数限制
@property (nonatomic, readonly) int totalWithdrawTimes;               //总提现次数 -1 表示没有总提现次数限制

- (instancetype) initWithData:(NSDictionary *)dic;

@end

@interface RichOXSSWithdrawRecordData : RichOXWithdrawRecordData

@property (nonatomic, strong, readonly) NSString *taskId;

- (instancetype) initWithWithdrawRecord:(NSDictionary *)dic;

@end

@interface RichOXSSWithdrawStatus : NSObject

@property (nonatomic, strong, readonly) NSString *taskId;
@property (nonatomic, readonly) RICHOX_SS_R_WITHDRAW_STATUS status;

@property (nonatomic, strong, readonly) NSArray <RichOXSSProgressStatus *> *progressInfos;
@property (nonatomic, readonly) int needInviteUserCount;
@property (nonatomic, readonly) int alreayInviteUserCount;

- (instancetype) initWithWithdrawStatus:(NSDictionary *)dic;

@end

@interface RichOXStageStrategyStatus : NSObject

@property (nonatomic, strong, readonly) NSString *abGroup;
@property (nonatomic, strong, readonly) NSString *strategyVer;

@property (nonatomic, readonly, readonly) NSArray <RichOXSSProgressInfo *> *progressInfos;

@property (nonatomic, strong, readonly) NSArray <RichOXSSWithdrawRecordData *>*withdrawRecord;          //提现记录列表

@property (nonatomic, strong, readonly) NSArray <RichOXSSWithdrawStatus *>*withdrawStatus;          //提现状态列表

- (instancetype) initWithData:(NSDictionary *)dic;

@end



@interface RichOXStageStrategyTaskResult: NSObject

@property (nonatomic, strong, readonly) NSString *progressId; //进度值类型ID
@property (nonatomic, readonly) double  deltaPrize;              //进度值变化值
@property (nonatomic, readonly) double  totalPrize;              //变化后的进度值

@property (nonatomic, strong, readonly) NSArray <RichOXSSProgressInfo *> *progressInfos; //所有当前的进度值信息

- (instancetype) initWithData:(NSDictionary *)dic;

@end

NS_ASSUME_NONNULL_END
