//
//  RichOXStageStrategySetting.h
//  RichOXStageStrategy_R
//
//  Created by zena.tang on 2021/2/5.
//  Copyright © 2021 richox. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RichOXStageStrategyItemR.h"

NS_ASSUME_NONNULL_BEGIN

@interface RichOXStageStrategySetting : NSObject

@property (nonatomic, strong, readonly) NSString *strategyId;                              //策略ID
@property (nonatomic, strong, readonly) NSString *strategyVer;                             //策略版本
@property (nonatomic, strong, readonly) NSString *name;                                    //策略名字
@property (nonatomic, strong, readonly) NSString *payRemark;                               //支付说明
@property (nonatomic, strong, readonly) NSString *startTime;                               //开始时间
@property (nonatomic, strong, readonly) NSString *endTime;                                 //结束时间
@property (nonatomic) BOOL isIndefinite;                                                   //是否是无限期任务
@property (nonatomic, readonly) int abId;                                 //（可选）该策略归属的ab测试id,用于客户端打点
@property (nonatomic, strong, readonly) NSString *abGroup;                                 //（可选）流量组

@property (nonatomic, strong, readonly) NSArray <RichOXSSProgress *> *progressTypes;         //进度值型
@property (nonatomic, strong, readonly) NSArray <RichOXStageStrategyTask *> *tasks;         //策略任务
@property (nonatomic, strong, readonly) NSArray <RichOXStageStrategyItemR *> *withdrawSetting;                          //提现设置

- (instancetype) initWithData:(NSDictionary *)dic;

@end




NS_ASSUME_NONNULL_END
