//
//  RichOXStageStrategyItemR.h
//  RichOX
//
//  Created by zena.tang on 2021/1/13.
//  Copyright © 2021 richox. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, RICHOX_SS_R_WITHDRAW_STATUS) {
    RICHOX_SS_R_WITHDRAW_STATUS_UNKNOWN                           = 0, //未提现
    RICHOX_SS_R_WITHDRAW_STATUS_FAIL                              = 1, //提现失败
    RICHOX_SS_R_WITHDRAW_STATUS_IN_PROGRESS                       = 2, //处理中
    RICHOX_SS_R_WITHDRAW_STATUS_AUDIT_UNPASS                      = 3, //审核驳回
    RICHOX_SS_R_WITHDRAW_STATUS_PAY_SUCCESS                       = 100 //提现成功
};

typedef NS_ENUM(NSInteger, RICHOX_SS_R_PRECONDITION_STATUS) {
    RICHOX_SS_R_PRECONDITION_STATUS_NO              = 0, //无前置条件
    RICHOX_SS_R_PRECONDITION_STATUS_OK              = 1  //前置红包已提现
};

typedef NS_ENUM(NSInteger, RICHOX_SS_R_WITHDRAW_TYPE) {
    RICHOX_SS_R_WITHDRAW_TYPE_NORMAL                              = 0,  //普通
    RICHOX_SS_R_WITHDRAW_TYPE_WX                                  = 1  //微信极速提现
    
};

typedef NS_ENUM(NSInteger, RICHOX_SS_R_FREQUENCY_TYPE) {
    RICHOX_SS_R_FREQUENCY_TYPE_DAILY                              = 1,  //每日
    RICHOX_SS_R_FREQUENCY_TYPE_WEEKLY                             = 2,  //每周
    RICHOX_SS_R_FREQUENCY_TYPE_ALWAYS                             = 3,  //全程
    RICHOX_SS_R_FREQUENCY_TYPE_NOLIMIT                            = 4   //无限制
};

typedef NS_ENUM(NSInteger, RICHOX_SS_R_PRIZE_TYPE) {
    RICHOX_SS_R_PRIZE_TYPE_FIX                                    = 1,  //固定值
    RICHOX_SS_R_PRIZE_TYPE_MAX                                    = 2,  //指定最大值
};

@interface RichOXStageStrategyTask : NSObject

@property (nonatomic, strong, readonly) NSString *taskId;                              //任务ID
@property (nonatomic, strong, readonly) NSString *name;                                //任务名字
@property (nonatomic, readonly) int frequency;                                         //频率值
@property (nonatomic, readonly) RICHOX_SS_R_FREQUENCY_TYPE frequencyType;     //频率类型
@property (nonatomic, readonly) int prizeAmount;                                       //任务完成获取的奖励值
@property (nonatomic, readonly) RICHOX_SS_R_PRIZE_TYPE prizeType;             //奖励值类型

- (instancetype) initWithData:(NSDictionary *)dic;

@end


@interface RichOXStageStrategyItemR : NSObject

@property (nonatomic) int seq;                                        //获取列表序列，从1开始
@property (nonatomic, strong, readonly) NSString *packageId;          //红包项Id
//@property (nonatomic, strong, readonly) NSString *name;             //红包项名字
@property (nonatomic) double amount;                                  //提现数值
@property (nonatomic, readonly) RICHOX_SS_R_FREQUENCY_TYPE frequencyType;

@property (nonatomic, readonly) RICHOX_SS_R_WITHDRAW_TYPE withdrawType;       //提现类型
//@property (nonatomic, readonly) RICHOX_SS_R_PRECONDITION_STATUS precondition;           //前置条件
@property (nonatomic, readonly) int targetDegree;               //目标等级
@property (nonatomic, strong, readonly) NSString *detail;             //自定义信息
@property (nonatomic) int needPrize;                      //所需进度值

//@property (nonatomic) RICHOX_SS_R_WITHDRAW_STATUS withdrawStatus;   //提现状态

- (instancetype) initWithData:(NSDictionary *)dic;

@end


NS_ASSUME_NONNULL_END
