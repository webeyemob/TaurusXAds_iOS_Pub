//
//  FissionSdkShare.h
//  FissionSdk
//
//  Created by zena.tang on 2021/1/8.
//  Copyright © 2021 TaurusXAds. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, FISSIONSDK_SHARE_PLATFORM) {
    FISSIONSDK_SHARE_PLATFORM_WECHAT_SESSION        = 0, //微信好友
    FISSIONSDK_SHARE_PLATFORM_WECHAT_TIMELINE       = 1, //微信朋友圈
    FISSIONSDK_SHARE_PLATFORM_QQ_FRIEND             = 2, //QQ好友
    FISSIONSDK_SHARE_PLATFORM_QQ_ZONE               = 3, //QQZone
    FISSIONSDK_SHARE_PLATFORM_SINAWEIBO             = 4, //新浪微博
    FISSIONSDK_SHARE_PLATFORM_DOUYIN                = 5, //抖音
    FISSIONSDK_SHARE_PLATFORM_SMS                   = 6, //短信
    FISSIONSDK_SHARE_PLATFORM_MAIL                  = 7, //邮件
    FISSIONSDK_SHARE_PLATFORM_COPY                  = 8  //复制
};

typedef NS_ENUM(NSInteger, FISSIONSDK_SHARE_CONTENTTYPE) {
    FISSIONSDK_SHARE_CONTENTTYPE_AUTO         = 0,   //自动适配
    FISSIONSDK_SHARE_CONTENTTYPE_TEXT         = 1,   //文本
    FISSIONSDK_SHARE_CONTENTTYPE_IMAGE        = 2,   //图片
    FISSIONSDK_SHARE_CONTENTTYPE_WEBPAGE      = 3,   //网页
    FISSIONSDK_SHARE_CONTENTTYPE_AUDIO        = 5,   //音频
    FISSIONSDK_SHARE_CONTENTTYPE_VIDEO        = 6    //视频
};

@interface FissionSdkShareParam : NSObject

@property (nonatomic, strong) NSString *text;
@property (nonatomic, strong) NSString *title;
@property (nonatomic, strong) NSURL *url;        //video，audio或者网页的url

@property (nonatomic, strong) NSArray  *images;             //可以为UIImage、NSString（图片路径）、NSURL（图片路径）的 数组，如果是抖音分享，只允许为相册资源且集合传对应的资源localIdentifier，非相册路径       如相册路径为“assets-library://asset/asset.mp4?id=E7BEC1A7-D60C-4B41-85AB-B8A1606AB338&ext=mp4”，images为@[@"E7BEC1A7-D60C-4B41-85AB-B8A1606AB338"]

@property (nonatomic, assign) double latitude;  //新浪微博分享时可以传入
@property (nonatomic, assign) double longitude; //新浪微博分享时可以传入

@property (nonatomic, assign) FISSIONSDK_SHARE_CONTENTTYPE contentType;

@end

typedef void (^FissionSdkShareSuccessBlock)(void);
typedef void (^FissionSdkShareFailureBlock)(NSError *error);

@interface FissionSdkShare : NSObject


/*!
@method shareTo:shareContent:success:failure
@abstract 分享功能
@param platform 分享的平台
@param shareContent  分享内容
@param success 成功的block，无参数
@param failure 失败的block，返回失败的原因
*/
+ (void) shareTo:(FISSIONSDK_SHARE_PLATFORM)platform shareContent:(FissionSdkShareParam *)shareContent success:(FissionSdkShareSuccessBlock)success failure:(FissionSdkShareFailureBlock)failure;

/*!
@method popShareWithView:items:shareContent:success:failure
@abstract 从设备的底部弹出菜单，显示各个分享平台的icon，点击icon分享到对应的平台
@param view 菜单大小
@param items  要分享的平台集合，如果传nil，分享到默认的平台（微信，QQ，新浪，抖音）
@param shareContent  分享内容
@param success 成功的block，无参数
@param failure 失败的block，返回失败的原因
*/
+ (void)popShareWithView:(UIView *)view items: (NSArray *)items shareContent:(FissionSdkShareParam *)shareContent success:(FissionSdkShareSuccessBlock)success failure:(FissionSdkShareFailureBlock)failure;


@end

NS_ASSUME_NONNULL_END
