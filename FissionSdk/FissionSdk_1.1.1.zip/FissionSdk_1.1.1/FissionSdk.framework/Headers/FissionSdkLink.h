//
//  FissionSdkLink.h
//  FissionSdk
//
//  Created by zena.tang on 2021/1/8.
//  Copyright © 2021 TaurusXAds. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

typedef void(^FissionSdkLinkSuccessHandler)(NSString *shareUrl);
typedef void(^FissionSdkLinkFailHandler)(NSError *error);

@protocol FissionSdkLineInviteDelegate <NSObject>

@required
/*!
@method getInviter:params:inPath
@abstract SDK通过调用该方法返回邀请者的ID
@param id 邀请者ID
@param params 师傅分享ID时自定义的参数
@param path 分享路径，用于区别来自什么场景的分享
*/
- (void)getInviter:(NSString *)id params: (NSDictionary *)params inPath:(NSString *)path;

@end

@interface FissionSdkLink : NSObject

/**
 获取单例对象
 
 @return 单例对象
 */
+ (FissionSdkLink *)shareInstance;

/*!
@method start:appSecret:delegate
@abstract 启动Link功能获取师傅ID
@param appKey  moblink上创建项目获取的appKey
@param appSecret  moblink上创建项目获取的appSecret
@param delegate  设置代理方法用于接收师傅ID
*/
- (void) start: (NSString *)appKey appSecret:(NSString *)appSecret delegate:(id <FissionSdkLineInviteDelegate>)delegate;

/*!
@method getShareLink:path:params:success:fail
@abstract 获取本人的分享连接
@param host  web端地址
@param path  分享路径，用于区别时什么场景的分享
@param params 师傅分享ID时自定义的参数
@param success 成功的block，参数是邀请链接
@param fail 失败的block，返回失败的原因
*/
+ (void)getShareLink: (NSString *)host path: (NSString *)path params:(NSDictionary *)params success:(FissionSdkLinkSuccessHandler)success fail:(FissionSdkLinkFailHandler)fail;

/*!
@method getQRCodeView:linkUrl
@abstract 给分享链接生成二维码 view
@param frame  view的大小
@param linkUrl  分享链接
*/
+ (UIView *)getQRCodeView:(CGRect)frame linkUrl:(NSString *)linkUrl;


@end

NS_ASSUME_NONNULL_END
