//
//  FissionSdkMissionRecord.h
//  FissionSdk
//
//  Created by zena.tang on 2020/12/14.
//  Copyright © 2020 TaurusXAds. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FissionSdkType.h"

NS_ASSUME_NONNULL_BEGIN

@interface FissionSdkMissionRecord : NSObject

@property (nonatomic, strong, readonly) NSString *recordId;
@property (nonatomic, strong, readonly) NSString *userId;
@property (nonatomic, strong, readonly) NSString *missionId;

@property (nonatomic, readonly) FISSIONSDK_MISSION_BONUSTYPE bonusType;
@property (nonatomic, readonly) int bonus;

@property (nonatomic, readonly) int multiply;

@property (nonatomic, readonly) FISSIONSDK_MISSION_COSTTYPE costType;
@property (nonatomic, readonly) int cost;

@property (nonatomic, strong, readonly) NSString *executedAt;

@property (nonatomic, strong, readonly) NSString *multiplyAt;

- (instancetype) initWithResponse:(NSDictionary *)dic;

@end


@interface FissionSdkMissionSubmitResult : NSObject

@property (nonatomic, strong, readonly) FissionSdkMissionRecord *record;

@property (nonatomic, readonly) int coinDelta;                                  //金币变动
@property (nonatomic, readonly) float cashDelta;                                //现金变动
@property (nonatomic, readonly) int currentCoin;                                //当前金币
@property (nonatomic, readonly) float currentCash;                              //当前现金

- (instancetype) initWithResponse:(NSDictionary *)dic;

@end

@interface FissionSdkMissionQueryResult : NSObject

@property (nonatomic, strong, readonly) NSArray <FissionSdkMissionRecord *>* records;

@property (nonatomic, readonly) int total;                                     //总数
@property (nonatomic, readonly) int pageIndex;                                 //记录开始index
@property (nonatomic, readonly) int pageSize;                                  //记录每页的大小
@property (nonatomic, strong, readonly) NSString *begin;                       //开始时间
@property (nonatomic, strong, readonly) NSString *end;                         //结束时间

- (instancetype) initWithResponse:(NSDictionary *)dic;

@end

@interface FissionSdkMissionQueryCountResult : NSObject


@property (nonatomic, strong, readonly) NSString *missionId;                   //总数
@property (nonatomic, readonly) int count;                                     //数量
@property (nonatomic, strong, readonly) NSString *begin;                       //开始时间
@property (nonatomic, strong, readonly) NSString *end;                         //结束时间

- (instancetype) initWithResponse:(NSDictionary *)dic;

@end

@interface FissionSdkMissionTodayCoinsResult : NSObject


@property (nonatomic, strong, readonly) NSString *userId;                      //用户ID
@property (nonatomic, strong, readonly) NSString *day;                         //日期
@property (nonatomic, strong, readonly) NSString *version;                     //版本
@property (nonatomic, readonly) int coin;                                      //金币数
@property (nonatomic, readonly) int count;                                     //数量

- (instancetype) initWithResponse:(NSDictionary *)dic;

@end

NS_ASSUME_NONNULL_END
