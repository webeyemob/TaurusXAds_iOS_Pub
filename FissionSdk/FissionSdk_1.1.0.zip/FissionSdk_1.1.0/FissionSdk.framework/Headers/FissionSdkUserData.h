//
//  FissionSdkUserData.h
//  FissionSdk
//
//  Created by zena.tang on 2020/12/14.
//  Copyright © 2020 TaurusXAds. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FissionSdkSocialAccount.h"
#import "FissionSdkWithdraw.h"

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, FISSIONSDK_BINDTYPE) {
    FISSIONSDK_BINDTYPE_WECHAT                      = 0, //微信
    FISSIONSDK_BINDTYPE_FACEBOOK                    = 1,  // facebook
    FISSIONSDK_BINDTYPE_GOOGLE                      = 2,  // google
    FISSIONSDK_BINDTYPE_APPLE                       = 3,  // apple
    FISSIONSDK_BINDTYPE_ALIPAY                      = 4   // 支付宝
};

typedef NS_ENUM(int, FISSIONSDK_GENDER_TYPE) {
    FISSIONSDK_GENDER_UNKNOWN                       = 0, //未知
    FISSIONSDK_GENDER_MALE                          = 1,  // 男
    FISSIONSDK_GENDER_FEMALE                        = 2   // 女
};


typedef NS_ENUM(int, FISSIONSDK_INVITATE_STATUS) {
    FISSIONSDK_INVITATE_STATUS_OK                   = 1,    //绑定成功
    FISSIONSDK_INVITATE_STATUS_INVALIDED            = 50,   // 邀请无效
    FISSIONSDK_INVITATE_STATUS_VALIDED              = 100   // 邀请有效
};

@interface FissionSdkUserData : NSObject

@property (nonatomic, strong, readonly) NSString *id;                 //用户唯一标识
@property (nonatomic, strong, readonly) NSString *name;               //用户昵称自动生成，绑定facebook后更新为facebook用户的name
@property (nonatomic, strong, readonly) NSString *avatar;             //头像URL,绑定微信后设置
@property (nonatomic, strong, readonly) NSString *deviceId;           //设备唯一id
@property (nonatomic, strong, readonly) NSString *phone;


//微信信息
@property (nonatomic, strong, readonly) NSString *wechatOpenId;       //微信用户openid    绑定微信后设置
@property (nonatomic, strong, readonly) NSString *wechatAppId;        //微信开发者账号appid    绑定微信后设置
@property (nonatomic, strong, readonly) NSString *wechatBoundAt;      //微信bind时间
@property (nonatomic, readonly) FISSIONSDK_GENDER_TYPE gender;        //性别，1:男，2：女


@property (nonatomic, readonly) int coin;                             //金币数量
@property (nonatomic, readonly) float cash;                           //现金数量

@property (nonatomic, readonly) BOOL hasWithdrawn;                    //是否提现过


@property (nonatomic, strong, readonly) NSString *installAt;          //安装时间
@property (nonatomic, strong, readonly) NSString *inviterId;          //邀请者ID（师傅）
@property (nonatomic, strong, readonly) NSString *invitationCode;     //邀请码

@property (nonatomic, readonly) BOOL isNew;                           //是否新创建用户

//fb信息
@property (nonatomic, strong, readonly) NSString *fbOpenId;           //facebook用户标识
@property (nonatomic, strong, readonly) NSString *fbName;             //facebook用户名
@property (nonatomic, strong, readonly) NSString *fbFirstName;          //用户名
@property (nonatomic, strong, readonly) NSString *fbLastName;           //用户姓氏
@property (nonatomic, strong, readonly) NSString *fbEmail;            //用户email

//google信息
@property (nonatomic, strong, readonly) NSString *googleSub;          //google账号唯一标示    google开关必须打开
@property (nonatomic, strong, readonly) NSString *googleName;         //google账号用户名    google开关必须打开


//apple信息
@property (nonatomic, strong, readonly) NSString *appleSub;           //apple账号唯一标示    apple开关必须打开
@property (nonatomic, strong, readonly) NSString *appleName;          //apple账号用户名    apple开关必须打开

//支付宝账号信息
@property (nonatomic, strong, readonly) NSString *alipayId;           //支付宝账号唯一标示
@property (nonatomic, strong, readonly) NSString *alipayName;          //支付宝账号名

- (instancetype) initWithResponse:(NSDictionary *)dic;


@end


@interface FissionSdkUserBindResult : FissionSdkUserData

@property (nonatomic, readonly) FISSIONSDK_BINDTYPE bindType;                           //bind type
@property (nonatomic, readonly) long long createdAt;                                     //用户创建时间，毫秒时间戳

@property (nonatomic, strong, readonly) FissionSdkSocialAccount *socialAccountInfo;     //社交账号信息

- (instancetype) initWithResponse:(NSDictionary *)dic bindType: (FISSIONSDK_BINDTYPE)bindType;

@end

@interface FissionSdkUserTokenData : NSObject

@property (nonatomic, strong, readonly) NSString *userId;             //id
@property (nonatomic, strong, readonly) NSString *token;              //token
@property (nonatomic, readonly) long long refreshTime;                //刷新时间

- (instancetype) initWithResponse:(NSDictionary *)dic;

@end

@interface FissionSdkUserSignInData : NSObject

@property (nonatomic, strong, readonly) FissionSdkWithdrawSetting *withdrawSetting;             //提现设置
@property (nonatomic, strong, readonly) NSArray <NSString *>*records;                           //签到记录
@property (nonatomic, strong, readonly) NSArray <NSString *>*withdraws;                         //提现记录

- (instancetype) initWithResponse:(NSDictionary *)dic;

@end

@interface FissionSdkUserBindInvitationData : NSObject

@property (nonatomic, strong, readonly) FissionSdkUserData *inviter;                            //inviter user data
@property (nonatomic, readonly) FISSIONSDK_MISSION_BONUSTYPE awardType;                         //奖励类型
@property (nonatomic, readonly) float award;                                                      //奖励数
@property (nonatomic, readonly) int currentCoin;                                                //当前金币数
@property (nonatomic, readonly) float currentCash;                                              //当前现金数

- (instancetype) initWithResponse:(NSDictionary *)dic;

@end

@interface FissionSdkInvitationData : NSObject

@property (nonatomic, strong, readonly) NSString *id;                                          //Invitation ID
@property (nonatomic, strong, readonly) NSString *inviteeId;                                   //invitee ID
@property (nonatomic, strong, readonly) NSString *inviteeName;                                 //invitee Name
@property (nonatomic, strong, readonly) NSString *inviteeAvatar;                               //invitee avatar
@property (nonatomic, strong, readonly) NSString *invitedDay;                                  //邀请日期 2020-06-23
@property (nonatomic, strong, readonly) NSString *invitedAt;                                   //邀请时间 2020-06-23T06:40:45.487Z

@property (nonatomic, strong, readonly) NSString *activiyId;                                   //活动ID
@property (nonatomic, readonly) FISSIONSDK_MISSION_BONUSTYPE boundAwardType;                   //奖励类型
@property (nonatomic, readonly) float boundAward;                                              //奖励数
@property (nonatomic, readonly) FISSIONSDK_MISSION_BONUSTYPE validAwardType;                   //有效奖励类型
@property (nonatomic, readonly) float validAward;                                              //有效奖励数

@property (nonatomic, readonly) FISSIONSDK_INVITATE_STATUS status;                              //状态

- (instancetype) initWithResponse:(NSDictionary *)dic;

@end


@interface FissionSdkInvitationRecord : NSObject

@property (nonatomic, readonly) int total;                                          //总数
@property (nonatomic, readonly) int validCount;                                     //有效数
@property (nonatomic, readonly) int inValidCount;                                   //无效数
@property (nonatomic, readonly) int bound;                                          //奖励数
@property (nonatomic, readonly) int boundCoin;                                      //奖励金币
@property (nonatomic, readonly) int validCoin;                                      //有效金币
@property (nonatomic, readonly) float boundCash;                                    //奖励现金
@property (nonatomic, readonly) float validCash;                                    //有效金币
@property (nonatomic, readonly) int pageIndex;                                      //
@property (nonatomic, readonly) int pageSize;                                       //

@property (nonatomic, strong, readonly) NSArray <FissionSdkInvitationData *> *records; //邀请记录

- (instancetype) initWithResponse:(NSDictionary *)dic;

@end

@interface FissionSdkUserBasicData : NSObject

@property (nonatomic, strong, readonly) NSString *userId;             //id
@property (nonatomic, strong, readonly) NSString *name;              //name
@property (nonatomic, strong, readonly) NSString *avatar;            //头像

- (instancetype) initWithResponse:(NSDictionary *)dic;

@end


NS_ASSUME_NONNULL_END
