//
//  FissionSdkManager.h
//  FissionSdk
//
//  Created by zena.tang on 2020/12/12.
//  Copyright © 2020 TaurusXAds. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, FISSIONSDK_USERTYPE) {
    FISSIONSDK_USERTYPE_VISTOR                      = 0, // 游客 缺省值
    FISSIONSDK_USERTYPE_WECHAT                      = 1, // 微信
    FISSIONSDK_USERTYPE_FACEBOOK                    = 2, // facebook
    FISSIONSDK_USERTYPE_GOOGLE                      = 3, // google
    FISSIONSDK_USERTYPE_APPLE                       = 4, // apple
};

@interface FissionSdkManager : NSObject

/*!
@method initWithHost:key:deviceId:userType:userToken:openId
@abstract init Fission SDK
@param host app's host url in fission platform
@param key app's key in fission platform
@param deviceId deviceId for define the user in App, if is nil, the value define by SDK
*/
+ (void) initWithHost:(NSString *)host key:(NSString *)key deviceId:(NSString * _Nullable)deviceId;

+ (void) setTestMode:(BOOL)testMode;
+ (BOOL) isTestMode;

/*!
@method setFissionPlatform
@abstract 设置FissionPlatform字段，如果有特殊需求。调用此接口传入
@param fissionPlatform fissionPlatform字段
*/
+ (void)setFissionPlatform: (NSString *)fissionPlatform;

/*!
@method setAppVersionCode
@abstract 设置App Version Code，如果使用版本号去掉"."生成版本代码，不用调用此接口
@param appVersionCode APP的版本号
*/
+ (void)setAppVersionCode:(NSInteger)appVersionCode;


//第三方分享和share SDK
+ (void) uploadPrivacyPermissionStatus:(BOOL)status onResult:(void (^_Nullable)(BOOL success))handler;

@end

NS_ASSUME_NONNULL_END
