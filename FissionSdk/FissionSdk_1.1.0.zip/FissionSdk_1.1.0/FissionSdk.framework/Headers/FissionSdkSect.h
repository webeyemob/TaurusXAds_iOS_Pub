//
//  FissionSdkSect.h
//  FissionSdk
//
//  Created by zena.tang on 2021/1/14.
//  Copyright © 2021 TaurusXAds. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FissionSdkSectData.h"
#import "FissionSdkError.h"
#import "FissionSdkMissionData.h"

NS_ASSUME_NONNULL_BEGIN


typedef void (^FissionSdkSectGetSectInfoSuccessBlock)(FissionSdkSectData *data);
typedef void (^FissionSdkSectGetApprenticeListSuccessBlock)(FissionSdkSectApprenticeList *data);
typedef void (^FissionSdkSectGetApprenticeInfoSuccessBlock)(FissionSdkSectApprenticeInfo *data);
typedef void (^FissionSdkSectGenContributionSuccessBlock)(int star);
typedef void (^FissionSdkSectGetContributionSuccessBlock)(int star, int deltaContribution); //star: 领取后当前宗门贡献值, deltaContribution:本次领取的贡献值
typedef void (^FissionSdkSectGetInviteAwardSuccessBlock)(FissionSdkSectInviteAward *award);
typedef void (^FissionSdkSectGetContributionDayRecordSuccessBlock)(NSDictionary *record);
typedef void (^FissionSdkSectGetTransTimesPacketSuccessBlock)(FissionSdkSectTransformTimesPacket *packet);
typedef void (^FissionSdkSectGetRedPacketRecordSuccessBlock)(FissionSdkSectRedPacketRecord *record);
typedef void (^FissionSdkSectTransformSuccessBlock)(FissionSdkSectTransformResult *result);
typedef void (^FissionSdkSectGetSettingSuccessBlock)(FissionSdkSectSettingData *data);
typedef void (^FissionSdkSectGetInviteAwardSettingSuccessBlock)(NSArray <FissionSdkSectInviteAwardsSettingData *> *list);
typedef void (^FissionSdkSectGetMissionSuccessBlock)(NSArray <FissionSdkMissionData *> *data);
typedef void (^FissionSdkSectMissionSubmitSuccessBlock)(FissionSdkSectMissionSubmitResult *result);
typedef void (^FissionSdkSectQueryMissionSuccessBlock)(FissionSdkSectQueryMissionResult *result);


@interface FissionSdkSect : NSObject

/*!
@method getSectInfo:failure
@abstract 此接口用于获取当前用户的宗门信息
@param success 成功的block，参数是FissionSdkSectData
@param failure 失败的block，返回失败的原因
*/
+ (void)getSectInfo:(FissionSdkSectGetSectInfoSuccessBlock)success failure:(FissionSdkFailureBlock)failure;

/*!
@method getApprenticeList:pageSize:currentPage:success:failure
@abstract 此接口用于分页获取某级弟子的信息
@param level 弟子级数 ，1为掌门弟子
@param pageSize 每页大小，0表示使用默认的50，最大200
@param currentPage 当前页，默认0
@param success 成功的block，参数是FissionSdkSectApprenticeListLevel
@param failure 失败的block，返回失败的原因
*/
+ (void)getApprenticeList:(int)level pageSize:(int)pageSize currentPage:(int)currentPage success:(FissionSdkSectGetApprenticeListSuccessBlock)success failure:(FissionSdkFailureBlock)failure;

/*!
@method getApprenticeInfo:success:failure
@abstract 此接口用于获取某个弟子的详细信息
@param apprenticeUid 弟子uid
@param success 成功的block，参数是FissionSdkSectApprenticeInfo
@param failure 失败的block，返回失败的原因
*/
+ (void)getApprenticeInfo:(NSString *)apprenticeUid success:(FissionSdkSectGetApprenticeInfoSuccessBlock)success failure:(FissionSdkFailureBlock)failure;

/*!
@method genContribution:success:failure
@abstract 此接口用于通过上报某种动作产生贡献值(未领取状态，目前仅有观看视频广告)
@param actionId 动作id, 0-观看视频
@param success 成功的block，参数是贡献值
@param failure 失败的block，返回失败的原因
*/
+ (void)genContribution:(int)actionId success:(FissionSdkSectGenContributionSuccessBlock)success failure:(FissionSdkFailureBlock)failure;

/*!
@method getContribution:studentUid:success:failure
@abstract 此接口用于领取贡献值
@param masterUid 宗主uid
@param apprenticeUid 指定弟子(包括自己)的uid, 不填则为一键领取
@param success 成功的block，参数是领取后当前宗门贡献值和本次领取的贡献值
@param failure 失败的block，返回失败的原因
*/
+ (void)getContribution:(NSString *)masterUid apprenticeUid:(NSString * _Nullable)apprenticeUid success:(FissionSdkSectGetContributionSuccessBlock)success failure:(FissionSdkFailureBlock)failure;

/*!
@method getInviteAward:success:failure
@abstract 此接口用于领取招募奖励
@param count 奖励对应的招募用户数
@param success 成功的block，参数是FissionSdkSectInviteAward
@param failure 失败的block，返回失败的原因
*/
+ (void)getInviteAward:(int)count success: (FissionSdkSectGetInviteAwardSuccessBlock)success failure:(FissionSdkFailureBlock)failure;

/*!
@method getContributionDayRecord:year:month:success:failure
@abstract 此接口用于获取贡献记录(按月)
@param year 年 *2021
@param month 月 *1
@param success 成功的block，参数是: key为日期，value为内容的字典，比如  {"2020-08-11": {"total": 123,"0": 10,"1": 100,"2": 13}}
@param failure 失败的block，返回失败的原因
*/
+ (void)getContributionDayRecord:(int)year month: (int)month success: (FissionSdkSectGetContributionDayRecordSuccessBlock)success failure:(FissionSdkFailureBlock)failure;


/*!
@method getTransformTimesPacket:success:failure
@abstract 此接口用于领取完成现金兑换次数红包
@param count 第几个红包，从1开始
@param success 成功的block，参数是:FissionSdkSectTransformTimesPacket
@param failure 失败的block，返回失败的原因
*/
+ (void)getTransformTimesPacket:(int)count success:(FissionSdkSectGetTransTimesPacketSuccessBlock)success failure:(FissionSdkFailureBlock)failure;

/*!
@method getRedPacketRecord:curPage:success:failure
@abstract 此接口用于获取红包记录
@param pageSize 每页大小，0表示使用默认50，最大200
@param curPage 当前页，默认0
@param success 成功的block，参数是:FissionSdkSectTransformResult
@param failure 失败的block，返回失败的原因
*/
+ (void)getRedPacketRecord:(int)pageSize curPage:(int)curPage success:(FissionSdkSectGetRedPacketRecordSuccessBlock)success failure:(FissionSdkFailureBlock)failure;

/*!
@method transform:failure
@abstract 此接口用于进行现金兑换
@param success 成功的block，参数是:FissionSdkSectTransformResult
@param failure 失败的block，返回失败的原因
*/
+ (void)transform:(FissionSdkSectTransformSuccessBlock)success failure:(FissionSdkFailureBlock)failure;


/*!
@method getSetting:failure
@abstract 此接口用于获取宗门设置
@param success 成功的block，参数是:FissionSdkSectSettingData
@param failure 失败的block，返回失败的原因
*/
+ (void)getSetting:(FissionSdkSectGetSettingSuccessBlock)success failure:(FissionSdkFailureBlock)failure;


/*!
@method getInviteAwardSetting:failure
@abstract 此接口用于获取招募奖励设置列表
@param success 成功的block，参数是:NSArray <FissionSdkSectInviteAwardsSettingData *> *
@param failure 失败的block，返回失败的原因
*/
+ (void)getInviteAwardSetting:(FissionSdkSectGetInviteAwardSettingSuccessBlock)success failure:(FissionSdkFailureBlock)failure;


/*!
@method getSectMission:failure
@abstract 此接口用于获取宗门配置的任务信息
@param success 成功的block，参数是:FissionSdkMissionData 数组
@param failure 失败的block，返回失败的原因
*/
+ (void)getSectMission:(FissionSdkSectGetMissionSuccessBlock)success failure:(FissionSdkFailureBlock)failure;

/*!
@method submitSectMission:missionId:bonus:success:failure
@abstract 此接口用于宗门用户完成宗门任务后领取相应的奖励
@param missionId 宗门任务id
@param bonus 客户端指定的奖励数量(仅对支持客户端控制的任务有效)
@param success 成功的block，参数是:FissionSdkSectMissionSubmitResult
@param failure 失败的block，返回失败的原因
*/
+ (void)submitSectMission:(NSString *)missionId bouns:(float)bonus success:(FissionSdkSectMissionSubmitSuccessBlock)success failure:(FissionSdkFailureBlock)failure;

/*!
@method quaryMission:missionId:days:pageSize:pageIndex:success:failure
@abstract 此接口用于查询指定天数内的特定类型宗门任务记录，返回按任务完成时间倒序排列，比如查询7天内的签到记录
@param missionId: 宗门任务id，不填返回全部任务记录
@param days: 天数，1表示查当天
@param pageSize: 每页数量，0表示使用默认30
@param pageIndex: 页码，从1开始，0表示使用默认1
@param success 成功的block，参数是:FissionSdkMissionData 数组
@param failure 失败的block，返回失败的原因
*/
+ (void)quaryMission:(NSString * _Nullable)missionId days:(int)days pageSize:(int)pageSize pageIndex:(int)pageIndex success:(FissionSdkSectQueryMissionSuccessBlock)success failure:(FissionSdkFailureBlock)failure;

@end

NS_ASSUME_NONNULL_END
