//
//  FissionSdkUser.h
//  FissionSdk
//
//  Created by zena.tang on 2020/12/12.
//  Copyright © 2020 TaurusXAds. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FissionSdkError.h"
#import "FissionSdkUserData.h"

NS_ASSUME_NONNULL_BEGIN


typedef void (^FissionSdkUserGetUserDataSuccessBlock)(FissionSdkUserData *userData);
typedef void (^FissionSdkUserBindSuccessBlock)(FissionSdkUserBindResult *result);


typedef void (^FissionSdkUserGetPrivateDataSuccessBlock)(NSString *value);

typedef void (^FissionSdkUserTokenSuccessBlock)(FissionSdkUserTokenData *data);

typedef void (^FissionSdkUserSignInSuccessBlock)(NSArray <NSString *> *days);
typedef void (^FissionSdkUserSignInInfoSuccessBlock)(FissionSdkUserSignInData *data);

typedef void (^FissionSdkBindInvitationSuccessBlock)(FissionSdkUserBindInvitationData *data);

typedef void (^FissionSdkInvitationRecordSuccessBlock)(FissionSdkInvitationRecord *data);

typedef void (^FissionSdkGetUserBasicInfosSuccessBlock)(NSArray <FissionSdkUserBasicData *> *data);

/*!
包含用户 API.的类
*/
@interface FissionSdkUser : NSObject

/*!
@method registerUserId:failure
@abstract 此接口用于新安装用户获取游客身份
@param success 成功的block，参数是用户信息
@param failure 失败的block
*/
+ (void)registerUserId: (FissionSdkUserGetUserDataSuccessBlock)success failure:(FissionSdkFailureBlock)failure;

/*!
@method bindUser:bindType:bindCode:success:failure:
@abstract 社交账号绑定
@param appId  google用户该值为nil, 微信用户是微信应用的app_id, facebook用户是facebook用户的open_id, apple用户是apple用户名(非必填)
@param bindType 社交账号类型，参见FISSIONSDK_BINDTYPE
@param bindCode 微信用户为微信绑定code, Facebook用户为 facebook用户的授权码token, google用户为用户的id_token, Apple用户是登录后获取的token
@param success 成功的block，参数是绑定之后的用户信息
@param failure 失败的block
*/
+ (void)bindUser: (NSString *)appId bindType:(FISSIONSDK_BINDTYPE)bindType bindCode:(NSString *)bindCode success:(FissionSdkUserBindSuccessBlock)success failure:(FissionSdkFailureBlock)failure;

/*!
@method checkBind:bindType:bindCode:success:failure:
@abstract 社交账号绑定检查
@param appId  google用户该值为nil, 微信用户是微信应用的app_id, facebook用户是facebook用户的open_id, apple用户是apple用户名(非必填)
@param bindType 社交账号类型，参见FISSIONSDK_BINDTYPE
@param bindCode 微信用户为微信绑定code, Facebook用户为 facebook用户的授权码token, google用户为用户的id_token, Apple用户是登录后获取的token
@param success 成功的block，参数是绑定之后的用户信息
@param failure 失败的block
*/
+ (void)checkBind: (NSString *)appId bindType:(FISSIONSDK_BINDTYPE)bindType bindCode:(NSString *)bindCode success:(FissionSdkUserBindSuccessBlock)success failure:(FissionSdkFailureBlock)failure;

/*!
@method getUserInfo:failure:
@abstract 此接口用于获取用户昵称、头像、金币数等信息
@param success 成功的block，参数是用户信息
@param failure 失败的block
*/
+ (void)getUserInfo: (FissionSdkUserGetUserDataSuccessBlock)success failure:(FissionSdkFailureBlock)failure;

/*!
@method saveUserPrivate:data:success:failure
@abstract 此接口用于存储用户级的私有数据，存储的key最大长度支持64个字符
@param key 存储的key值    最大支持64个字符
@param data 存储的value值
@param success 成功的block，参数无
@param failure 失败的block
*/
+ (void)saveUserPrivate: (NSString *)key data:(NSString *)data success:(FissionSdkCommonSuccessBlock)success failure:(FissionSdkFailureBlock)failure;

/*!
@method getUserData:success:failure:
@abstract 此接口用于查询指定的用户级key存储的数据
@param key 存储的key值
@param success 成功的block，参数是key对应的value值
@param failure 失败的block
*/
+ (void)getUserData: (NSString *)key success:(FissionSdkUserGetPrivateDataSuccessBlock)success failure:(FissionSdkFailureBlock)failure;

/*!
@method getUserBaseInfo:success:failure:
@abstract 此接口用于获取指定用户微信昵称、头像等信息
@param targetUserId  指定的用户ID
@param success 成功的block，参数是FissionSdkUserBasicData的数组
@param failure 失败的block
*/
+ (void)getUserBaseInfo: (NSArray *)targetUserId success:(FissionSdkGetUserBasicInfosSuccessBlock)success failure:(FissionSdkFailureBlock)failure;

/*!
@method logOutUser:failure
@abstract 此接口用于注销指定用户，用户注销成功后，该用户设备将无法再次使用产品
@param success 成功的block，参数无
@param failure 失败的block
*/
+ (void)logOutUser:(FissionSdkCommonSuccessBlock)success failure:(FissionSdkFailureBlock)failure;

/*!
@method getUserToken:failure
@abstract 此接口用于获取当前用户的访问token，方便第三方系统访问fission系统
@param success 成功的block，参数Token信息
@param failure 失败的block
*/
+ (void)getUserToken:(FissionSdkUserTokenSuccessBlock)success failure:(FissionSdkFailureBlock)failure;

/*!
@method registerByWeChat:bindCode:success:failure:
@abstract 此接口用于新安装用户直接使用微信注册
@param appId  微信应用的app_id
@param bindCode 微信绑定code
@param success 成功的block，参数是绑定之后的用户信息
@param failure 失败的block
*/
+ (void)registerByWeChat:(NSString *)appId bindCode:(NSString *)bindCode success:(FissionSdkUserBindSuccessBlock)success failure:(FissionSdkFailureBlock)failure;

/*!
@method syncWeChat:oopenId:unionId:nickName:headImgUrl:success:failure:
@abstract 此接口用于三方用户中心同步微信用户信息
@param appId  微信应用的app_id
@param openId  微信用户open_id
@param unionId  微信用户union_id
@param nickName  微信用户的昵称
@param headImgUrl  微信用户的头像
@param success 成功的block，参数是绑定之后的用户信息
@param failure 失败的block
*/
+ (void)syncWeChat:(NSString *)appId openId:(NSString *)openId unionId:(NSString *)unionId nickName:(NSString *)nickName headImgUrl:(NSString *)headImgUrl success:(FissionSdkUserBindSuccessBlock)success failure:(FissionSdkFailureBlock)failure;

/*!
@method registerByFacebook:accessToken:success:failure:
@abstract 此接口用于新安装用户直接使用Facebook注册
@param openId  facebook用户的open_id
@param accessToken facebook用户的授权码token
@param success 成功的block，参数是绑定之后的用户信息
@param failure 失败的block
*/
+ (void)registerByFacebook:(NSString *)openId accessToken:(NSString *)accessToken success:(FissionSdkUserBindSuccessBlock)success failure:(FissionSdkFailureBlock)failure;

/*!
@method registerByGoogle:success:failure:
@abstract 此接口用于新安装用户直接使用Google账号注册
@param idToken  google用户的id_token
@param success 成功的block，参数是绑定之后的用户信息
@param failure 失败的block
*/
+ (void)registerByGoogle:(NSString *)idToken success:(FissionSdkUserBindSuccessBlock)success failure:(FissionSdkFailureBlock)failure;

/*!
@method registerByApple:appleToken:success:failure:
@abstract 此接口用于新安装用户直接使用Apple注册
@param appleName  apple用户名，可为nil
@param appleToken Apple用户登录后获取的token
@param success 成功的block，参数是绑定之后的用户信息
@param failure 失败的block
*/
+ (void)registerByApple:(NSString * _Nullable)appleName appleToken:(NSString *)appleToken success:(FissionSdkUserBindSuccessBlock)success failure:(FissionSdkFailureBlock)failure;

/*!
@method getSignInInfo:failure:
@abstract 此接口用于获取指定用户的签到数据
@param success 成功的block，参数是用户的签到信息
@param failure 失败的block
*/
+ (void)getSignInInfo:(FissionSdkUserSignInInfoSuccessBlock)success failure:(FissionSdkFailureBlock)failure;

/*!
@method userSignIn:failure:
@abstract 此接口用于用户签到
@param success 成功的block，参数是用户的签到信息
@param failure 失败的block
*/
+ (void)userSignIn:(FissionSdkUserSignInSuccessBlock)success failure:(FissionSdkFailureBlock)failure;

/*!
@method userSignInWithDraw:remark:comment:successfailure:
@abstract 此接口用于用户签到提现，当前仅支持自有微信极速提现
@param remark 支付备注，将显示在微信红包中20字符（10汉字）内，禁止特殊字符
@param comment 客户端备注信息，可为空
@param success 成功的block，参数是用户提现结果
@param failure 失败的block
*/
+ (void)userSignInWithDraw:(NSString *)remark comment:(NSString * _Nullable)comment success: (FissionSdkRequestWithdrawSuccessBlock)success failure:(FissionSdkFailureBlock)failure;


/*!
@method bindInvitationCode:activityId:successfailure:
@abstract 此接口用于用户绑定师傅的邀请码
@param code 师傅的邀请码
@param activityId 活动id，可为空
@param success 成功的block，参数是绑定成功信息
@param failure 失败的block
*/
+ (void)bindInvitationCode:(NSString *)code activityId:(NSString * _Nullable)activityId success: (FissionSdkBindInvitationSuccessBlock)success failure:(FissionSdkFailureBlock)failure;

/*!
@method getInvitationRecords:withDetail:pageSize:pageIndex:successfailure:
@abstract 此接口用于查询指定日期或所有的用户邀请记录，返回按邀请时间倒序排列
@param day  指定邀请日期，格式：yyyy-MM-dd
@param withDetail 返回邀请记录明细。1：是，0：否
@param pageSize  每页数量，输入0表示使用默认值，默认30
@param pageIndex 页码，从1开始，输入0表示使用默认值，默认1
@param success 成功的block，参数是邀请记录
@param failure 失败的block
*/
+ (void)getInvitationRecords:(NSString * _Nullable)day withDetail:(BOOL)withDetail pageSize:(int)pageSize pageIndex:(int)pageIndex success: (FissionSdkInvitationRecordSuccessBlock)success failure:(FissionSdkFailureBlock)failure;

/*!
@method getInviterRecordsBegin:end:pageSize:pageIndex:successfailure:
@abstract 此接口用于师傅查询指定时间范围的邀请的徒弟的信息记录，返回按邀请时间倒序排列
@param beginTime  开始时间戳，单位：秒
@param endTime  结束时间戳，单位：秒
@param pageSize  每页数量，输入0表示使用默认值，默认30
@param pageIndex 页码，从1开始，输入0表示使用默认值，默认1
@param success 成功的block，参数是邀请记录
@param failure 失败的block
*/
+ (void)getInviterRecordsBegin:(long)beginTime end:(long)endTime pageSize:(int)pageSize pageIndex:(int)pageIndex success: (FissionSdkInvitationRecordSuccessBlock)success failure:(FissionSdkFailureBlock)failure;

@end

NS_ASSUME_NONNULL_END
