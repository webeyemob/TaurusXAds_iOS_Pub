//
//  FissionSdkType.h
//  FissionSdk
//
//  Created by zena.tang on 2020/12/14.
//  Copyright © 2020 TaurusXAds. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface FissionSdkType : NSObject

typedef NS_ENUM(NSInteger, FISSIONSDK_MISSION_LIMITTYPE) {
    FISSIONSDK_MISSION_LIMITTYPE_NONE               = 0, //无限制
    FISSIONSDK_MISSION_LIMITTYPE_GLOBAL             = 1, //全局次数限制
    FISSIONSDK_MISSION_LIMITTYPE_DAILY              = 2, //每日次数限制
    FISSIONSDK_MISSION_LIMITTYPE_INTERVAL_DAYS      = 3, //最小间隔天数
    FISSIONSDK_MISSION_LIMITTYPE_INTERVAL_MINUTES   = 4  //最小间隔分钟数
};


typedef NS_ENUM(NSInteger, FISSIONSDK_MISSION_BONUSTYPE) {
    FISSIONSDK_MISSION_BONUSTYPE_COIN               = 0, //金币
    FISSIONSDK_MISSION_BONUSTYPE_CASH               = 1  //现金
};

typedef NS_ENUM(NSInteger, FISSIONSDK_MISSION_COSTTYPE) {
    FISSIONSDK_MISSION_COSTTYPE_NONE               = 0, //无
    FISSIONSDK_MISSION_COSTTYPE_COIN               = 1, //金币
    FISSIONSDK_MISSION_COSTTYPE_CASH               = 2  //现金
};

+ (FISSIONSDK_MISSION_LIMITTYPE)matchLimieType:(NSString *)limitType;
+ (FISSIONSDK_MISSION_BONUSTYPE)matchBounsType:(NSString *)bonusType;
+ (FISSIONSDK_MISSION_COSTTYPE)matchCostType:(NSString *)costType;

@end

NS_ASSUME_NONNULL_END
