//
//  FissionSdkMission.h
//  FissionSdk
//
//  Created by zena.tang on 2020/12/14.
//  Copyright © 2020 TaurusXAds. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FissionSdkError.h"
#import "FissionSdkMissionRecord.h"

NS_ASSUME_NONNULL_BEGIN

typedef void (^FissionSdkGetMissionSuccessBlock)(NSArray *missions);
typedef void (^FissionSdkMissionSubmitSuccessBlock)(FissionSdkMissionSubmitResult *result);
typedef void (^FissionSdkMissionQuerySuccessBlock)(FissionSdkMissionQueryResult *result);
typedef void (^FissionSdkMissionQueryCountSuccessBlock)(FissionSdkMissionQueryCountResult *result);
typedef void (^FissionSdkMissionTodayCoinsSuccessBlock)(FissionSdkMissionTodayCoinsResult *result);


/*!
包含激励任务 API.的类
*/
@interface FissionSdkMission : NSObject

/*!
@method getMissionInfo
@abstract 获取激励任务列表
@param success 成功的block，参数是激励任务列表
@param failure 失败的block
*/
+ (void)getMissionInfo:(FissionSdkGetMissionSuccessBlock)success failure:(FissionSdkFailureBlock)failure;

/*!
@method submitMissionInfo
@abstract 此接口用于完成激励任务后领取奖励
@param missionId 任务ID
@param multiple 翻倍倍数，默认1不翻倍，可为空
@param bonus 客户端指定的奖励数量
@param cost   客户端指定的消耗数量
@param success 成功的block，参数是激励结果
@param failure 失败的block
*/
+ (void)submitMissionInfo:(NSString *)missionId multiple:(NSString * _Nullable)multiple bouns:(float)bonus cost:(float)cost success:(FissionSdkMissionSubmitSuccessBlock)success failure:(FissionSdkFailureBlock)failure;

/*!
@method missionMultiply
@abstract 此接口用于激励任务奖励翻倍，通常用于观看激励视屏场景。（仅对支持翻倍的任务有效）
@param missionId 任务ID
@param recordId  激励领取记录id
@param multiple 翻倍倍数
@param success 成功的block，参数是激励结果
@param failure 失败的block
*/
+ (void)missionMultiply:(NSString *)missionId recordId:(NSString *)recordId multiple:(NSString *)multiple success:(FissionSdkMissionSubmitSuccessBlock)success failure:(FissionSdkFailureBlock)failure;

/*!
@method missionQuary
@abstract 此接口用于查询指定天数内的特定类型任务记录，返回按任务完成时间倒序排列，比如查询7天内的签到记录
@param missionId 任务ID,nil表示查询所有任务
@param days  天数，1表示查当天，为0表示默认查当天
@param pageSize  每页数量，输入0表示使用默认值，默认30
@param pageIndex 页码，从1开始，输入0表示使用默认值，默认1
@param success 成功的block，参数是任务记录
@param failure 失败的block
*/
+ (void)missionQuary:(NSString * _Nullable)missionId days:(int)days pageSize:(int)pageSize pageIndex:(int)pageIndex success:(FissionSdkMissionQuerySuccessBlock)success failure:(FissionSdkFailureBlock)failure;

/*!
@method missionCount
@abstract 此接口用于查询指定天数内的特定类型任务数量，返回按任务完成时间倒序排列，比如查询7天内的签到记录
@param missionId 任务ID
@param days  天数，1表示查当天，为0表示默认查当天
@param success 成功的block，参数是任务数量信息
@param failure 失败的block
*/
+ (void)missionCount:(NSString *)missionId days:(int)days success:(FissionSdkMissionQueryCountSuccessBlock)success failure:(FissionSdkFailureBlock)failure;

/*!
@method getTodayCoins
@abstract 此接口用于查询用户今日的任务金币数获取信息
@param success 成功的block，参数是用户今天金币数量信息
@param failure 失败的block
*/
+ (void)getTodayCoins:(FissionSdkMissionTodayCoinsSuccessBlock)success failure:(FissionSdkFailureBlock)failure;

/*!
@method getInviteeInfo
@abstract 此接口用于获取被邀请者任务列表 （被邀请者任务是指邀请关系中，由被邀请者完成，奖励发放给邀请者的任务）
@param success 成功的block，参数是激励任务列表
@param failure 失败的block
*/
+ (void)getInviteeInfo:(FissionSdkGetMissionSuccessBlock)success failure:(FissionSdkFailureBlock)failure;

/*!
@method submitInvitee
@abstract 此接口用于完成被邀请者任务后提交，奖励发放给其邀请者
@param missionId 任务ID
@param bonus  客户端指定奖励，可以为0
@param success 成功的block，参数是任务完成结果
@param failure 失败的block
*/
+ (void)submitInvitee:(NSString *)missionId bonus:(int)bonus success:(FissionSdkMissionSubmitSuccessBlock)success failure:(FissionSdkFailureBlock)failure;

/*!
@method queryInVitee
@abstract 此接口用于查询指定天数内的特定类型任务记录，返回按任务完成时间倒序排列，比如查询7天内的签到记录
@param missionId 任务ID
@param role  指定邀请关系中的角色，0表示作为被邀请者的任务记录，1表示作为邀请者的任务记录, 不填默认为0
@param days  天数，1表示查当天，为0表示默认查当天
@param pageSize  每页数量，输入0表示使用默认值，默认30
@param pageIndex 页码，从1开始，输入0表示使用默认值，默认1
@param success 成功的block，参数是任务完成结果
@param failure 失败的block
*/
+ (void)queryInVitee:(NSString *)missionId role:(int)role days:(int)days pageSize:(int)pageSize pageIndex:(int)pageIndex success:(FissionSdkMissionQuerySuccessBlock)success failure:(FissionSdkFailureBlock)failure;

@end

NS_ASSUME_NONNULL_END
