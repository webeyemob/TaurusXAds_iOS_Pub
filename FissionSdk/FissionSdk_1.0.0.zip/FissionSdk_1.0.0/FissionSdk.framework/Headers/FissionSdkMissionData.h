//
//  FissionSdkMissionData.h
//  FissionSdk
//
//  Created by zena.tang on 2020/12/14.
//  Copyright © 2020 TaurusXAds. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FissionSdkType.h"

NS_ASSUME_NONNULL_BEGIN

@interface FissionSdkMissionData : NSObject

@property (nonatomic, strong, readonly) NSString *id;     //mission-id
@property (nonatomic, strong, readonly) NSString *name;   //name
@property (nonatomic, readonly) FISSIONSDK_MISSION_LIMITTYPE limitType;   //限制类型：global，全局，每日，间隔
@property (nonatomic, readonly) int limit;                                //限制次数

@property (nonatomic, readonly) FISSIONSDK_MISSION_BONUSTYPE bonusType;   //奖励类型：金币 or 现金
@property (nonatomic, readonly) int bonus;                                //奖励数
@property (nonatomic, readonly) int bonusMax;                             //最大奖励数

@property (nonatomic, readonly) FISSIONSDK_MISSION_COSTTYPE costType;     //消耗类型：none。金币，现金
@property (nonatomic, readonly) int cost;                                 //消耗数

@property (nonatomic, readonly) BOOL supportMultiply;                     //是否支持翻倍
@property (nonatomic, readonly) BOOL supportclientControl;                //是否支持客户端控制

@property (nonatomic, readonly) int maxMultiply;                          //最大翻倍数
@property (nonatomic, readonly) int dailyBonusLimit;                      //每日奖励限制

- (instancetype) initWithResponse:(NSDictionary *)dic;

@end

NS_ASSUME_NONNULL_END
