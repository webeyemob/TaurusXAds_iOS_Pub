//
//  FissionSdkPeriodActivity.h
//  FissionSdk
//
//  Created by zena.tang on 2020/12/15.
//  Copyright © 2020 TaurusXAds. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FissionSdkActivityData.h"
#import "FissionSdkError.h"

NS_ASSUME_NONNULL_BEGIN

typedef void (^FissionSdkGetActivityInfoSuccessBlock)(NSArray <FissionSdkActivityData *>* activitys);
typedef void (^FissionSdkGetActivityAccountInfoSuccessBlock)(FissionSdkActivityAccountData *data);
typedef void (^FissionSdkGetActivityGiftInfoSuccessBlock)(NSArray <FissionSdkActivityGiftData *> *gifts);
typedef void (^FissionSdkGetActivityUserGiftsInfoSuccessBlock)(NSArray <FissionSdkUserGiftData *> *gifts);

typedef void (^FissionSdkGetActivityExchangeGiftSuccessBlock)(FissionSdkExchangeGiftResult *result);


/*!
包含周期活动 API.的类
*/
@interface FissionSdkPeriodActivity : NSObject

/*!
@method getActivityInfo
@abstract 此接口用于查询指定的活动信息，返回当前进行中的活动以及下一期活动（如果存在）
@param activityId 活动ID
@param success 成功的block，参数是周期任务列表
@param failure 失败的block
*/
+ (void)getActivityInfo:(NSString *)activityId success:(FissionSdkGetActivityInfoSuccessBlock)success failure:(FissionSdkFailureBlock)failure;

/*!
@method getActivityAccountInfo
@abstract 此接口用于查询指定活动和期数的用户账户信息，返回用户的账户相关信息
@param activityId 活动ID
@param periodId 活动期数id
@param success 成功的block，参数是用户账户信息
@param failure 失败的block
*/
+ (void)getActivityAccountInfo:(NSString *)activityId periodId:(NSString *)periodId success:(FissionSdkGetActivityAccountInfoSuccessBlock)success failure:(FissionSdkFailureBlock)failure;

/*!
@method getActivityGiftInfo
@abstract 此接口用于查询当期的活动奖品信息，返回当前进行中的活动的奖品库存以及客户端附属信息等
@param activityId 活动ID
@param periodId 活动期数id
@param success 成功的block，参数是活动奖品信息
@param failure 失败的block
*/
+ (void)getActivityGiftInfo:(NSString *)activityId periodId:(NSString *)periodId success:(FissionSdkGetActivityGiftInfoSuccessBlock)success failure:(FissionSdkFailureBlock)failure;


/*!
@method getUserGiftsInfo
@abstract 此接口用于查询指定活动和期数的用户兑奖信息，返回用户兑奖请求提交的相关信息
@param activityId 活动ID
@param periodId 活动期数id
@param success 成功的block，参数是用户兑奖请求提交
@param failure 失败的block
*/
+ (void)getUserGiftsInfo:(NSString *)activityId periodId:(NSString *)periodId success:(FissionSdkGetActivityUserGiftsInfoSuccessBlock)success failure:(FissionSdkFailureBlock)failure;

/*!
@method updateUserGiftInfo
@abstract 此接口用于修改指定活动和期数的用户兑奖信息：用户姓名、联系方式、收货地址等，此接口在指定活动的有效兑奖时间范围内可用
@param activityId 活动ID
@param periodId 活动期数id
@param giftInfo 更新的用户兑奖信息，该结构通过- (instancetype) initWithRecordId:(NSString *)recordId realName:(NSString *)realName contact:(NSString *)contact addr:(NSString *)addr comment:(NSString * _Nullable)comment创建
@param success 成功的block，无参数
@param failure 失败的block
*/
+ (void)updateUserGiftInfo:(NSString *)activityId periodId:(NSString *)periodId giftInfo:(FissionSdkUserGiftData *)giftInfo success:(FissionSdkCommonSuccessBlock)success failure:(FissionSdkFailureBlock)failure;

/*!
@method exchangeGift
@abstract 此接口用于用户兑换活动指定奖品，此接口在指定活动的有效兑奖时间范围内可用
@param activityId 活动ID
@param periodId 活动期数id
@param giftInfo 更新的用户兑奖信息，该结构通过- (instancetype) initWithGiftId:(NSString *)giftId realName:(NSString *)realName contact:(NSString *)contact addr:(NSString *)addr comment:(NSString * _Nullable)comment创建
@param success 成功的block，参数是兑换结果FissionSdkExchangeGiftResult
@param failure 失败的block
*/
+ (void)exchangeGift:(NSString *)activityId periodId:(NSString *)periodId giftInfo:(FissionSdkUserGiftData *)giftInfo success:(FissionSdkGetActivityExchangeGiftSuccessBlock)success failure:(FissionSdkFailureBlock)failure;

/*!
@method exchangeCoin
@abstract 此接口用于用户账户现金兑换活动积分，此接口在指定活动的有效兑奖时间范围内可用
@param activityId 活动ID
@param periodId 活动期数id
@param cash 现金数值，单位：元，最小为0.01
@param comment 请求备注，非必传
@param success 成功的block，参数是兑换结果FissionSdkExchangeGiftResult
@param failure 失败的block
*/
+ (void)exchangeCoin:(NSString *)activityId periodId:(NSString *)periodId cash:(float)cash comment:(NSString * _Nullable)comment success:(FissionSdkRequestWithdrawSuccessBlock)success failure:(FissionSdkFailureBlock)failure;


/*!
@method requestActivityWithdraw
@abstract 此接口用于用户活动提现操作（一次性提出账户所有现金），此接口在指定活动的有效提现时间范围内可用
@param activityId 活动ID
@param periodId 活动期数id
@param realName 真实姓名
@param idCard 用户身份证号
@param payRemark 支付备注，将显示在微信红包中，20字符（10汉字）内，禁止特殊字符
@param phoneNo  用户手机号，根据系统开关，如果当前提现通道需要提供手机号，则必须传入
@param comment 请求备注，非必传
@param success 成功的block，参数是提现结果
@param failure 失败的block
*/
+ (void)requestActivityWithdraw:(NSString *)activityId periodId:(NSString *)periodId realName:(NSString *)realName idCard:(NSString *)idCard payRemark:(NSString *)payRemark phoneNo:(NSString *)phoneNo comment: (NSString *)comment success: (FissionSdkRequestWithdrawSuccessBlock)success failure:(FissionSdkFailureBlock)failure;

/*!
@method requestFragmentGift
@abstract 此接口用于用户参与集碎片活动的兑奖，此接口在指定活动的有效时间范围内可用
@param activityId 活动ID
@param periodId 活动期数id
@param giftInfo 礼品兑换信息，该结构通过- (instancetype) initWithGiftId:(NSString *)giftId realName:(NSString *)realName contact:(NSString *)contact addr:(NSString *)addr comment:(NSString * _Nullable)comment创建
@param success 成功的block，参数是礼品兑换结果
@param failure 失败的block
*/
+ (void)requestFragmentGift:(NSString *)activityId periodId:(NSString *)periodId giftInfo:(FissionSdkUserGiftData *)giftInfo success:(FissionSdkGetActivityExchangeGiftSuccessBlock)success failure:(FissionSdkFailureBlock)failure;

@end

NS_ASSUME_NONNULL_END
