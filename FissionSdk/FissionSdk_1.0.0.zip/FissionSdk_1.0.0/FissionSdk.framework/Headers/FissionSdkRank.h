//
//  FissionSdkRank.h
//  FissionSdk
//
//  Created by zena.tang on 2020/12/14.
//  Copyright © 2020 TaurusXAds. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FissionSdkError.h"
#import "FissionSdkUserRankData.h"

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, FISSIONSDK_USERRANK_CONDITION) {
    FISSIONSDK_USERRANK_CONDITION_COIN           = 0, // 金币
    FISSIONSDK_USERRANK_CONDITION_CASH           = 1  // 现金
};

typedef void (^FissionSdkUserGetRankSuccessBlock)(NSArray *ranks);
typedef void (^FissionSdkUserGetRankingListSuccessBlock)(FissionSdkUserRankingList *rankList);

/*!
包含排行榜 API.的类
*/
@interface FissionSdkRank : NSObject

/*!
@method getUserRank:allUser:condition:success:failure
@abstract 此接口用于获取用户金币或现金排行
@param count 排行榜数量
@param allUser YES: 返回所有用户, NO:仅返回绑定社交账户用户数id
@param condition coin: 按金币余额排行,cash: 按现金余额排行
@param success 成功的block，参数是排行列表
@param failure 失败的block
*/
+ (void)getUserRank: (int)count allUser:(BOOL)allUser condition:(FISSIONSDK_USERRANK_CONDITION)condition success:(FissionSdkUserGetRankSuccessBlock)success failure:(FissionSdkFailureBlock)failure;

/*!
@method rankingReportParam:value:success:failure
@abstract 此接口用于上报参与排行榜的用户数据
@param rankId 排行榜id
@param value 用户整数数据
@param success 成功的block，无参数
@param failure 失败的block
*/
+ (void)rankingReportParam:(NSString *)rankId value:(int)value success:(FissionSdkCommonSuccessBlock)success failure:(FissionSdkFailureBlock)failure;

/*!
@method getRankingList:includeHistory:success:failure
@abstract 此接口用于获取用户参与的排行榜记录信息
@param rankId 排行榜id
@param includeHistory 是否查询历史榜单，NO：否，YES：是。
@param success 成功的block，参数是用户排行列表
@param failure 失败的block
*/
+ (void)getRankingList:(NSString *)rankId includeHistory:(BOOL)includeHistory success:(FissionSdkUserGetRankingListSuccessBlock)success failure:(FissionSdkFailureBlock)failure;

@end

NS_ASSUME_NONNULL_END
