//
//  FissionSdkActivityData.h
//  FissionSdk
//
//  Created by zena.tang on 2020/12/15.
//  Copyright © 2020 TaurusXAds. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FissionSdkWithdraw.h"

NS_ASSUME_NONNULL_BEGIN

@interface FissionSdkActivityDetailData : NSObject

@property (nonatomic, strong, readonly) NSString *activity;            //活动ID
@property (nonatomic, strong, readonly) NSString *url;                 //周期ID
@property (nonatomic, strong, readonly) NSString *desc;                //描述

- (instancetype) initWithResponse:(NSDictionary *)dic;

@end


@interface FissionSdkActivityData : NSObject

@property (nonatomic, strong, readonly) NSString *activityId;            //活动ID
@property (nonatomic, strong, readonly) NSString *periodId;              //周期ID
@property (nonatomic, strong, readonly) NSString *startAt;               //开始时间 "2019-11-14T16:00:00Z"
@property (nonatomic, strong, readonly) NSString *endAt;                 //结束时间 "2019-12-14T16:00:00Z"
@property (nonatomic, strong, readonly) NSString *playEnd;               //结束时间 "2019-12-14T16:00:00Z"
@property (nonatomic, strong, readonly) NSString *exchangeStart;         //兑换开始时间 "2019-11-14T16:00:00Z"
@property (nonatomic, strong, readonly) NSString *exchangeEnd;           //兑换结束时间 "2019-12-14T16:00:00Z"
@property (nonatomic, strong, readonly) NSString *withdrawStart;         //提现开始时间 "2019-11-14T16:00:00Z"
@property (nonatomic, strong, readonly) NSString *withdrawEnd;           //提现结束时间 "2019-12-14T16:00:00Z"
@property (nonatomic, readonly) int cashExchangeRate;                    //汇率
@property (nonatomic, readonly) float minWithdrawCash;                   //最小提现额度
@property (nonatomic, readonly) float maxWithdrawCash;                   //最大提现额度
@property (nonatomic, readonly) int giftExchangeLimit;                   //礼品兑换限制
@property (nonatomic, readonly) BOOL isCurrent;                          //是否是当前进行中的活动

@property (nonatomic, strong, readonly) FissionSdkActivityDetailData *detail;  //详细信息

- (instancetype) initWithResponse:(NSDictionary *)dic;

@end

@interface FissionSdkActivityAccountData : NSObject

@property (nonatomic, strong, readonly) NSString *activityId;            //活动ID
@property (nonatomic, strong, readonly) NSString *periodId;              //周期ID
@property (nonatomic, strong, readonly) NSString *userId;                //用户ID
@property (nonatomic, readonly) int coin;                                //金币
@property (nonatomic, readonly) float cash;                              //现金
@property (nonatomic, readonly) int withdrawCount;                       //提现次数
@property (nonatomic, readonly) int exchangeCount;                       //兑换次数

- (instancetype) initWithResponse:(NSDictionary *)dic;

@end

@interface FissionSdkActivityGiftData : NSObject

@property (nonatomic, readonly) int order;                               //次序
@property (nonatomic, strong, readonly) NSString *giftId;                //礼品ID
@property (nonatomic, strong, readonly) NSString *giftName;              //礼品名字
@property (nonatomic, readonly) int coin;                                //金币
@property (nonatomic, readonly) int stock;                               //库存
@property (nonatomic, readonly) int consumeStock;                       //库存消耗

@property (nonatomic, strong, readonly) FissionSdkActivityDetailData *detail;  //详细信息

- (instancetype) initWithResponse:(NSDictionary *)dic;

@end

@interface FissionSdkUserGiftData : NSObject

@property (nonatomic, strong, readonly) NSString *recordId;              //礼品兑换记录ID
@property (nonatomic, strong, readonly) NSString *giftId;                //礼品ID
@property (nonatomic, strong, readonly) NSString *giftName;              //礼品名字
@property (nonatomic, strong, readonly) NSString *realName;              //礼品名字
@property (nonatomic, strong, readonly) NSString *contact;               //联系人
@property (nonatomic, strong, readonly) NSString *userAddr;               //用户地址
@property (nonatomic, strong, readonly) NSString *comment;               //备注

@property (nonatomic, strong, readonly) FissionSdkActivityDetailData *detail;  //详细信息


- (instancetype) initWithResponse:(NSDictionary *)dic;

//用于用户兑奖信息修改
- (instancetype) initWithRecordId:(NSString *)recordId realName:(NSString *)realName contact:(NSString *)contact addr:(NSString *)addr comment:(NSString * _Nullable)comment;

//用于积分兑奖品
- (instancetype) initWithGiftId:(NSString *)giftId realName:(NSString *)realName contact:(NSString *)contact addr:(NSString *)addr comment:(NSString * _Nullable)comment;

@end

@interface FissionSdkExchangeGiftResult : FissionSdkWithdrawResult

@property (nonatomic, strong, readonly) NSString *recordId;              //礼品记录ID

- (instancetype) initWithResponse:(NSDictionary *)dic;

@end



NS_ASSUME_NONNULL_END
