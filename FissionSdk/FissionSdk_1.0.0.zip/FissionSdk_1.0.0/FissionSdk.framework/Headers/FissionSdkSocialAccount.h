//
//  FissionSdkSocialAccount.h
//  FissionSdk
//
//  Created by zena.tang on 2020/12/14.
//  Copyright © 2020 TaurusXAds. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface FissionSdkSocialAccount : NSObject

- (instancetype) initWithAccountDic:(NSDictionary *)dic;

@end


@interface FissionSdkWechatAccount : FissionSdkSocialAccount

@property (nonatomic, strong, readonly) NSString *appId;               //用户唯一标识
@property (nonatomic, strong, readonly) NSString *openId;              //微信用户的open-id
@property (nonatomic, strong, readonly) NSString *unionId;             //微信用户的union-id
@property (nonatomic, strong, readonly) NSString *nickName;            //微信用户的昵称
@property (nonatomic, readonly) int sex;                                //性别
@property (nonatomic, strong, readonly) NSString *province;             //省份
@property (nonatomic, strong, readonly) NSString *city;                 //城市
@property (nonatomic, strong, readonly) NSString *country;              //国家
@property (nonatomic, strong, readonly) NSString *avatar;               //头像地址

@end

@interface FissionSdkGoogleAccount : FissionSdkSocialAccount

@property (nonatomic, strong, readonly) NSString *id;               //用户唯一标识
@property (nonatomic, strong, readonly) NSString *googleSub;        //google用户的
@property (nonatomic, strong, readonly) NSString *name;             //昵称
@property (nonatomic, strong, readonly) NSString *familyName;       //姓
@property (nonatomic, strong, readonly) NSString *givenName;        //名
@property (nonatomic, strong, readonly) NSString *email;            //email
@property (nonatomic, strong, readonly) NSString *avatar;           //头像地址

@end

@interface FissionSdkFacebookAccount : FissionSdkSocialAccount

@property (nonatomic, strong, readonly) NSString *openId;           //facebook用户的唯一标识
@property (nonatomic, strong, readonly) NSString *name;             //昵称
@property (nonatomic, strong, readonly) NSString *firstName;        //名
@property (nonatomic, strong, readonly) NSString *lastName;         //姓
@property (nonatomic, strong, readonly) NSString *email;            //email

@end

@interface FissionSdkAppleAccount : FissionSdkSocialAccount

@property (nonatomic, strong, readonly) NSString *appleSub;           //apple用户的唯一标识
@property (nonatomic, strong, readonly) NSString *name;               // app name
@end

NS_ASSUME_NONNULL_END
