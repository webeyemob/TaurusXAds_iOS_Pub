//
//  FissionSdkUserRankData.h
//  FissionSdk
//
//  Created by zena.tang on 2020/12/14.
//  Copyright © 2020 TaurusXAds. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface FissionSdkUserRankData : NSObject

@property (nonatomic, strong, readonly) NSString *userId;             //id
@property (nonatomic, strong, readonly) NSString *name;               //name
@property (nonatomic, strong, readonly) NSString *avatar;             //头像
@property (nonatomic, readonly) int coin;                             //金币数量
@property (nonatomic, readonly) float cash;                           //现金数量

- (instancetype) initWithResponse:(NSDictionary *)dic;

@end

@interface FissionSdkUserRankingSeq : NSObject

@property (nonatomic, readonly) int seqNo;                            //序号
@property (nonatomic, strong, readonly) NSString *userId;             //用户id
@property (nonatomic, strong, readonly) NSString *name;               //name
@property (nonatomic, strong, readonly) NSString *avatar;             //头像
@property (nonatomic, readonly) int value;                            //数值

- (instancetype) initWithResponse:(NSDictionary *)dic;

@end

@interface FissionSdkUserRankingList : NSObject

@property (nonatomic, strong, readonly) NSString *rankingId;                            //排行榜id
@property (nonatomic, strong, readonly) NSArray <FissionSdkUserRankingSeq *> *records;  //记录列表

- (instancetype) initWithResponse:(NSDictionary *)dic;

@end


NS_ASSUME_NONNULL_END
