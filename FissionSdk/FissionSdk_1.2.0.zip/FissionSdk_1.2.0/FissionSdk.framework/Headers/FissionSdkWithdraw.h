//
//  FissionSdkWithdraw.h
//  FissionSdk
//
//  Created by zena.tang on 2020/12/14.
//  Copyright © 2020 TaurusXAds. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FissionSdkWithdrawData.h"
#import "FissionSdkError.h"


NS_ASSUME_NONNULL_BEGIN

@interface FissionSdkWithdrawResult : NSObject

@property (nonatomic, readonly) int coinDelta;                                  //金币变动
@property (nonatomic, readonly) float cashDelta;                                //现金变动
@property (nonatomic, readonly) int currentCoin;                                //当前金币
@property (nonatomic, readonly) float currentCash;                              //当前现金

- (instancetype) initWithResponse:(NSDictionary *)dic;

@end


@interface FissionSdkWithdrawSetting : NSObject

@property (nonatomic, readonly) int minCoin;                                    //金币最小限制
@property (nonatomic, readonly) int minVersion;                                 //最小版本限制
@property (nonatomic, readonly) BOOL isFree;                                    //是否免费
@property (nonatomic, readonly) float amount;                                     //数量
@property (nonatomic, readonly) int limit;                                      //限制
@property (nonatomic, readonly) int consecutiveDays;                            //连续天数

- (instancetype) initWithResponse:(NSDictionary *)dic;

@end



typedef void (^FissionSdkGetWithdrawSuccessBlock)(FissionSdkWithdrawData *data);
typedef void (^FissionSdkRequestWithdrawSuccessBlock)(FissionSdkWithdrawResult *data);

/*!
包含提现 API.的类
*/
@interface FissionSdkWithdraw : NSObject

/*!
@method getWithdrawInfo
@abstract 此接口用于获取提现任务信息，以及用户提现记录，当日汇率等
@param success 成功的block，参数是FissionSdkWithdrawData
@param failure 失败的block
*/
+ (void)getWithdrawInfo:(FissionSdkGetWithdrawSuccessBlock)success failure:(FissionSdkFailureBlock)failure;

/*!
@method requestWithdraw
@abstract 此接口用于发起提现请求，客户端需根据当前系统配置的提现通道传入相关参数
@param missionId 激励任务ID
@param realName 真实姓名
@param idCard 用户身份证号
@param payRemark 支付备注，将显示在微信红包中，20字符（10汉字）内，禁止特殊字符
@param phoneNo  用户手机号，根据系统开关，如果当前提现通道需要提供手机号，则必须传入
@param channel 提现通道标识 ，传入当前系统配置的提现通道标识。
@param success 成功的block，参数是提现结果
@param failure 失败的block
*/
+ (void)requestWithdraw:(NSString *)missionId realName:(NSString *)realName idCard:(NSString *)idCard payRemark:(NSString *)payRemark phoneNo:(NSString * _Nullable)phoneNo channel:(NSString * _Nullable)channel success: (FissionSdkRequestWithdrawSuccessBlock)success failure:(FissionSdkFailureBlock)failure;


/*!
@method requestWXPay
@abstract 此接口用于发起微信企业付款提现请求，目前仅支持极速提现的场景
@param missionId 激励任务ID
@param payRemark 支付备注，将显示在微信红包中，20字符（10汉字）内，禁止特殊字符
@param comment 客户端备注信息,可为nil。
@param success 成功的block，参数是提现结果
@param failure 失败的block
*/
+ (void)requestWXPay:(NSString *)missionId  payRemark:(NSString *)payRemark comment:(NSString * _Nullable)comment success: (FissionSdkRequestWithdrawSuccessBlock)success failure:(FissionSdkFailureBlock)failure;

/*!
@method requestAliPay
@abstract 此接口用于用户发起支付宝提现请求，目前仅支持极速提现的场景
@param missionId 激励任务ID
@param payRemark 支付备注，将显示在微信红包中，20字符（10汉字）内，禁止特殊字符
@param comment 客户端备注信息,可为nil。
@param success 成功的block，参数是提现结果
@param failure 失败的block
*/
+ (void)requestAliPay:(NSString *)missionId payRemark:(NSString *)payRemark comment:(NSString *)comment success: (FissionSdkRequestWithdrawSuccessBlock)success failure:(FissionSdkFailureBlock)failure;

@end

NS_ASSUME_NONNULL_END
