//
//  BaiduAdMode.h
//  TaurusXAdMediation_Baidu
//
//  Created by TaurusXAds on 2020/2/3.
//  Copyright © 2020 TaurusXAds. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSUInteger, TXADBaiduNativeMode) {
    TXAD_BAIDU_NATIVE_NORMAL = 0,           // 原生
    TXAD_BAIDU_NATIVE_EXPRESS = 1,          // H5【未测试出广告】
    TXAD_BAIDU_NATIVE_EXPRESS_CAROUSEL = 2, // H5 轮播【未测试出广告】
    TXAD_BAIDU_NATIVE_SMART_OPT = 3,        // 智能优选
    TXAD_BAIDU_NATIVE_PATCH_VIDEO = 4,      // 贴片广告【未测试出广告】
    TXAD_BAIDU_NATIVE_PORTRAIT_VIDEO = 5    // 小视频
};

typedef NS_ENUM(NSUInteger, TXADBaiduFeedListMode) {
    TXAD_BAIDU_FEEDLIST_NATIVE = 0,           // 原生
    TXAD_BAIDU_FEEDLIST_EXPRESS = 1,          // H5【未测试出广告】
    TXAD_BAIDU_FEEDLIST_EXPRESS_CAROUSEL = 2, // H5 轮播【未测试出广告】
    TXAD_BAIDU_FEEDLIST_SMART_OPT = 3,        // 智能优选
    TXAD_BAIDU_FEEDLIST_PATCH_VIDEO = 4,      // 贴片广告【未测试出广告】
    TXAD_BAIDU_FEEDLIST_PORTRAIT_VIDEO = 5    // 小视频
};

typedef NS_ENUM(NSUInteger, TXADBaiduInterstitalType) {
    TXAD_BAIDU_INTERSTITIAL_TYPE_OTHER = 0,        // 其他
    TXAD_BAIDU_INTERSTITIAL_TYPE_BEFORE_VIDEO = 1, // 前贴
    TXAD_BAIDU_INTERSTITIAL_TYPE_PAUSE_VIDEO = 2   // 暂停
};
