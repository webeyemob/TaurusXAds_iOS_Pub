//
//  BaiduAdMode.h
//  TaurusXAdMediation_Baidu
//
//  Created by TaurusXAds on 2020/2/3.
//  Copyright © 2020 TaurusXAds. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSUInteger, TXADBaiduNativeMode) {
    TXAD_BAIDU_NATIVE_CUSTOM = 0,           // 自渲染
    TXAD_BAIDU_NATIVE_EXPRESS = 1,          // H5【未测试出广告】
    TXAD_BAIDU_NATIVE_EXPRESS_CAROUSEL = 2, // H5 轮播【未测试出广告】
    TXAD_BAIDU_NATIVE_SMART_OPT = 3,        // 智能优选
    TXAD_BAIDU_NATIVE_PATCH_VIDEO = 4,      // 贴片广告【未测试出广告】
    TXAD_BAIDU_NATIVE_PORTRAIT_VIDEO = 5    // 小视频
};

typedef NS_ENUM(NSUInteger, TXADBaiduFeedListMode) {
    TXAD_BAIDU_FEEDLIST_CUSTOM = 0,           // 自渲染
    TXAD_BAIDU_FEEDLIST_EXPRESS = 1,          // H5【未测试出广告】
    TXAD_BAIDU_FEEDLIST_EXPRESS_CAROUSEL = 2, // H5 轮播【未测试出广告】
    TXAD_BAIDU_FEEDLIST_SMART_OPT = 3,        // 智能优选
    TXAD_BAIDU_FEEDLIST_PATCH_VIDEO = 4,      // 贴片广告【未测试出广告】
    TXAD_BAIDU_FEEDLIST_PORTRAIT_VIDEO = 5,    // 小视频
    TXAD_BAIDU_FEEDLIST_BEFORE_VIDEO_INTERSTITIAL = 6, // 前贴插屏
    TXAD_BAIDU_FEEDLIST_PAUSE_VIDEO_INTERSTITIAL = 7   // 暂停插屏
};

typedef NS_ENUM(NSUInteger, TXADBaiduInterstitialMode) {
    TXAD_BAIDU_INTERSTITIAL_NORMAL = 0,          // 插屏
    TXAD_BAIDU_INTERSTITIAL_FULLSCREENVIDEO = 1, // 全屏视频
    TXAD_BAIDU_INTERSTITIAL_EXPRESS = 2          // 模版插屏
};
