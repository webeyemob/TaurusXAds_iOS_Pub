//
//  TaurusXAdMediation_Baidu.h
//  TaurusXAdMediation_Baidu
//
//  Created by TaurusXAds on 2019/11/2.
//  Copyright © 2019年 TaurusXAds. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for TaurusXAdMediation_Baidu.
FOUNDATION_EXPORT double TaurusXAdMediation_BaiduVersionNumber;

//! Project version string for TaurusXAdMediation_Baidu.
FOUNDATION_EXPORT const unsigned char TaurusXAdMediation_BaiduVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TaurusXAdMediation_Baidu/PublicHeader.h>

#import <TaurusXAdMediation_Baidu/TXADBaiduAdMode.h>

#import <TaurusXAdMediation_Baidu/TXADBaiduSplashConfig.h>
#import <TaurusXAdMediation_Baidu/TXADBaiduPatchVideoNativeConfig.h>

