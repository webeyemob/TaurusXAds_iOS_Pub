//
//  GDTAppDelegate+DataDetector.h
//  GDTMobDataDetectorSample
//
//  Created by nimo on 2020/8/25.
//  Copyright © 2020 Tencent. All rights reserved.
//

#import "GDTAppDelegate.h"

NS_ASSUME_NONNULL_BEGIN

@interface GDTAppDelegate (DataDetector)

@end

NS_ASSUME_NONNULL_END
