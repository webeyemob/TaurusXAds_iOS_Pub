//
//  GDTAdViewController+Sample.h
//  GDTMobApp
//
//  Created by royqpwang on 2019/3/26.
//  Copyright © 2019 Tencent. All rights reserved.
//

#import "GDTAdViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface GDTAdViewController (Sample)

@end

NS_ASSUME_NONNULL_END
