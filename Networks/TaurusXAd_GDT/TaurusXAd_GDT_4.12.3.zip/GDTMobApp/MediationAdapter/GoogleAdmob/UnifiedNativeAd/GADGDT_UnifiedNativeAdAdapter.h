//
//  GADGDT_UnifiedNativeAdAdapter.h
//  GDTMobApp
//
//  Created by Nancy on 2019/7/25.
//  Copyright © 2019 Tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "GDTUnifiedNativeAdNetworkAdapterProtocol.h"

NS_ASSUME_NONNULL_BEGIN

@interface GADGDT_UnifiedNativeAdAdapter : NSObject <GDTUnifiedNativeAdNetworkAdapterProtocol>

@end

NS_ASSUME_NONNULL_END
