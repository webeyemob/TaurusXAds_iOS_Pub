//
//  GADGDT_RewardVideoAdAdapter.h
//  GDTMobApp
//
//  Created by royqpwang on 2019/7/16.
//  Copyright © 2019 Tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "GDTRewardVideoAdNetworkAdapterProtocol.h"

NS_ASSUME_NONNULL_BEGIN

@interface GADGDT_RewardVideoAdAdapter : NSObject <GDTRewardVideoAdNetworkAdapterProtocol>

@end

NS_ASSUME_NONNULL_END
