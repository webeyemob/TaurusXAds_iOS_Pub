//
//  GADGDT_SplashAdAdapter.h
//  GDTMobApp
//
//  Created by 胡俊峰 on 2019/12/5.
//  Copyright © 2019 Tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "GDTSplashAdNetworkAdapterProtocol.h"

NS_ASSUME_NONNULL_BEGIN

@interface GADGDT_SplashAdAdapter : NSObject <GDTSplashAdNetworkAdapterProtocol>

@end

NS_ASSUME_NONNULL_END
