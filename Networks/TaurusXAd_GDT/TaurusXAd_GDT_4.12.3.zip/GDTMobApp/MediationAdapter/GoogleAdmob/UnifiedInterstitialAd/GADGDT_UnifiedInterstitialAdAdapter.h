//
//  GADGDT_UnifiedInterstitialAdAdapter.h
//  GDTMobApp
//
//  Created by Nancy on 2019/8/12.
//  Copyright © 2019 Tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "GDTUnifiedinterstitialAdNetworkAdapterProtocol.h"

NS_ASSUME_NONNULL_BEGIN

@interface GADGDT_UnifiedInterstitialAdAdapter : NSObject <GDTUnifiedinterstitialAdNetworkAdapterProtocol>

@end

NS_ASSUME_NONNULL_END
