//
//  MediationAdapterUtil.h
//  GDTMobApp
//
//  Created by royqpwang on 2019/7/18.
//  Copyright © 2019 Tencent. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface MediationAdapterUtil : NSObject

+ (NSMutableDictionary *)getURLParams:(NSString *)url;

@end

NS_ASSUME_NONNULL_END
