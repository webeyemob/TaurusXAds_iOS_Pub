//
//  DataDetectorViewController.h
//  GDTMobApp
//
//  Created by nimo on 2020/8/25.
//  Copyright © 2020 Tencent. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface DataDetectorViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
