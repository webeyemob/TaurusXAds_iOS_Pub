//
//  PlayableAdTestViewController.h
//  GDTMobApp
//
//  Created by Nancy on 2020/8/12.
//  Copyright © 2020 Tencent. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface PlayableAdTestViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
