//
//  DemoPlayerTableViewCell.m
//  GDTMobApp
//
//  Created by royqpwang on 2019/5/26.
//  Copyright © 2019 Tencent. All rights reserved.
//

#import "DemoPlayerTableViewCell.h"

@implementation DemoPlayerTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
