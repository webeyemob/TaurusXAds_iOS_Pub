//
//  BUVACommonHeader.h
//  BUVAAuxiliary
//
//  Created by bytedance on 2020/8/27.
//  Copyright © 2020 bytedance. All rights reserved.
//

#ifndef BUVACommonHeader_h
#define BUVACommonHeader_h

// 是否提供测试GPS功能，正式上线发版时置0
#define BU_VA_DEVOPEN 0

#endif /* BUVACommonHeader_h */
