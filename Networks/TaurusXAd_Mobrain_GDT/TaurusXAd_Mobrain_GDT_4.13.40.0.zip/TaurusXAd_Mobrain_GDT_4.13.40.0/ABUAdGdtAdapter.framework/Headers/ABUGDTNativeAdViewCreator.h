//
//  ABUGDTNativeAdViewCreator.h
//  ABUAdSDK
//
//  Created by CHAORS on 2021/9/29.
//

#import <Foundation/Foundation.h>
#import <ABUAdSDK/ABUAdSDK.h>
#import "ABUGdtNativeAdProtocols.h"


NS_ASSUME_NONNULL_BEGIN

@interface ABUGDTNativeAdViewCreator : NSObject <ABUMediatedNativeAdViewCreator>

- (instancetype)initWithAd:(GDTUnifiedNativeAdView *)ad;

@end

NS_ASSUME_NONNULL_END
