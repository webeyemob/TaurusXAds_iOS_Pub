//
//  ABUGDTNativeAdData.h
//  ABUAdSDK
//
//  Created by CHAORS on 2021/9/28.
//

#import <Foundation/Foundation.h>
#import <ABUAdSDK/ABUAdSDK.h>

#import "ABUGdtNativeAdProtocols.h"

NS_ASSUME_NONNULL_BEGIN

@interface ABUGDTNativeAdData : NSObject <ABUMediatedNativeAdData>

- (instancetype)initWithAd:(GDTUnifiedNativeAdDataObject *)ad;

@end

NS_ASSUME_NONNULL_END
