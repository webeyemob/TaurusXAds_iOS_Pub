//
//  ABUAdSigmobAdapter.h
//  ABUAdSigmobAdapter
//
//  Created by XuQingJia on 2020/10/12.
//

#import <Foundation/Foundation.h>

#import "ABUSigmobPersonaliseConfigAdapter.h"
