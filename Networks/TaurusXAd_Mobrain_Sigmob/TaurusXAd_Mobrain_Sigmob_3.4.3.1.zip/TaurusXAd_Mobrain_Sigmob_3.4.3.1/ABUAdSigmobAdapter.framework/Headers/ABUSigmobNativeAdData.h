//
//  ABUSigmobNativeAdData.h
//  ABUAdSDK
//
//  Created by heyinyin on 2021/10/21.
//

#import <Foundation/Foundation.h>
#import <ABUAdSDK/ABUAdSDK.h>
#import "ABUSigmobProtocols.h"

NS_ASSUME_NONNULL_BEGIN

@interface ABUSigmobNativeAdData : NSObject <ABUMediatedNativeAdData, ABUMediatedNativeAdViewCreator>
- (instancetype)initWithOriginData:(WindNativeAd *)data andView:(WindNativeAdView *)adview;
@end

NS_ASSUME_NONNULL_END
