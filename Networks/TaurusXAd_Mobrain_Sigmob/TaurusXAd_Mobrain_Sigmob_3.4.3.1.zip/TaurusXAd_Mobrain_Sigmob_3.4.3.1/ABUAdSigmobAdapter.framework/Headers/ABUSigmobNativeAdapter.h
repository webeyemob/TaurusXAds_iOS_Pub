//
//  ABUSigmobNativeAdapter.h
//  ABUAdSDK
//
//  Created by heyinyin on 2021/10/20.
//

#import <Foundation/Foundation.h>
#import <ABUAdSDK/ABUAdSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface ABUSigmobNativeAdapter : NSObject <ABUCustomNativeAdapter>

@end

NS_ASSUME_NONNULL_END
