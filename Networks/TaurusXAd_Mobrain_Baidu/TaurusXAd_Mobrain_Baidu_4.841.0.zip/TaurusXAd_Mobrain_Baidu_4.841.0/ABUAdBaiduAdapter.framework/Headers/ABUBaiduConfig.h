//
//  ABUBaiduConfig.h
//  ABUAdSDK
//
//  Created by Makaiwen on 2021/5/31.
//

#import <Foundation/Foundation.h>
#import <ABUAdSDK/ABUAdSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface ABUBaiduConfig : NSObject <ABUCustomConfigAdapter>

+ (instancetype)shared;

@property (nonatomic, copy, readonly) NSString *appId;
@end

NS_ASSUME_NONNULL_END
