//
//  ABUBaiduNativeProtocols.h
//  ABUAdSDK
//
//  Created by bytedance on 2021/10/3.
//

#import <Foundation/Foundation.h>
#import "ABUBaiduCommonProtocol.h"
#import <AVFoundation/AVFoundation.h>

NS_ASSUME_NONNULL_BEGIN

/**
 * 智能优选feed类型
 */
typedef NS_ENUM(NSInteger, BaiduMobAdSmartFeedStyleType) {
    FeedType_PIC_BOTTOM_TITLE = 28,//大图底部文字
    FeedType_PIC_TOP_TITLE = 29,//大图上部文字
    FeedType_PIC_LOGO = 30,//大图上部文字+logo
    FeedType_LEFT_PIC = 33,//左图右文
    FeedType_RIGHT_PIC = 34,//右图左文
    FeedType_GROUP_PIC = 35,//三图图文
    FeedType_GROUP_PIC_LOGO = 36,//三图图文+logo
    FeedType_VIDEO_TOP_TITLE = 37//视频+文字
};

typedef enum {
    NORMAL, // 一般图文或图片广告
    VIDEO, // 视频广告，需开发者增加播放器支持
    HTML, // html模版广告
    GIF //GIF广告
} BaiduMobMaterialType;

/**
 * 智能优选尺寸类型
 */
typedef NS_ENUM(NSInteger, BaiduMobAdSmartFeedSizeType) {
    SizeType_NONE = 0,//不使用
    SizeType_PIXEL = 1,//像素
    SizeType_SCALE = 2,//比例
};

typedef enum {
    BaiduMobNativeAdActionTypeLP = 1,
    BaiduMobNativeAdActionTypeDL = 2,
    BaiduMobNativeAdActionTypeDeepLink = 512
} BaiduMobNativeAdActionType;

typedef enum {
    onShow,  //video展现
    onClickToPlay,//点击播放
    onStart, //开始播放
    onError, //播放失败
    onComplete, //完整播放
    onClose, //播放结束
    onFullScreen, //全屏观看
    onClick, //广告点击
    onSkip, //跳过视频
    onShowEndCard,// 展现endcard
    onClickEndCard,// 点击endcard
    onClickDownloadDirect, // 视频下载广告点击直接下载
    onCacheSuccess,//视频缓存成功
    onCacheFail,//视频缓存失败
    onCacheExpire, //广告过期
    onReplay, //重播
    onPlayEnd // 播放终止，横、竖版视频
    
} BaiduAdNativeVideoEvent;

@protocol ABUBaidu_BaiduMobAdNativeAdDelegate;
@protocol ABUBaidu_BaiduMobAdNativeCacheDelegate;

@protocol ABUBaidu_BaiduMobAdFeedRequestParameters <NSObject>


@end
typedef NSObject<ABUBaidu_BaiduMobAdFeedRequestParameters> BaiduMobAdFeedRequestParameters;

@protocol ABUBaidu_BaiduMobAdNative <NSObject>
/**
 *  应用的APPID
 */
@property(nonatomic, copy) NSString *publisherId;

/**
 *  设置/获取代码位id
 */
@property(nonatomic, copy) NSString *adId;

/**
 * 原生广告delegate
 */
@property (nonatomic, weak) id<ABUBaidu_BaiduMobAdNativeAdDelegate> delegate;

/**
 * 针对视频缓存delegate
 * 适用于竖版视频，信息流视频不建议使用
 */
@property (nonatomic, weak) id<ABUBaidu_BaiduMobAdNativeCacheDelegate> cacheDelegate;

/**
 * 模版高度，仅用于信息流模版广告
 */
@property (nonatomic, strong) NSNumber *baiduMobAdsHeight;

/**
 * 模版宽度，仅用于信息流模版广告
 */
@property (nonatomic, strong) NSNumber *baiduMobAdsWidth;

/**
 *  使用controller present 落地页
 */
@property (nonatomic, weak) UIViewController *presentAdViewController;

/**
 * 广告请求成功后是否缓存视频物料，YES:缓存 NO:不缓存。默认缓存
 */
@property (nonatomic, assign) BOOL isCacheVideo;

/**
 * 广告请求超时时间，默认30s，单位s
 */
@property (nonatomic, assign) NSTimeInterval timeout;

/**
 * 广告类型，请在request请求之前赋值
 */
@property (nonatomic, assign) NSInteger adType;

/**
 *  请求原生广告
 *  注意广告的展示存在有效期，单次检索后须在一定时间内展示在页面上
 */
- (void)requestNativeAds;

/**
 *带参数请求原生广告
 *注意广告的展示存在有效期，单次检索后须在一定时间内展示在页面上
*/
- (void)requestNativeAdsWithParameters:(BaiduMobAdFeedRequestParameters *)requestParameters;

/**
 *  预加载视频素材  如果有多条素材会在所以素材均缓存完毕后回调nativeVideoAdCacheSuccess
 */
- (void)preloadVideoMaterial;

@end
typedef NSObject<ABUBaidu_BaiduMobAdNative> BaiduMobAdNative;




@protocol ABUBaidu_BaiduMobAdNativeAdObject <NSObject>

/**
 * 标题 text
 */
@property (copy, nonatomic) NSString *title;
/**
 * 描述 text
 */
@property (copy, nonatomic) NSString *text;
/**
 * 小图 url
 */
@property (copy, nonatomic) NSString *iconImageURLString;
/**
 * 大图 url
 */
@property (copy, nonatomic) NSString *mainImageURLString;

/**
 * 广告标识图标 url
 */
@property (copy, nonatomic) NSString *adLogoURLString;

/**
 * 百度logo图标 url
 */
@property (copy, nonatomic) NSString *baiduLogoURLString;

/**
 * 多图信息流的image url array
 */
@property (strong, nonatomic) NSArray *morepics;
/**
 * 视频url
 */
@property (copy, nonatomic) NSString *videoURLString;
/**
 * 视频时长，单位为s
 */
@property (strong, nonatomic) NSNumber *videoDuration;
/**
 * 自动播放
 */
@property (strong, nonatomic) NSNumber *autoPlay;
/**
 * 品牌名称，若广告返回中无品牌名称则为空
 */
@property (copy, nonatomic) NSString *brandName;
/**
* 开发者配置可接受视频后，对返回的广告单元，需先判断BaiduMobMaterialType再决定使用何种渲染组件
 */
@property (assign, nonatomic) BaiduMobMaterialType materialType;

/**
 * 返回广告单元的点击类型
 */
@property (assign, nonatomic) BaiduMobNativeAdActionType actType;

/**
 * 大图图片宽
 */
@property (copy, nonatomic) NSString *w;
/**
 * 大图图片高
 */
@property (copy, nonatomic) NSString *h;
/**
 价格标签
 */
@property (copy, nonatomic) NSString *ECPMLevel;
/**
 用户点击行为
 */
@property (copy, nonatomic) NSString *actButtonString;

#pragma mark - 智能优选
/**
 信息流广告样式类型
 */
@property (nonatomic, assign) BaiduMobAdSmartFeedStyleType style_type;
/**
 标记信息流广告容器宽高是px还是比例 0：无、1：像素、2：比例
 */
@property (nonatomic, assign) BaiduMobAdSmartFeedSizeType size_type;
/**
 信息流广告容器宽
 */
@property (nonatomic, assign) int container_width;
/**
 信息流广告容器高
 */
@property (nonatomic, assign) int container_height;


/**
 *  广告价格标签
 */
- (NSString *)getECPMLevel;

/**
 * 反馈竞价成功及二价
 * @param secondPrice 第二价格
 */
- (void)biddingSuccess:(NSString *)secondPrice;

/**
 * 反馈竞价失败及原因
 * @param reason 失败原因
 */
- (void)biddingFail:(NSString *)reason;

/**
 * 是否过期，默认为false，30分钟后过期，需要重新请求广告
 */
- (BOOL)isExpired;

/**
 * 发送视频广告相关日志
 * @param currentPlaybackTime 播放器当前时间，单位为s
 */
- (void)trackVideoEvent:(BaiduAdNativeVideoEvent)event withCurrentTime:(NSTimeInterval)currentPlaybackTime;

/**
 * 发送展现
 */
- (void)trackImpression:(UIView *)view;

/**
 * 发送点击
 */
- (void)handleClick:(UIView *)view;

/**
 * 百度联盟官网logo点击
 */
- (void)baiduLogoClick:(UIView *)baiduLogoView;

@end
typedef NSObject<ABUBaidu_BaiduMobAdNativeAdObject> BaiduMobAdNativeAdObject;

@protocol ABUBaidu_BaiduMobAdNativeAdDelegate <NSObject>
/**
 *  应用在mssp.baidu.com上的APPID
 */
- (NSString *)publisherId;

/**
 * 广告位id
 */
- (NSString *)apId;

/**
 * 模版高度，仅用于信息流模版广告
 */
- (NSNumber *)baiduMobAdsHeight;

/**
 * 模版宽度，仅用于信息流模版广告
 */
- (NSNumber *)baiduMobAdsWidth;

/**
 *  渠道ID
 */
- (NSString *)channelId;

/**
 *  启动位置信息
 */
- (BOOL)enableLocation;//如果enable，plist 需要增加NSLocationWhenInUseUsageDescription

/**
 * 广告请求成功
 * 请求成功的BaiduMobAdNativeAdObject数组，如果只成功返回一条原生广告，数组大小为1
 */
- (void)nativeAdObjectsSuccessLoad:(NSArray *)nativeAds nativeAd:(BaiduMobAdNative *)nativeAd;

/**
 *  广告请求失败
 *  失败的类型 BaiduMobFailReason
 */
- (void)nativeAdsFailLoad:(BaiduMobFailReason)reason nativeAd:(BaiduMobAdNative *)nativeAd;

/**
 *  广告曝光成功
 */
- (void)nativeAdExposure:(UIView *)nativeAdView nativeAdDataObject:(BaiduMobAdNativeAdObject *)object;

/**
 *  广告曝光失败
 */
- (void)nativeAdExposureFail:(UIView *)nativeAdView
          nativeAdDataObject:(BaiduMobAdNativeAdObject *)object
                  failReason:(int)reason;

/**
 *  广告点击
 */
- (void)nativeAdClicked:(UIView *)nativeAdView nativeAdDataObject:(BaiduMobAdNativeAdObject *)object;

/**
 *  广告详情页关闭
 */
- (void)didDismissLandingPage:(UIView *)nativeAdView;

/**
 *  联盟官网点击跳转
 */
- (void)unionAdClicked:(UIView *)nativeAdView nativeAdDataObject:(BaiduMobAdNativeAdObject *)object;

/**
 * 智能优选负反馈的选择
 */
- (void)smartFeedbackSelectedWithObject:(BaiduMobAdNativeAdObject *)object;


@end

@protocol ABUBaidu_BaiduMobAdNativeVideoBaseView <NSObject>
- (BOOL)isPlaying;
- (void)play;
- (void)pause;
- (void)stop;
- (BOOL)render;
- (BOOL)handleScrollStop;
- (void)sendVideoEvent:(BaiduAdNativeVideoEvent)event currentTime:(NSTimeInterval) currentTime;
@end
typedef UIView<ABUBaidu_BaiduMobAdNativeVideoBaseView> BaiduMobAdNativeVideoBaseView;

@protocol ABUBaidu_BaiduMobAdNativeVideoViewDelegate;
@protocol ABUBaidu_BaiduMobAdNativeWebView <NSObject>
- (instancetype)initWithFrame:(CGRect)frame andObject:(BaiduMobAdNativeAdObject *)object;
@end
typedef UIView<ABUBaidu_BaiduMobAdNativeWebView> BaiduMobAdNativeWebView;

typedef void (^BaiduMobAdViewCompletionBlock)(NSArray *errors);

@protocol ABUBaidu_BaiduMobAdNativeVideoView <NSObject>
@property (nonatomic, weak) id <ABUBaidu_BaiduMobAdNativeVideoViewDelegate> videoDelegate; //视频事件delegate

/**
 初始化方法

 @param frame videoView尺寸
 @param object BaiduMobAdNativeAdObject
 @return BaiduMobAdVideoView
 */
- (instancetype)initWithFrame:(CGRect)frame andObject:(BaiduMobAdNativeAdObject *)object;

/**
 设置AVAudioSessionCategory，play之前调用，默认：AVAudioSessionCategoryAmbient
 */
- (void)setAudioSessionCategory:(AVAudioSessionCategory)category;

/**
 开始播放
 */
- (void)play;

/**
 暂停播放
 */
- (void)pause;

/**
 销毁播放器
 */
- (void)stop;

/**
 重新播放
 */
- (void)replay;

/**
 是否播放中

 @return isPlaying
 */
- (BOOL)isPlaying;

/**
 设置静音

 @param mute YES静音   NO非静音
 */
- (void)setVideoMute:(BOOL)mute;

/**
 刷新视图frame
 */
- (void)reSize;

/**
发送视频状态
一定要向BaiduMobAdNativeAdObject发送视频状态事件和当前视频播放的位置，只有在第一次播放才需要发送
*/
- (void)sendVideoEvent:(BaiduAdNativeVideoEvent)event currentTime:(NSTimeInterval) currentTime;


/**
触发播放，仅设置wifi自动播放后生效。建议屏幕滑动停止后调用
*/
- (BOOL)render;
@end
typedef UIView<ABUBaidu_BaiduMobAdNativeVideoView> BaiduMobAdNativeVideoView;


@protocol ABUBaidu_BaiduMobAdNativeVideoViewDelegate <NSObject>

/**
 视频准备开始播放
 
 @param videoView self
 */
- (void)nativeVideoAdDidStartPlaying:(BaiduMobAdNativeVideoView *)videoView;

/**
 视频暂停播放
 
 @param videoView self
 */
- (void)nativeVideoAdDidPause:(BaiduMobAdNativeVideoView *)videoView;

/**
 视频重播
 
 @param videoView self
 */
- (void)nativeVideoAdDidReplay:(BaiduMobAdNativeVideoView *)videoView;

/**
 视频播放完成

 @param videoView self
 */
- (void)nativeVideoAdDidComplete:(BaiduMobAdNativeVideoView *)videoView;

/**
 视频播放失败

 @param videoView self
 */
- (void)nativeVideoAdDidFailed:(BaiduMobAdNativeVideoView *)videoView;


@end


@protocol ABUBaidu_BaiduMobAdNativeAdView <NSObject>

/**
 * 小图
 */
@property (strong, nonatomic) UIImageView *iconImageView;

/**
 * 大图
 */
@property (strong, nonatomic) UIImageView *mainImageView;

/**
 多图
 */
@property (strong, nonatomic) NSMutableArray *morePicsArray;

/**
 * 广告标示
 */
@property (strong, nonatomic) UIImageView *adLogoImageView;

/**
 * 百度广告logo
 */
@property (strong, nonatomic) UIImageView *baiduLogoImageView;

/**
 * 标题 view
 */
@property (strong, nonatomic) UILabel *titleLabel;

/**
 * 描述 view
 */
@property (strong, nonatomic) UILabel *textLabel;

/**
 * 品牌名称 view
 */
@property (strong, nonatomic) UILabel *brandLabel;

/**
 * 用户点击行为按钮
 */
@property (strong, nonatomic) UIButton *actButton;

/**
 * 视频 view
 */
@property (strong, nonatomic) BaiduMobAdNativeVideoBaseView *videoView;

/**
 * web view
 */
@property (strong, nonatomic) BaiduMobAdNativeWebView *webView;

/**
 *  展示用的vc, 可以不传
 */
@property (nonatomic, weak) UIViewController *presentAdViewController;

/**
 *  广告数据对象
*/
@property (nonatomic, strong, readonly) BaiduMobAdNativeAdObject *object;

/**
 常规大图信息流 MaterialType是NORMAL的初始化方法
 
 @param frame 信息流视图大小
 @param brandLabel 品牌名称
 @param titleLabel 标题
 @param textLabel 描述
 @param iconView 图标
 @param mainView 大图
 @return 信息流视图
 */
- (instancetype)initWithFrame:(CGRect)frame
          brandName:(UILabel *)brandLabel
              title:(UILabel *)titleLabel
               text:(UILabel *)textLabel
               icon:(UIImageView *)iconView
          mainImage:(UIImageView *)mainView;

/**
 * 多图信息流，MaterialType是NORMAL的初始化方法
 */
- (instancetype)initWithFrame:(CGRect)frame
          brandName:(UILabel *)brandLabel
              title:(UILabel *)titleLabel
               text:(UILabel *)textLabel
               icon:(UIImageView *)iconView
          mainImage:(UIImageView *)mainView
           morepics:(NSMutableArray *)imageViewArray;

/**
 * 信息流视频
 * 推荐使用SDK的BaiduMobAdNativeVideoView视频组件，也可自定义视频view传入
 */
- (instancetype)initWithFrame:(CGRect)frame
          brandName:(UILabel *)brandLabel
              title:(UILabel *)titleLabel
               text:(UILabel *)textLabel
               icon:(UIImageView *)iconView
          videoView:(BaiduMobAdNativeVideoBaseView *)videoView;

- (instancetype)initWithFrame:(CGRect)frame
          brandName:(UILabel *)brandLabel
              title:(UILabel *)titleLabel
               text:(UILabel *)textLabel
               icon:(UIImageView *)iconView
          mainImage:(UIImageView *)mainView
          videoView:(BaiduMobAdNativeVideoBaseView *)videoView;
/**
 * 信息流模板
 */
- (instancetype)initWithFrame:(CGRect)frame
            webview:(BaiduMobAdNativeWebView *) webView;

/**
 * 广告渲染
 */
- (void)loadAndDisplayNativeAdWithObject:(BaiduMobAdNativeAdObject *)object completion:(BaiduMobAdViewCompletionBlock)completionBlock;

/**
 曝光事件，必传
 */
- (void)trackImpression;

/**
 手动触发视频播放 仅在WiFi自动播放场景下生效

 @return 视频播放状态，是否播放中 YES正常播放  NO未播放
 */
- (BOOL)render;

/**
 设置信息流点击响应事件

 @param deal YES需开发者手动添加点击事件  默认NO，SDK管理点击事件
 */
+ (void)dealTapGesture:(BOOL) deal;

@end

typedef UIView<ABUBaidu_BaiduMobAdNativeAdView> BaiduMobAdNativeAdView;

@protocol ABUBaidu_BaiduMobAdSmartFeedView <NSObject>

/**
 * @brief 初始化智能优选组件
 *
 * @param object 信息流广告对象
 * @param frame frame,注意，以传入宽计算高度，会重新设置frame的高。添加到界面重新获取height
 * @return 模板组件
 */
- (instancetype)initWithObject:(BaiduMobAdNativeAdObject *)object
                         frame:(CGRect)frame;

/**
 * @brief 初始化智能优选组件
 *
 * @param object 信息流广告对象
 * @param frame frame,注意，以传入宽计算高度，会重新设置frame的高。添加到界面重新获取height
 * @param color 弱网下图片的默认背景色，若不传，将用浅灰色默认替代
 * @return 模板组件
 */
- (instancetype)initWithObject:(BaiduMobAdNativeAdObject *)object
                         frame:(CGRect)frame
          imageBackgroundColor:(UIColor *)color;

/**
 * @brief 组件的宽度
 *
 * @return 宽度
 */
- (CGFloat)viewWidth;

/**
 * @brief 组件的高度
 *
 * @return 高度
 */
- (CGFloat)viewHeight;

/**
 * @brief 是否已渲染完毕
 *
 * @return YES/NO
 */
- (BOOL)isReady;

/**
 * @brief 修改相关细节参数，组件尺寸后/字体字号，重新刷新渲染效果。注意组件高度有可能改变
 *
 */
- (void)reSize;

/**
 设置静音

 @param mute YES静音   NO非静音
 */
- (void)setVideoMute:(BOOL)mute;

/**
 * @brief 触发曝光检查
 *
 */
- (void)trackImpression;

/**
 * @brief 执行点击行为
 *
 */
- (void)handleClick;

/**
触发播放，仅设置wifi自动播放后生效。建议屏幕滑动停止后调用
*/
- (BOOL)render;

/**
 * 是否限制点击区域，YES限制，NO不限制
 */
@property (nonatomic, assign) BOOL enableAreaClick;

//TODO:修改如下字段后，必须调用一次reSize方法，部分属性会影响高度，注意修改后viewHeight会改变
//logo配置
@property (nonatomic, assign) CGFloat iconWidth;
@property (nonatomic, assign) CGFloat iconHeight;
@property (nonatomic, assign) CGFloat iconLeft;
@property (nonatomic, assign) CGFloat iconTop;
@property (nonatomic, assign) CGFloat iconRight;
@property (nonatomic, assign) CGFloat iconBottom;

//标题配置
@property (nonatomic, assign) CGFloat titleLeft;
@property (nonatomic, assign) CGFloat titleTop;
@property (nonatomic, assign) CGFloat titleWidth;
@property (nonatomic, assign) CGFloat titleHeight;
@property (nonatomic, assign) CGFloat titleRight;
@property (nonatomic, assign) CGFloat titleBottom;
@property (nonatomic, assign) CGFloat titleFontSize;//系统默认字体
@property (nonatomic, assign) UIFont *titleFont;
@property (nonatomic, strong) UIColor *titleColor;

//主素材：大图、视频、三图首图
@property (nonatomic, assign) CGFloat mainMaterialLeft;
@property (nonatomic, assign) CGFloat mainMaterialTop;
@property (nonatomic, assign) CGFloat mainMaterialWidth;
@property (nonatomic, assign) CGFloat mainMaterialHeight;
@property (nonatomic, assign) CGFloat mainMaterialRight;
@property (nonatomic, assign) CGFloat mainMaterialBottom;

//三图的中图
@property (nonatomic, assign) CGFloat centerPicLeft;
@property (nonatomic, assign) CGFloat centerPicTop;
@property (nonatomic, assign) CGFloat centerPicWidth;
@property (nonatomic, assign) CGFloat centerPicHeight;
@property (nonatomic, assign) CGFloat centerPicRight;
@property (nonatomic, assign) CGFloat centerPicBottom;

//三图的右图
@property (nonatomic, assign) CGFloat lastPicLeft;
@property (nonatomic, assign) CGFloat lastPicTop;
@property (nonatomic, assign) CGFloat lastPicWidth;
@property (nonatomic, assign) CGFloat lastPicHeight;
@property (nonatomic, assign) CGFloat lastPicRight;
@property (nonatomic, assign) CGFloat lastPicBottom;

//底部行为按钮
@property (nonatomic, assign) CGFloat buttonLeft;
@property (nonatomic, assign) CGFloat buttonRight;
@property (nonatomic, assign) CGFloat buttonTop;
@property (nonatomic, assign) CGFloat buttonBottom;
@property (nonatomic, assign) CGFloat buttonWidth;
@property (nonatomic, assign) CGFloat buttonHeight;
@property (nonatomic, assign) UIFont *buttonFont;
@property (nonatomic, assign) CGFloat buttonCornerRadius;
@property (nonatomic, strong) UIColor *buttonTitleColor;
@property (nonatomic, strong) UIColor *buttonBackgroundColor;

//底部负反馈按钮
@property (nonatomic, assign) CGFloat dislikeBtnLeft;
@property (nonatomic, assign) CGFloat dislikeBtnRight;
@property (nonatomic, assign) CGFloat dislikeBtnTop;
@property (nonatomic, assign) CGFloat dislikeBtnBottom;
@property (nonatomic, assign) CGFloat dislikeBtnHeigth;
@property (nonatomic, assign) CGFloat dislikeBtnWidth;
@property (nonatomic, strong) UIImage *dislikeBtnImage;

//底部品牌字样,建议不更改
@property (nonatomic, assign) CGFloat brandLeft;
@property (nonatomic, assign) CGFloat brandWidth;
@property (nonatomic, assign) CGFloat brandHeight;
@property (nonatomic, assign) CGFloat brandBottom;
@property (nonatomic, assign) CGFloat brandFontSize;
@property (nonatomic, assign) UIFont *brandFont;
@property (nonatomic, strong) UIColor *brandColor;

@end

typedef UIView<ABUBaidu_BaiduMobAdSmartFeedView> BaiduMobAdSmartFeedView;

NS_ASSUME_NONNULL_END
