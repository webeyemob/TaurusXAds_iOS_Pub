//
//  ABUBaiduNativeViewHelper.h
//  ABUAdSDK
//
//  Created by bytedance on 2021/10/3.
//

#import <Foundation/Foundation.h>
#import <ABUAdSDK/ABUAdSDK.h>
#import "ABUBaiduProtocols.h"

NS_ASSUME_NONNULL_BEGIN

@interface ABUBaiduNativeViewHelper : NSObject <ABUMediatedNativeAdViewCreator, ABUMediatedNativeAdData>

- (instancetype)initWithFrame:(CGRect)frame andObjc:(BaiduMobAdNativeAdObject *)objc;

@property (nonatomic, strong, readonly) UIView *view;

@end

NS_ASSUME_NONNULL_END
