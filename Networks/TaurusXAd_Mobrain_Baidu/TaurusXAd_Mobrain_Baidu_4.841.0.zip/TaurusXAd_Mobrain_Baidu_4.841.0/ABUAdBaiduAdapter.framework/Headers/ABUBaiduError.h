//
//  ABUBaiduError.h
//  Pods
//
//  Created by Makaiwen on 2021/5/31.
//

#ifndef ABUBaiduError_h
#define ABUBaiduError_h
#import <Foundation/Foundation.h>

static inline
NSError *ABUBaiduError(int code, NSString *reason) {
    return [NSError errorWithDomain:@"com.bytedance.GroMore.baidu.adapter" code:code userInfo:@{
        NSLocalizedDescriptionKey : reason ?: @"Unknow error",
        NSLocalizedFailureReasonErrorKey : reason ?: @"Unknow error"}];
}

static inline
NSError *ABUBaiduError_Setup_Failed() {
    return ABUBaiduError(-1, @"Failed to set up ad.");
}

static inline
NSError *ABUBaiduError_Empty_Ads() {
    return ABUBaiduError(-2, @"No ads loaded.");
}

#endif /* ABUBaiduError_h */
