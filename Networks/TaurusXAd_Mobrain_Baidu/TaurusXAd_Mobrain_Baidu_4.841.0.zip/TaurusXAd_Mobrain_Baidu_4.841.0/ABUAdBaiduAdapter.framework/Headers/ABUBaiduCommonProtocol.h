//
//  ABUBaiduCommonProtocol.h
//  ABUAdSDK
//
//  Created by bytedance on 2021/9/15.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

#ifndef SDK_VERSION_IN_MSSP
#define SDK_VERSION_IN_MSSP @""
#endif

typedef enum {
    BaiduMobAdTypeFeed = 0, // 默认 请求普通信息流广告
    BaiduMobAdTypePortrait = 1,  // 竖版视频广告
    BaiduMobAdTypeRewardVideo = 2,  // 激励视频
    BaiduMobAdTypeFullScreenVideo = 3   // 全屏视频
} BaiduMobAdType;

typedef enum _BaiduMobFailReason {
    BaiduMobFailReason_NOAD = 0,// 没有推广返回
    BaiduMobFailReason_EXCEPTION,//网络或其它异常
    BaiduMobFailReason_FRAME//广告尺寸或元素异常，不显示广告
} BaiduMobFailReason;

NS_ASSUME_NONNULL_END
