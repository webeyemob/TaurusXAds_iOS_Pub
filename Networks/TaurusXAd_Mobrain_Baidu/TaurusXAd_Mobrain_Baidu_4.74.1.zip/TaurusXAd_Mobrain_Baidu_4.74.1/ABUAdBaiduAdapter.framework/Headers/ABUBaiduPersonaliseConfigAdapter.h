//
//  ABUPanglePersonaliseConfigAdapter.h
//  ABUAdBaiduAdapter
//
//  Created by wangchao on 2020/5/20.
//  Copyright © 2020 wangchao. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface ABUBaiduPersonaliseConfigAdapter : NSObject

@end

NS_ASSUME_NONNULL_END
