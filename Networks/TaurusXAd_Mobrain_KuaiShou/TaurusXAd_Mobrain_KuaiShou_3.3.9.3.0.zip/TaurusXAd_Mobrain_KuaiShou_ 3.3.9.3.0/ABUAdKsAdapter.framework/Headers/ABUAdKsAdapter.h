//
//  ABUAdKsAdapter.h
//  ABUAdKsAdapter
//
//  Created by XuQingJia on 2020/10/13.
//

#import <Foundation/Foundation.h>

#import "ABUKsPersonaliseConfigAdapter.h"


