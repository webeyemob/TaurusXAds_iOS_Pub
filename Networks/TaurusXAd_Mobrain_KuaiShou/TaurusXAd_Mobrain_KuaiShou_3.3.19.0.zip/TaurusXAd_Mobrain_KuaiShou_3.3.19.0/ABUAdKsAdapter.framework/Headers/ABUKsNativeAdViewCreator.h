//
//  ABUKsNativeAdViewCreator.h
//  ABUAdSDK
//
//  Created by bytedance on 2021/9/16.
//

#import <Foundation/Foundation.h>
#import <ABUAdSDK/ABUAdSDK.h>
#import "ABUKsProtocols.h"

NS_ASSUME_NONNULL_BEGIN

@interface ABUKsNativeAdViewCreator : NSObject <ABUMediatedNativeAdViewCreator>

- (instancetype)initWithAd:(KSNativeAd *)ad viewDelegate:(id)delegate;

@end

NS_ASSUME_NONNULL_END
