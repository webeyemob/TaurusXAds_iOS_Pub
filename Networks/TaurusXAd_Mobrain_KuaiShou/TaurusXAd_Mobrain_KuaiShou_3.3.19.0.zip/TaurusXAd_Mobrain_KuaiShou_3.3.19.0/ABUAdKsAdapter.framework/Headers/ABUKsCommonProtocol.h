//
//  ABUKsCommonProtocol.h
//  ABUAdSDK
//
//  Created by bytedance on 2021/9/15.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@protocol ABUKs_KSAdSDKManager <NSObject>
- (void)setAppId:(NSString *)appId;
- (NSString *)SDKVersion;
@end

@protocol ABUKs_KSAd <NSObject>

@property (nonatomic, readonly) NSInteger ecpm;

@end

@protocol ABUKs_KSVideoAd <ABUKs_KSAd>

@property (nonatomic, readonly) BOOL isValid;
@property (nonatomic, assign) BOOL shouldMuted;
@property (nonatomic, assign) NSInteger showDirection;  //显示方向

- (void)loadAdData;

- (BOOL)showAdFromRootViewController:(UIViewController *)rootViewController;

- (BOOL)showAdFromRootViewController:(UIViewController *)rootViewController showScene:(nullable NSString *)showScene;

@end

NS_ASSUME_NONNULL_END
