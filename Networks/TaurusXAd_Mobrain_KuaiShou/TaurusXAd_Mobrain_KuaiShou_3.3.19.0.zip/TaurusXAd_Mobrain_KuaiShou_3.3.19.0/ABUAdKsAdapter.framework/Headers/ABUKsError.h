//
//  ABUKsError.h
//  Pods
//
//  Created by Makaiwen on 2021/5/31.
//

#ifndef ABUKsError_h
#define ABUKsError_h
#import <Foundation/Foundation.h>

static inline
NSError *ABUKsError(int code, NSString *reason) {
    return [NSError errorWithDomain:@"com.bytedance.GroMore.ks.adapter" code:code userInfo:@{
        NSLocalizedDescriptionKey : reason ?: @"Unknow error",
        NSLocalizedFailureReasonErrorKey : reason ?: @"Unknow error"}];
}

static inline
NSError *ABUKsError_Setup_Failed() {
    return ABUKsError(-1, @"Failed to set up ad.");
}

static inline
NSError *ABUKsError_No_ViewControler() {
    return ABUKsError(-2, @"Failed to load ad because of ks return null splashViewController.");
}

#endif /* ABUKsError_h */
