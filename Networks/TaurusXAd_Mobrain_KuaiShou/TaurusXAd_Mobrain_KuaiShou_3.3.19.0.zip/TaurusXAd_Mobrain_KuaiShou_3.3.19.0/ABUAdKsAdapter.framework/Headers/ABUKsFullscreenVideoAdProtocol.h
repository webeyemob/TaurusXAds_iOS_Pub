//
//  ABUKsFullscreenVideoAdProtocol.h
//  ABUAdSDK
//
//  Created by bytedance on 2021/9/16.
//

#import <Foundation/Foundation.h>
#import "ABUKsCommonProtocol.h"

NS_ASSUME_NONNULL_BEGIN

@protocol ABUKs_KSFullscreenVideoAd;

@protocol ABUKs_KSFullscreenVideoAdDelegate <NSObject>
@optional
- (void)fullscreenVideoAdDidLoad:(id<ABUKs_KSFullscreenVideoAd>)fullscreenVideoAd;
- (void)fullscreenVideoAd:(id<ABUKs_KSFullscreenVideoAd>)fullscreenVideoAd didFailWithError:(NSError *_Nullable)error;
- (void)fullscreenVideoAdVideoDidLoad:(id<ABUKs_KSFullscreenVideoAd>)fullscreenVideoAd;
- (void)fullscreenVideoAdWillVisible:(id<ABUKs_KSFullscreenVideoAd>)fullscreenVideoAd;
- (void)fullscreenVideoAdDidVisible:(id<ABUKs_KSFullscreenVideoAd>)fullscreenVideoAd;
- (void)fullscreenVideoAdWillClose:(id<ABUKs_KSFullscreenVideoAd>)fullscreenVideoAd;
- (void)fullscreenVideoAdDidClose:(id<ABUKs_KSFullscreenVideoAd>)fullscreenVideoAd;
- (void)fullscreenVideoAdDidClick:(id<ABUKs_KSFullscreenVideoAd>)fullscreenVideoAd;
- (void)fullscreenVideoAdDidPlayFinish:(id<ABUKs_KSFullscreenVideoAd>)fullscreenVideoAd didFailWithError:(NSError *_Nullable)error;
- (void)fullscreenVideoAdStartPlay:(id<ABUKs_KSFullscreenVideoAd>)fullscreenVideoAd;
- (void)fullscreenVideoAdDidClickSkip:(id<ABUKs_KSFullscreenVideoAd>)fullscreenVideoAd;
- (void)fullscreenVideoAdDidClickSkip:(id<ABUKs_KSFullscreenVideoAd>)fullscreenVideoAd currentTime:(NSTimeInterval)currentTime;
@end

@protocol ABUKs_KSFullscreenVideoAd <ABUKs_KSVideoAd>

- (void)setDelegate:(id<ABUKs_KSFullscreenVideoAdDelegate>)delegate;
- (instancetype)initWithPosId:(NSString *)posId;

@end

NS_ASSUME_NONNULL_END
