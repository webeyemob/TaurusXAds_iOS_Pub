//
//  ABUKsPersonaliseConfigAdapter.h
//  ABUAdKsAdapter
//
//  Created by XuQingJia on 2020/10/13.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface ABUKsPersonaliseConfigAdapter : NSObject

@end

NS_ASSUME_NONNULL_END
