//
//  ABUAdMintegralAdapter.h
//  ABUAdMintegralAdapter
//
//  Created by wangchao on 2020/3/16.
//  Copyright © 2020 bytedance. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "ABUMintegralPersonaliseConfigAdapter.h"


