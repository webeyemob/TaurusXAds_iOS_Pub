//
//  ABUMtgCommonProtocol.h
//  ABUAdSDK
//
//  Created by bytedance on 2021/9/15.
//

#import <Foundation/Foundation.h>

/*
 * only certain compilers support __attribute__((deprecated))
 */
#if defined(__has_feature) && defined(__has_attribute)
    #if __has_attribute(deprecated)
        #define DEPRECATED_ATTRIBUTE        __attribute__((deprecated))
        #if __has_feature(attribute_deprecated_with_message)
            #define DEPRECATED_MSG_ATTRIBUTE(s) __attribute__((deprecated(s)))
        #else
            #define DEPRECATED_MSG_ATTRIBUTE(s) __attribute__((deprecated))
        #endif
    #else
        #define DEPRECATED_ATTRIBUTE
        #define DEPRECATED_MSG_ATTRIBUTE(s)
    #endif
#elif defined(__GNUC__) && ((__GNUC__ >= 4) || ((__GNUC__ == 3) && (__GNUC_MINOR__ >= 1)))
    #define DEPRECATED_ATTRIBUTE        __attribute__((deprecated))
    #if (__GNUC__ >= 5) || ((__GNUC__ == 4) && (__GNUC_MINOR__ >= 5))
        #define DEPRECATED_MSG_ATTRIBUTE(s) __attribute__((deprecated(s)))
    #else
        #define DEPRECATED_MSG_ATTRIBUTE(s) __attribute__((deprecated))
    #endif
#else
    #define DEPRECATED_ATTRIBUTE
    #define DEPRECATED_MSG_ATTRIBUTE(s)
#endif

typedef NS_ENUM(NSUInteger, MTGGender) {
    MTGGender_Unknown = 0,
    MTGGender_Man     = 1,
    MTGGender_Woman   = 2,
};

typedef NS_ENUM(NSUInteger, MTGUserPayType) {
    MTGUserPayType_Unpaid  = 0,
    MTGUserPayType_Pay     = 1,
    MTGUserPayType_Unknown = 2,
};

typedef NS_ENUM(NSInteger, MTGAdCategory) {
    MTGAD_CATEGORY_ALL  = 0,
    MTGAD_CATEGORY_GAME = 1,
    MTGAD_CATEGORY_APP  = 2,
};

typedef NS_ENUM(NSInteger,MTGIVRewardMode) {
    MTGIVRewardCloseMode,//The alert was shown when the user tried to close the ad.
    MTGIVRewardPlayMode//The alert was shown when the ad played to a certain extent
};

typedef NS_ENUM(NSInteger, MTGAdSourceType) {
    MTGAD_SOURCE_API_OFFER = 1,
    MTGAD_SOURCE_MY_OFFER  = 2,
    MTGAD_SOURCE_FACEBOOK  = 3,
    MTGAD_SOURCE_Mintegral = 4,
    MTGAD_SOURCE_PUBNATIVE = 5,
    MTGAD_SOURCE_MYTARGET  = 7,
    MTGAD_SOURCE_NATIVEX   = 8,
    MTGAD_SOURCE_APPLOVIN  = 9,
};

typedef NS_ENUM(NSInteger, MTGAdTemplateType) {
    MTGAD_TEMPLATE_BIG_IMAGE  = 2,
    MTGAD_TEMPLATE_ONLY_ICON  = 3,
};

/**
 Tri-state boolean.
 */
typedef NS_ENUM(NSInteger, MTGBool) {
    /* No */
    MTGBoolNo = -1,
    
    /* Unknown */
    MTGBoolUnknown = 0,
    
    /* Yes */
    MTGBoolYes = 1,
};


typedef NS_ENUM(NSUInteger, MTGInterfaceOrientation) {
    MTGInterfaceOrientationAll = 0,       // to use current orientation of the device.
    MTGInterfaceOrientationPortrait = 1,  // to force to use portrait mode.
    MTGInterfaceOrientationLandscape = 2, // to force to use landscape mode.
};

/**
 We will call back whether the alert information has shown to the user and decision of the user.
*/
typedef NS_ENUM(NSInteger,MTGIVAlertWindowStatus) {
    MTGIVAlertNotShown, //The alert window was not shown
    MTGIVAlertChooseContinue,//The alert window has shown and the user chooses to continue which means he wants the reward.
    MTGIVAlertChooseCancel //The alert window has shown and the user chooses to cancel which means he doesn’t want the reward.
};


@protocol ABUMtg_MTGUserInfo <NSObject>

@property (nonatomic,assign) MTGGender gender;
@property (nonatomic,assign) NSInteger age;
@property (nonatomic,assign) MTGUserPayType pay;
@property (nonatomic,  copy) NSString *custom;
@property (nonatomic,  copy) NSString *longitude;
@property (nonatomic,  copy) NSString *latitude;

@end
typedef NSObject<ABUMtg_MTGUserInfo> MTGUserInfo;


@protocol ABUMtg_MTGSDK <NSObject>

/**
* The version of the SDK.
*
* @return The current version of the SDK.
*/
+(NSString *_Nonnull)sdkVersion;

/**
 * The shared instance of the SDK.
 *
 * @return The SDK singleton.
 */
+ (nonnull instancetype)sharedInstance;

/**
 * Set the AppID and ApiKey.
 *  This must be called after set the authorization of user privacy information collection if you need to keep GDPR terms.
 *  This must be called before any ads are requested .
 *
 * @param appID  T application Id registered on the our portal.
 * @param apiKey The API Key generated on the our Portal.
 */
- (void)setAppID:(nonnull NSString *)appID ApiKey:(nonnull NSString *)apiKey;

@property (nonatomic, assign) BOOL autoSetAudioCategory;

/**
 Set user GDPR authorization information
 
 Set YES to indicate the user's data will be collected otherwise NO. Default to be YES.
 
@abstract According to the GDPR, set method of this property must be called before "setAppID: ApiKey:", or by default will collect user's information.
 @Attention Do not mix the usage of `setConsentStatus:` and `setUserPrivateInfoType:agree` simultaneously in your app.
 */
@property (nonatomic, assign) BOOL consentStatus;

/**
 Set user GDPR authorization IDFV information
 Disable the collection of idfv , Default to be NO.
 
 */
@property (nonatomic, assign) BOOL disableIDFV;

/**
 If set to YES, the server will not display personalized ads based on the user's personal information
 When receiving the user's request, and will not synchronize the user's information to other third-party partners.
 Default is NO
 */
@property (nonatomic, assign) BOOL doNotTrackStatus;

- (void)setUserInfo:(nonnull MTGUserInfo *)userInfo;

/**
 *
 @method
 
 @abstract The method that kicks off the preloading of native ads. It may be called again in the future to refresh the ads manually.
 
 @param placementId The id of the ad placement. You can create your placement id from our Portal.
 @param unitId The id of the ad unit. You can create your unit id from our Portal.
 @param templates This array contains objects of MTGTemplate. See more detail in definition of MTGTemplate.
 @param autoCacheImage If you pass YES, SDK will download the image resource automatically when you get the campaign.
 @param adCategory Decide what kind of ads you want to retrieve. Games, apps or all of them. The default is All.
 */
- (void)preloadNativeAdsWithPlacementId:(nullable NSString *)placementId
                                 unitId:(nonnull NSString *)unitId
                     supportedTemplates:(nullable NSArray *)templates
                         autoCacheImage:(BOOL)autoCacheImage
                             adCategory:(MTGAdCategory)adCategory;

@end
typedef NSObject<ABUMtg_MTGSDK> MTGSDK;


@protocol ABUMtg_MTGBiddingSDK <NSObject>

- (NSString *)buyerUID;

@end
