//
//  ABUMTGNativeAdViewCreator.h
//  ABUAdSDK
//
//  Created by CHAORS on 2021/9/29.
//

#import <Foundation/Foundation.h>
#import <ABUAdSDK/ABUAdSDK.h>
#import "ABUMtgNativeAdProtocols.h"

NS_ASSUME_NONNULL_BEGIN

@interface ABUMtgNativeAdViewCreator : NSObject <ABUMediatedNativeAdViewCreator>

- (instancetype)initWithAd:(MTGCampaign *)ad videoViewDelegate:(id)delegate slotID:(NSString *)slotID muted:(BOOL)muted;

@end

NS_ASSUME_NONNULL_END
