//
//  ABUMtgProtocols.h
//  Pods
//
//  Created by bytedance on 2021/9/15.
//

#import "ABUMtgCommonProtocol.h"
#import "ABUMtgFullscreenAdProtocols.h"
#import "ABUMtgInterstialAdProtocols.h"
#import "ABUMtgNativeAdProtocols.h"
#import "ABUMtgBannerProtocols.h"
#import "ABUMtgRewardVideoAdProtocols.h"
#import "ABUMtgSplashAdProtocols.h"
