//
//  ABUMtgNativeAdProtocols.h
//  ABUAdSDK
//
//  Created by CHAORS on 2021/9/29.
//

#import <Foundation/Foundation.h>
#import "ABUMtgCommonProtocol.h"

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, MTGNativeAdvancedAdVideoPlayType) {
    MTGVideoPlayTypeOnlyWiFi = 1,// the video will play only if the network is WiFi
    MTGVideoPlayTypeJustTapped = 2,// the video will play when user tap the adView
    MTGVideoPlayTypeAuto = 3,//Default value, the video will play as long as the internet is available
};


@protocol ABUMtg_MTGTemplate <NSObject>

/*!
 @property
 
 @abstract It is an enumeration value. The default value is MTGAD_TEMPLATE_ONLY_ICON. It defines what type of ads you want to retrive in one template.
 */
@property (nonatomic, assign) MTGAdTemplateType templateType;

/*!
 @property
 
 @abstract It defines how many ads you want to retrive in one template.
 */
@property (nonatomic, assign) NSUInteger adsNum;

/**
 *
 @method
 
 @abstract The method defines which kinds of template you want to retrive.
 
 @param templateType It is an enumeration value. The default value is MTGAD_TEMPLATE_ONLY_ICON. It defines what type of ads you want to retrive in one template.
 @param adsNum It defines how many ads you want to retrive in one template.
 */
+ (id<ABUMtg_MTGTemplate>)templateWithType:(MTGAdTemplateType)templateType adsNum:(NSUInteger)adsNum;

@end
typedef NSObject<ABUMtg_MTGTemplate> MTGTemplate;


@protocol ABUMtg_MTGCampaign  <NSObject>

/*!
 @property
 
 @abstract The unique id of the ad
 */
@property (nonatomic, copy  ) NSString       *adId;

/*!
 @property
 
 @abstract The app's package name of the campaign
 */
@property (nonatomic, copy  ) NSString       *packageName;

/*!
 @property
 
 @abstract The app name of the campaign
 */
@property (nonatomic, copy  ) NSString       *appName;

/*!
 @property
 
 @abstract The description of the campaign
 */
@property (nonatomic, copy  ) NSString       *appDesc;

/*!
 @property
 
 @abstract The app size of the campaign
 */
@property (nonatomic, copy  ) NSString       *appSize;

/*!
 @property
 
 @abstract The icon url of the campaign
 */
@property (nonatomic, copy  ) NSString       *iconUrl;

/*!
 @property
 
 @abstract The image url of the campaign. The image size will be 1200px * 627px.
 */
@property (nonatomic, copy  ) NSString       *imageUrl;

/*!
 @property
 
 @abstract The string to show in the clickbutton
 */
@property (nonatomic, copy  ) NSString       *adCall;

/*!
 @property
 
 @abstract The ad source of the campaign
 */
@property (nonatomic, assign) MTGAdSourceType type;

/*!
 @property
 
 @abstract The timestap of the campaign
 */
@property (nonatomic, assign) double      timestamp;

/*!
 @property
 
 @abstract The dataTemplate of the campaign
 */
@property (nonatomic,assign) MTGAdTemplateType    dataTemplate;

/* The size info about adChoice icon */
@property (nonatomic) CGSize adChoiceIconSize;

/*!
@property

@abstract The video  duration of the campaign
*/
@property (nonatomic,assign) NSInteger     videoLength;

/*!
 @method
 
 @abstract
 Loads an icon image from self.iconUrl over the network, or returns the cached image immediately.
 
 @param block Block to handle the loaded image. The image may be nil if error happened.
 */
- (void)loadIconUrlAsyncWithBlock:(void (^)(UIImage *image))block;

/*!
 @method
 
 @abstract
 Loads an image from self.imageUrl over the network, or returns the cached image immediately.
 
 @param block Block to handle the loaded image. The image may be nil if error happened.
 */
- (void)loadImageUrlAsyncWithBlock:(void (^)(UIImage *image))block;

@end
typedef NSObject<ABUMtg_MTGCampaign> MTGCampaign;

@protocol ABUMtg_MTGNativeAdManagerDelegate;
@protocol ABUMtg_MTGNativeAdManager  <NSObject>

/*!
 @property
 
 @abstract The delegate
 
 @discussion All delegate method will be called in main thread.
 */
@property (nonatomic, weak, nullable) id <ABUMtg_MTGNativeAdManagerDelegate> delegate;

/*!
 @property
 
 @discussion Show the  loading view when to click on ads.
 The default is yes
 */
@property (nonatomic, assign) BOOL showLoadingView;

/*!
 @property
 
 @discussion DEPRECATED_ATTRIBUTE
 Mintegral support configuration： https://www.mintegral.net
 */
@property (nonatomic, readonly) BOOL videoSupport DEPRECATED_ATTRIBUTE;

/*!
@property

@discussion ad current placementId .
*/

@property (nonatomic, readonly) NSString *_Nullable placementId;

/*!
 @property
 
 @discussion ad current UnitId .
 */
@property (nonatomic, readonly) NSString * _Nonnull currentUnitId;

/**
* get the id of this request ad,call  after nativeAdsLoaded.
*/
@property (nonatomic, readonly) NSString *_Nullable requestId;

/*!
 @property
 
 @discussion The current ViewController of display ad.
 the "ViewController" parameters are assigned as calling the init or Registerview method
 */
@property (nonatomic, weak) UIViewController * _Nullable  viewController;

/*!
 
 Initialize the native ads manager which is for loading ads with more options.
 
 @param unitId The id of the ad unit. You can create your unit id from our Portal.
 @param templates This array contains objects of MTGTemplate. See more detail in definition of MTGTemplate.
 @param autoCacheImage If you pass YES, SDK will download the image resource automatically when you get the campaign. The default is NO.
 @param adCategory Decide what kind of ads you want to retrieve. Games, apps or all of them. The default is All.
 @param viewController The UIViewController that will be used to present SKStoreProductViewController
 (iTunes Store product information) or the in-app browser. If not set, it will be the root viewController of your current UIWindow. But it may failed to present our view controller if your rootViewController is presenting other view controller. So set this property is necessary.
 */
- (nonnull instancetype)initWithPlacementId:(nullable NSString *)placementId
                                     unitID:(nonnull NSString *)unitId
                         supportedTemplates:(nullable NSArray *)templates
                             autoCacheImage:(BOOL)autoCacheImage
                                 adCategory:(MTGAdCategory)adCategory
                   presentingViewController:(nullable UIViewController *)viewController;

/*!
 
 The method that kicks off the loading of ads. It may be called again in the future to refresh the ads manually.
 
 @discussion It only works if you init the manager by the 2 method above.
 */
- (void)loadAds;


/*!
 
 This is a method to associate a MTGCampaign with the UIView you will use to display the native ads.
 
 @param view The UIView you created to render all the native ads data elements.
 @param campaign The campaign you associate with the view.
 
 @discussion The whole area of the UIView will be clickable.
 */
- (void)registerViewForInteraction:(nonnull UIView *)view
                      withCampaign:(nonnull MTGCampaign *)campaign;

/*!
 
 This is a method to disconnect a MTGCampaign with the UIView you used to display the native ads.
 
 @param view The UIView you created to render all the native ads data elements.
 
 */
- (void)unregisterView:(nonnull UIView *)view;

/*!
 
 This is a method to associate a MTGCampaign with the UIView you will use to display the native ads and set clickable areas.
 
 @param view The UIView you created to render all the native ads data elements.
 @param clickableViews An array of UIView you created to render the native ads data element, e.g. CallToAction button, Icon image, which you want to specify as clickable.
 @param campaign The campaign you associate with the view.
 
 */
- (void)registerViewForInteraction:(nonnull UIView *)view
                withClickableViews:(nonnull NSArray *)clickableViews
                      withCampaign:(nonnull MTGCampaign *)campaign;

/*!
 
 This is a method to disconnect a MTGCampaign with the UIView you used to display the native ads.
 
 @param view The UIView you created to render all the native ads data elements.
 @param clickableViews An array of UIView you created to render the native ads data element, e.g. CallToAction button, Icon image, which you want to specify as clickable.
 
 */
- (void)unregisterView:(nonnull UIView *)view clickableViews:(nonnull NSArray *)clickableViews;

/*!
 
 This is a method to clean the cache nativeAd.
 
 */
- (void)cleanAdsCache;

/*!
 
 Set the video display area size.
 
 @param size The display area size.
 
 */
-(void)setVideoViewSize:(CGSize)size;

/*!
 
 Set the video display area size.
 
 @param width The display area width.
 @param height The display area height.
 */
-(void)setVideoViewSizeWithWidth:(CGFloat)width height:(CGFloat)height;

@end
typedef NSObject<ABUMtg_MTGNativeAdManager> MTGNativeAdManager;


@protocol ABUMtg_MTGNativeAdManagerDelegate  <NSObject>

/*!
 
 When the MTGNativeAdManager has finished loading a batch of ads this message will be sent. A batch of ads may be loaded in response to calling loadAds.
 @param nativeAds A array contains native ads (MTGCampaign).
 
 */
- (void)nativeAdsLoaded:(nullable NSArray *)nativeAds DEPRECATED_ATTRIBUTE;
- (void)nativeAdsLoaded:(nullable NSArray *)nativeAds nativeManager:(nonnull MTGNativeAdManager *)nativeManager;


/*!
 
 When the MTGNativeAdManager has reached a failure while attempting to load a batch of ads this message will be sent to the application.
 @param error An NSError object with information about the failure.
 
 */
- (void)nativeAdsFailedToLoadWithError:(nonnull NSError *)error DEPRECATED_ATTRIBUTE;
- (void)nativeAdsFailedToLoadWithError:(nonnull NSError *)error nativeManager:(nonnull MTGNativeAdManager *)nativeManager;

/*!
 
 When the MTGNativeAdManager has finished loading a batch of frames this message will be sent. A batch of frames may be loaded in response to calling loadAds.
 @param nativeFrames A array contains native frames (MTGFrame).
 
 @deprecated This method has been deprecated.
 */
- (void)nativeFramesLoaded:(nullable NSArray *)nativeFrames DEPRECATED_ATTRIBUTE;

/*!
 
 When the MTGNativeAdManager has reached a failure while attempting to load a batch of frames this message will be sent to the application.
 @param error An NSError object with information about the failure.
 
 @deprecated This method has been deprecated.
 */
- (void)nativeFramesFailedToLoadWithError:(nonnull NSError *)error DEPRECATED_ATTRIBUTE;

/*!
 
 Sent after an ad has been clicked by a user.
 
 @param nativeAd An MTGCampaign object sending the message.
 */
- (void)nativeAdDidClick:(nonnull MTGCampaign *)nativeAd DEPRECATED_ATTRIBUTE;
- (void)nativeAdDidClick:(nonnull MTGCampaign *)nativeAd nativeManager:(nonnull MTGNativeAdManager *)nativeManager;


/*!
 
 Sent after an ad url did start to resolve.
 
 @param clickUrl The click url of the ad.
 */
- (void)nativeAdClickUrlWillStartToJump:(nonnull NSURL *)clickUrl DEPRECATED_ATTRIBUTE;
- (void)nativeAdClickUrlWillStartToJump:(nonnull NSURL *)clickUrl nativeManager:(nonnull MTGNativeAdManager *)nativeManager;
/*!
 
 Sent after an ad url has jumped to a new url.
 
 @param jumpUrl The url during jumping.
 
 @discussion It will not be called if a ad's final jump url has been cached
 */
- (void)nativeAdClickUrlDidJumpToUrl:(nonnull NSURL *)jumpUrl DEPRECATED_ATTRIBUTE;
- (void)nativeAdClickUrlDidJumpToUrl:(nonnull NSURL *)jumpUrl nativeManager:(nonnull MTGNativeAdManager *)nativeManager;


/*!
 
 Sent after an ad url did reach the final jump url.
 
 @param finalUrl the final jump url of the click url.
 @param error the error generated between jumping.
 */
- (void)nativeAdClickUrlDidEndJump:(nullable NSURL *)finalUrl
                             error:(nullable NSError *)error DEPRECATED_ATTRIBUTE;

- (void)nativeAdClickUrlDidEndJump:(nullable NSURL *)finalUrl
                             error:(nullable NSError *)error nativeManager:(nonnull MTGNativeAdManager *)nativeManager;


- (void)nativeAdImpressionWithType:(MTGAdSourceType)type nativeManager:(nonnull MTGNativeAdManager *)nativeManager;

@end



@protocol ABUMtg_MTGMediaViewDelegate;
@protocol ABUMtg_MTGMediaView  <NSObject>

/* For best user experience, keep the aspect ratio of the mediaView at 16:9 */
- (instancetype)initWithFrame:(CGRect)frame;
/**
the media source, can be set again to reuse this view.
*/
- (void)setMediaSourceWithCampaign:(MTGCampaign *)campaign unitId:(NSString*)unitId;


@property (nonatomic, weak, nullable) id<ABUMtg_MTGMediaViewDelegate> delegate;

// Whether to allow full-screen playback, default YES
@property (nonatomic, assign) BOOL  allowFullscreen;

// Whether update to video from static image when video is ready to be played, default YES
@property (nonatomic, assign) BOOL  videoRefresh;

// Auto replay, default YES
@property (nonatomic, assign) BOOL  autoLoopPlay;
/* show video process view or not. Default to be YES. */
@property (nonatomic, assign) BOOL  showVideoProcessView;
/* show sound indicator view or not. Default to be YES. */
@property (nonatomic, assign) BOOL  showSoundIndicatorView;
/* mute audio output of the video player or not. Default to be YES, means video player is muted. */
@property (nonatomic, assign) BOOL mute;

@property (nonatomic, strong, readonly) MTGCampaign *campaign;

@property (nonatomic, readonly) NSString *unitId;

/**
 After called 'setMediaSourceWithCampaign:(MTGCampaign *)campaign unitId:(NSString*)unitId',
 you can check this MediaView whether has video content via isVideoContent if needed;
 */
@property (nonatomic,readonly,getter = isVideoContent) BOOL videoContent;

@end
typedef UIView<ABUMtg_MTGMediaView> MTGMediaView;


@protocol ABUMtg_MTGMediaViewDelegate  <NSObject>

/*!
 @method
 
 @abstract
 Sent just before an MTGMediaView will enter the fullscreen layout.
 
 @param mediaView  An mediaView object sending the message.
 */
- (void)MTGMediaViewWillEnterFullscreen:(MTGMediaView *)mediaView;

/*!
 @method
 
 @abstract
 Sent after an FBMediaView has exited the fullscreen layout.
 
 @param mediaView  An mediaView object sending the message.
 */
- (void)MTGMediaViewDidExitFullscreen:(MTGMediaView *)mediaView;


/**
 *  Called when the native video was starting to play.
 *
 *  @param mediaView  An mediaView object sending the message.
 */
- (void)MTGMediaViewVideoDidStart:(MTGMediaView *)mediaView;

/**
*  Called when  the video play completed.
*
*  @param mediaView  An mediaView object sending the message.
*/
- (void)MTGMediaViewVideoPlayCompleted:(MTGMediaView *)mediaView;

/*!
 @method
 
 @abstract
 Sent after an ad has been clicked by a user.
 
 @param nativeAd An MTGCampaign object sending the message.
 */
- (void)nativeAdDidClick:(nonnull MTGCampaign *)nativeAd;
- (void)nativeAdDidClick:(nonnull MTGCampaign *)nativeAd mediaView:(MTGMediaView *)mediaView;


/*!
 @method
 
 @abstract
 Sent after an ad url did start to resolve.
 
 @param clickUrl The click url of the ad.
 */
- (void)nativeAdClickUrlWillStartToJump:(nonnull NSURL *)clickUrl;
- (void)nativeAdClickUrlWillStartToJump:(nonnull NSURL *)clickUrl mediaView:(MTGMediaView *)mediaView;

/*!
 @method
 
 @abstract
 Sent after an ad url has jumped to a new url.
 
 @param jumpUrl The url during jumping.
 
 @discussion It will not be called if a ad's final jump url has been cached
 */
- (void)nativeAdClickUrlDidJumpToUrl:(nonnull NSURL *)jumpUrl;
- (void)nativeAdClickUrlDidJumpToUrl:(nonnull NSURL *)jumpUrl  mediaView:(MTGMediaView *)mediaView;

/*!
 @method
 
 @abstract
 Sent after an ad url did reach the final jump url.
 
 @param finalUrl the final jump url of the click url.
 @param error the error generated between jumping.
 */
- (void)nativeAdClickUrlDidEndJump:(nullable NSURL *)finalUrl
                             error:(nullable NSError *)error;
- (void)nativeAdClickUrlDidEndJump:(nullable NSURL *)finalUrl
                             error:(nullable NSError *)error  mediaView:(MTGMediaView *)mediaView;

- (void)nativeAdImpressionWithType:(MTGAdSourceType)type mediaView:(MTGMediaView *)mediaView;

@end


@protocol ABUMtg_MTGNativeAdvancedAdDelegate;
@protocol ABUMtg_MTGNativeAdvancedAd  <NSObject>

/** Set delegate to receive protocol event. */
@property(nonatomic,weak) id <ABUMtg_MTGNativeAdvancedAdDelegate> delegate;
 
/** The type to control ad video play. */
@property(nonatomic,assign) MTGNativeAdvancedAdVideoPlayType autoPlay;

/**
 Whether or not to mute the video player.
 You should set YES if you want to mute the video player, otherwise NO.
*/
@property(nonatomic,assign) BOOL mute;

/**
 Whether or not to show the close button.
 You should set YES if you want to show the close button, otherwise NO.
*/
@property(nonatomic,assign) BOOL showCloseButton;

/** The current ViewController of display ad. */
@property(nonatomic,weak) UIViewController * _Nullable viewController;

@property(nonatomic,copy,readonly) NSString *_Nullable placementId;

@property(nonatomic,copy,readonly) NSString * _Nonnull unitId;

/**
* get the id of this request ad,call  after nativeAdvancedAdLoadSuccess.
*/
@property(nonatomic,copy,readonly) NSString *_Nullable requestId;

/**
This is a method to initialize.

@param adSize The nativeAdvanced ad size.
@param placementID The id of the ad placement id. You can create your ad placement from the portal of mintegral.
@param unitID The id of the ad unit. You can create your unit id from the portal of mintegral.
@param rootViewController The view controller that will be used to present full screen ads.
 
*/
- (nonnull instancetype)initWithPlacementID:(nullable NSString *)placementID
                                 unitID:(nonnull NSString *)unitID
                                 adSize:(CGSize)adSize
                     rootViewController:(nullable UIViewController *)rootViewController;


/**
 This is a method to decorate the elements for the ad content.
 
 @param style  The setting for the elements of the ad content.
 @note For specific examples, please refer to the site:
    https://dev.mintegral.com/doc/index.html?file=sdk-m_sdk-ios&lang=en
*/
- (void)setAdElementsStyle:(NSDictionary *)style;

/**
 Request a NativeAdvanced Ad.
*/
- (void)loadAd;

/**
 Whether or not if there was a available ad to show.

 @return YES means there was a available ad, otherwise NO.
*/
- (BOOL)isAdReady;


/**
 Request a NativeAdvanced Ad via in-app header bidding

 @param bidToken token from bid request within MTGBidFramework.
*/
- (void)loadAdWithBidToken:(nonnull NSString *)bidToken;

/**
 Whether or not if there was a available bidding ad to show.

 @return YES means there was a available bidding ad, otherwise NO.
*/
- (BOOL)isBiddingAdReady;


/**
 Fetch the adView

 @note If get the adView before loadSuccess, you will get a UIView without a ad, which will be  attached a ad after loadSuccess
*/
- (UIView *)fetchAdView;


/**
 Call this method when you want to relase the ad, and the adView will be removed from your presenting view.
 
 @note After calling this method, if you need to continue using the MTGNativeAdvancedAd, you must reinitialize a MTGNativeAdvancedAd
*/
- (void)destroyNativeAd;

@end
typedef NSObject<ABUMtg_MTGNativeAdvancedAd> MTGNativeAdvancedAd;


@protocol ABUMtg_MTGNativeAdvancedAdDelegate  <NSObject>

/**
 This method is called when ad is loaded successfully.
 */
- (void)nativeAdvancedAdLoadSuccess:(MTGNativeAdvancedAd *)nativeAd;
 
/**
 This method is called when ad failed to load.
 */
- (void)nativeAdvancedAdLoadFailed:(MTGNativeAdvancedAd *)nativeAd error:(NSError * __nullable)error;

/**
 Sent immediately before the impression of an MTGNativeAdvancedAd object will be logged.
 */
- (void)nativeAdvancedAdWillLogImpression:(MTGNativeAdvancedAd *)nativeAd;
 
/**
 This method is called when ad is clicked.
 */
- (void)nativeAdvancedAdDidClicked:(MTGNativeAdvancedAd *)nativeAd;
 
/**
 Called when the application is about to leave as a result of tapping.
 Your application will be moved to the background shortly after this method is called.
 */
- (void)nativeAdvancedAdWillLeaveApplication:(MTGNativeAdvancedAd *)nativeAd;
 
/**
 Will open the full screen view
 Called when opening storekit or opening the webpage in app

 */
- (void)nativeAdvancedAdWillOpenFullScreen:(MTGNativeAdvancedAd *)nativeAd;
 
/**
 Close the full screen view
 Called when closing storekit or closing the webpage in app
 */
- (void)nativeAdvancedAdCloseFullScreen:(MTGNativeAdvancedAd *)nativeAd;

/**
 This method is called when ad is Closed.
 */
- (void)nativeAdvancedAdClosed:(MTGNativeAdvancedAd *)nativeAd;

@end

@protocol ABUMtg_MTGBidNativeAdManagerDelegate;
@protocol ABUMtg_MTGBidNativeAdManager <NSObject>

@property (nonatomic, weak, nullable) id <ABUMtg_MTGBidNativeAdManagerDelegate> delegate;
- (nonnull instancetype)initWithPlacementId:(nullable NSString *)placementId
                                     unitID:(nonnull NSString *)unitId
              presentingViewController:(nullable UIViewController *)viewController;
- (void)loadWithBidToken:(nonnull NSString *)bidToken;


@end
typedef NSObject<ABUMtg_MTGBidNativeAdManager> MTGBidNativeAdManager;

@protocol ABUMtg_MTGBidNativeAdManagerDelegate <NSObject>

/*!
 
 When the MTGBidNativeAdManager has finished loading a batch of ads this message will be sent. A batch of ads may be loaded in response to calling loadAds.
 @param nativeAds A array contains native ads (MTGCampaign).
 
 */
- (void)nativeAdsLoaded:(nullable NSArray *)nativeAds bidNativeManager:(nonnull MTGBidNativeAdManager *)bidNativeManager;


/*!
 
 When the MTGBidNativeAdManager has reached a failure while attempting to load a batch of ads this message will be sent to the application.
 @param error An NSError object with information about the failure.
 
 */
- (void)nativeAdsFailedToLoadWithError:(nonnull NSError *)error bidNativeManager:(nonnull MTGBidNativeAdManager *)bidNativeManager;

/*!
 
 Sent after an ad has been clicked by a user.
 
 @param nativeAd An MTGCampaign object sending the message.
 */
- (void)nativeAdDidClick:(nonnull MTGCampaign *)nativeAd bidNativeManager:(nonnull MTGBidNativeAdManager *)bidNativeManager;


/*!
 
 Sent after an ad url did start to resolve.
 
 @param clickUrl The click url of the ad.
 */
- (void)nativeAdClickUrlWillStartToJump:(nonnull NSURL *)clickUrl bidNativeManager:(nonnull MTGBidNativeAdManager *)bidNativeManager;
/*!
 
 Sent after an ad url has jumped to a new url.
 
 @param jumpUrl The url during jumping.
 
 @discussion It will not be called if a ad's final jump url has been cached
 */
- (void)nativeAdClickUrlDidJumpToUrl:(nonnull NSURL *)jumpUrl bidNativeManager:(nonnull MTGBidNativeAdManager *)bidNativeManager;


/*!
 
 Sent after an ad url did reach the final jump url.
 
 @param finalUrl the final jump url of the click url.
 @param error the error generated between jumping.
 */

- (void)nativeAdClickUrlDidEndJump:(nullable NSURL *)finalUrl
                             error:(nullable NSError *)error bidNativeManager:(nonnull MTGBidNativeAdManager *)bidNativeManager;


- (void)nativeAdImpressionWithType:(MTGAdSourceType)type bidNativeManager:(nonnull MTGBidNativeAdManager *)bidNativeManager;


@end
NS_ASSUME_NONNULL_END
