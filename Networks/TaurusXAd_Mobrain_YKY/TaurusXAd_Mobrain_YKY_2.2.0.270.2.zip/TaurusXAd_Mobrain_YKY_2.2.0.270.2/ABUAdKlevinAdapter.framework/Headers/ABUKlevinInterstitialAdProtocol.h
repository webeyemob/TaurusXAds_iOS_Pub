//
//  ABUKlevinInterstitialAdProtocol.h
//  ABUAdSDK
//
//  Created by CHAORS on 2021/9/29.
//

#import <Foundation/Foundation.h>
#import "ABUKlevinCommonProtocol.h"

NS_ASSUME_NONNULL_BEGIN

@protocol ABUKlevin_KLNInterstitialAd;
typedef void (^KLNInterstitialAdLoadCompletionHandler)(id<ABUKlevin_KLNInterstitialAd> interstitialAd,
                                                       NSError *_Nullable error);


@protocol ABUKlevin_KLNInterstitialAd <NSObject>

@property (nonatomic, weak, nullable) id<ABUKlevin_KLNFullScreenContentDelegate> fullScreenContentDelegate;

/// Controller for video play
@property (nonatomic, strong, readonly, nullable) KLNAdVideoController *videoController;

/// 加载插屏广告方法
///
/// @param request 插屏广告请求对象
/// @param completionHandler 广告加载结果回调（成功/失败），请注意：回调非线程安全
+ (void)loadWithRequest:(nonnull KLNInterstitialAdRequest *)request
      completionHandler:(KLNInterstitialAdLoadCompletionHandler)completionHandler;

/// 判断插屏广告是否可展示方法，请在主线程调用
/// Returns whether the interstitial ad can be presented from the provided root view
/// controller. Sets the error out parameter if the ad can't be presented. Must be called on the
/// main thread.
/// @param rootViewController 视图对象
/// @param error 错误信息
- (BOOL)canPresentFromRootViewController:(UIViewController *)rootViewController
                                   error:(NSError *_Nullable __autoreleasing *_Nullable)error;

/// 插屏广告展示方法，请在主线程调用
/// Presents the interstitial ad. Must be called on the main thread.
/// @param rootViewController A view controller to present the ad.
- (void)presentFromRootViewController:(UIViewController *)rootViewController;

@end
typedef NSObject<ABUKlevin_KLNInterstitialAd> KLNInterstitialAd;


NS_ASSUME_NONNULL_END
