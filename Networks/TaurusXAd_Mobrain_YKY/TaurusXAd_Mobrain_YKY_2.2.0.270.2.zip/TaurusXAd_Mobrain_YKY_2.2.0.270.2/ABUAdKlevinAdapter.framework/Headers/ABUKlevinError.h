//
//  ABUKlevinError.h
//  Pods
//
//  Created by Makaiwen on 2021/5/31.
//

#ifndef ABUKlevinError_h
#define ABUKlevinError_h
#import <Foundation/Foundation.h>

static inline
NSError *ABUKlevinError(int code, NSString *reason) {
    return [NSError errorWithDomain:@"com.bytedance.GroMore.klevin.adapter" code:code userInfo:@{
        NSLocalizedDescriptionKey : reason ?: @"Unknow error",
        NSLocalizedFailureReasonErrorKey : reason ?: @"Unknow error"}];
}

static inline
NSError *ABUKlevinError_Setup_Failed() {
    return ABUKlevinError(-1, @"Failed to set up ad.");
}

#endif /* ABUKlevinError_h */
