//
//  ABUKlevinPersonaliseConfigAdapter.h
//  ABUAdSDK
//
//  Created by CHAORS on 2021/7/26.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface ABUKlevinPersonaliseConfigAdapter : NSObject

@end

NS_ASSUME_NONNULL_END
