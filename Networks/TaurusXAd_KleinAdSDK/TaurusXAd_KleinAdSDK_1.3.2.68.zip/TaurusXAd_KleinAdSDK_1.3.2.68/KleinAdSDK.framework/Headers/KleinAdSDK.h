//
//  KleinAdSDK.h
//  Klevin
//
//  Created by noblechen on 2021/1/15.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <KleinAdSDK/constant.h>

NS_ASSUME_NONNULL_BEGIN
//! Project version number for KleinAdSDK.
FOUNDATION_EXPORT double KleinAdSDKVersionNumber;

//! Project version string for KleinAdSDK.
FOUNDATION_EXPORT const unsigned char KleinAdSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <KleinAdSDK/PublicHeader.h>


@interface KleinAdSDK : NSObject

+ (instancetype)sharedInstance;


/**
 * 初始化接口，用于传公共参数给广告sdk
 *
 *  @param jsonStr 公参json，没有的默认传@""
 *  @param handler 初始化结果回调
 */
- (void)initKleinAdSDK:(NSString *)jsonStr handler:(KLAdHandler)handler;

/**
 *  反初始化接口，用于释放内存等
 *
 */
- (void)deinKleinAdSDK;

/**
 * 下载开屏素材和展示开屏广告
 *
 *  @parm posIdArr 广告位id数组，平台获取
 *  @param autoShow 下载完成后是否自动展示
 *  @param delay 下载超时时间，超时不展示, 单位 秒
 *  @param window  开屏广告展示的window,有rootViewController并且可以presentViewController
 *  @param handler 加载和展示过程事件回调
 */
- (void)prepareADWithPosIdArr:(NSArray <NSString *>*)posIdArr
                     autoShow:(BOOL)autoShow
                        delay:(NSInteger)delay
                       window:(UIWindow *)window
                   andHandler:(KLAdHandler)handler;

/**
 * 下载激励视频素材
 *
 *  @parm posIdArr 广告位id数组，平台获取
 *  @parm trigger 触发的激励类型，1：复活；2：签到；3：道具；4：虚拟货币；5：其他
 *  @param handler 加载过程事件回调
 */
- (void)loadEncourageADWithPosId:(NSArray <NSString *>*)posIdArr
                   rewardTrigger:(NSInteger)trigger
                      andHandler:(KLAdHandler)handler;

/**
 * 下载插屏广告素材
 *
 *  @parm posIdArr 广告位id数组，平台获取
 *  @param handler 加载过程事件回调
 */
- (void)loadInterstitialADWithPosId:(NSArray <NSString *>*)posIdArr
                         andHandler:(KLAdHandler)handler;

/**
 * 展示广告
 *
 *  @param window  广告展示的window,有rootViewController并且可以presentViewController
 *  @param adType 广告配型
 *  @param handler 展示过程事件回调
 */
- (void)showInWindow:(UIWindow *)window
          withAdType:(KLAdType)adType
          andHandler:(KLAdHandler)handler;

/**
 * 展示广告-目前只支持激励视频
 *
 *  @param window  广告展示的window,有rootViewController并且可以presentViewController
 *  @param adType 广告配型
 *  @parm rewardTime 激励卡秒，0或负数则为视频时长
 *  @param mute 是否静音，目前只支持激励
 *  @param handler 展示过程事件回调
 */
- (void)showInWindow:(UIWindow *)window
          withAdType:(KLAdType)adType
          rewardTime:(NSTimeInterval)rewardTime
                mute:(BOOL)mute
          andHandler:(KLAdHandler)handler;

/**
 * 是否允许获取定位信息，权限需由接入方获取，SDK不会主动弹框申请
 * 基于用户地理信息，系统能推荐更精准的个性化广告，提升广告收益
 *
 *  @param enabled 在已获得定位权限的前提下，YES代表SDK能获取定位信息；默认为NO
 */
- (void)enableGPS:(BOOL)enabled;
@end

NS_ASSUME_NONNULL_END
