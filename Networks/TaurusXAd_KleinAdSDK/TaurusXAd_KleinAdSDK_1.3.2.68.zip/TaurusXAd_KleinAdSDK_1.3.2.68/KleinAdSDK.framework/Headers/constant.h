//
//  constant.h
//  Pods
//
//  Created by noblechen on 2021/1/12.
//

#ifndef constant_h
#define constant_h

typedef NS_ENUM(NSInteger, KLAdEvent) {
    
    // 初始化
    KLAdEvent_initSuccess = 800,              // 宿主初始化成功
    KLAdEvent_initFaild = 801,                // 宿主初始化失败
    KLAdEvent_NoInit = 802,                   // 宿主未初始化
    KLAdEvent_APIParamError = 803,            // 传入参数错误
    
    // 展示广告
    KLAdEvent_Showing = 900,                  // 已经有广告加载过程
    KLAdEvent_CreativeError = 901,            // 素材信息错误
    KLAdEvent_NetworkError = 902,             // 网络错误
    KLAdEvent_NotAdsReady = 903,              // 广告未准备好
    KLAdEvent_AdConfigRspError = 904,         // 拉取配置回包错误
    KLAdEvent_Timeout = 905,                  // 拉取超时，当次不展示
    KLAdEvent_AppStateInactive = 906,         // 准备展示的时候程序不是active
    KLAdEvent_GetAdInfo = 907,                // 向服务端发出广告请求
    KLAdEvent_ReciveAdInfo = 908,             // 收到服务端广告填充（返回广告信息)
    KLAdEvent_GetReward = 909,                // 满足奖励发放条件
    KLAdEvent_CacheError = 910,               // 本地存储文件夹创建错误
    KLAdEvent_FailUndefined = 999,            // 展示失败，错误未定义
    
    /// 服务器相关
    KLAdEvent_SystemError = 1001,             // 系统错误
    KLAdEvent_ParamIllegal = 1002,            // 参数非法
    KLAdEvent_NotAdsReturn = 1003,            // 无广告返回
    
    /// 下载完成
    KLAdEvent_CreativeDownloadSuccess = 2000, // 素材下载成功
    
    /// 广告展示
    KLAdEvent_DidShow = 3000,                 // 广告成功展示
    KLAdEvent_AdPlayFinish = 3001,            // 广告播放结束
    KLAdEvent_AdFinish = 3002,                // 广告展示结束
    KLAdEvent_AdSkip = 3003,                  // 用户点击跳过或者关闭
    KLAdEvent_AdTap = 3004,                   // 用户点击广告或者下载广告
    KLAdEvent_OnAppInactive = 3005,           // 程序退后台或者非活跃
    
    KLAdEvent_dismissAppStore = 4000,         // 退出AppStore
};

typedef NS_ENUM(NSInteger, KLAdType) {
    KLSplashAdType = 1,                 // 开屏
    KLEncourageAdType,                  // 激励
    KLInterstitialAdType                // 插屏
};

typedef NS_ENUM(NSInteger, KLAdShowError) {
    KLAdShowError_NotAdsReady = 1001,          // 没有可展示的广告
    KLAdShowError_NetworkUnreachable = 1002,   // 网络不通
    KLAdShowError_Undefined = 1999,            // 展示失败，未定义错误
};

typedef void (^KLAdHandler) (KLAdEvent event);

// SDK版本
// 1. 版本格式
// 形如xx.yy.zz.www
//
// 2. 字段说明：
// x：主版本号。
// y：子版本号。
// z：修复版本号。
// w：构建号。
// 例如，1.3.0.123表示“主版本为1，子版本为3，修复版本为0，构建号为123”。
#define SDK_VER @"1.3.2.68"

#endif /* constant_h */
