//
//  KleinLogger.h
//  KleinAdSDK
//
//  Created by Zion on 2021/3/31.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, KleinLogLevel) {
    KleinLogLevelUnknown = 0,
    KleinLogLevelVerbose = 1,
    KleinLogLevelDebug   = 2,
    KleinLogLevelInfo    = 3,
    KleinLogLevelWarn    = 4,
    KleinLogLevelError   = 5,
    KleinLogLevelFatal   = 6,
    KleinLogLevelSilent  = 7
};

@protocol KleinLoggerCallback <NSObject>
@required
/**
 * 日志回调函数
 *
 *  @parm logLevel 该条日志记录输出的logLevel级别
 *  @parm tag 日志的tag
 *  @parm message 日志内容
 */
- (void)didLogWithLevel:(KleinLogLevel)logLevel tag:(NSString *)tag message:(NSString *)message;
@end

@interface KleinLogger : NSObject

+ (instancetype)sharedInstance;

/**
 * 设置日志回调级别
 *
 *  @parm logLevel 默认KleinLogLevelInfo
 */
- (void)setLogLevel:(KleinLogLevel)logLevel;

/**
 * 设置日志回调对象
 *
 *  @parm callback 回调对象
 */
- (void)setCallback:(id<KleinLoggerCallback>)callback;

@end

NS_ASSUME_NONNULL_END
