//
//  KSDrawAdsManager.h
//  KSAdSDK
//
//  Created by xuzhijun on 2019/12/6.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface KSDrawAdsManager : NSObject

@end

NS_ASSUME_NONNULL_END
