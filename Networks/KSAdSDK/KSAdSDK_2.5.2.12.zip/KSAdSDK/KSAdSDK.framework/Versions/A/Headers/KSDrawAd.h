//
//  KSDrawAd.h
//  KSAdSDK
//
//  Created by xuzhijun on 2019/12/6.
//

#import "KSAd.h"

NS_ASSUME_NONNULL_BEGIN

@interface KSDrawAd : KSAd

@end

NS_ASSUME_NONNULL_END
