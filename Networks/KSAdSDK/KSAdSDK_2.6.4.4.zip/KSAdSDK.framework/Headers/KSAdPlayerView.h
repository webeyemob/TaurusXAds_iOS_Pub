//
//  KSAdPlayerView.h
//  KSAdPlayer
//
//  Created by 徐志军 on 2019/10/10.
//  Copyright © 2019 KuaiShou. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
#import "KSAdBasePlayerView.h"


@interface KSAdPlayerView : KSAdBasePlayerView

@end
