//
//  ABUAdSDKAdapter.h
//  ABUAdSDKAdapter
//
//  Created by wangchao on 2020/2/27.
//  Copyright © 2020 bytedance. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for ABUAdSDKAdapter.
FOUNDATION_EXPORT double ABUAdSDKAdapterVersionNumber;

//! Project version string for ABUAdSDKAdapter.
FOUNDATION_EXPORT const unsigned char ABUAdSDKAdapterVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ABUAdSDKAdapter/PublicHeader.h>

#import <ABUAdSDKAdapter/ABU_Busdk_ConfigAdapter.h>
