//
//  ABUPangleError.h
//  Pods
//
//  Created by Makaiwen on 2021/5/31.
//

#ifndef ABUPangleError_h
#define ABUPangleError_h
#import <Foundation/Foundation.h>

static inline
NSError *ABUPangleError(int code, NSString *reason) {
    return [NSError errorWithDomain:@"com.bytedance.GroMore.pangle.adapter" code:code userInfo:@{
        NSLocalizedDescriptionKey : reason ?: @"Unknow error",
        NSLocalizedFailureReasonErrorKey : reason ?: @"Unknow error"}];
}

static inline
NSError *ABUPangleError_Setup_Failed() {
    return ABUPangleError(-1, @"Failed to set up ad.");
}

#endif /* ABUPangleError_h */
