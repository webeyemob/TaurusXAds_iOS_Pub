//
// Created by bytedance on 2021/7/9.
//

#import <Foundation/Foundation.h>
#import <ABUAdSDK/ABUAdSDK.h>

@protocol ABUPangle_BUNativeAd;

@interface ABUPangleNativeAdData : NSObject <ABUMediatedNativeAdData>

- (instancetype)initWithAd:(id<ABUPangle_BUNativeAd>)ad;

@end