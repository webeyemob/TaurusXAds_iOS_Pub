//
//  ABURewardedVideoAdProtocols.h
//  ABUAdSDK
//
//  Created by bytedance on 2021/7/14.
//

#import <Foundation/Foundation.h>
#import "ABUPangleCommonProtocols.h"

NS_ASSUME_NONNULL_BEGIN

@protocol ABU_BUNativeExpressBannerViewDelegate;
@protocol ABU_BUNativeExpressBannerView <NSObject>

- (id)initWithSlot:(id<ABUPangleSlot>)slot rootViewController:(UIViewController*)vc adSize:(CGSize)size interval:(NSInteger)interval;
- (id)initWithSlot:(id<ABUPangleSlot>)slot rootViewController:(UIViewController*)vc adSize:(CGSize)size;
- (id)initWithSlotID:(id<ABUPangleSlot>)slot adloadSeq:(NSInteger)seq primeRit:(NSString *)primeRit rootViewController:(UIViewController*)vc adSize:(CGSize)size interval:(NSInteger)interval;
- (id)initWithSlotID:(id<ABUPangleSlot>)slot adloadSeq:(NSInteger)seq primeRit:(NSString *)primeRit rootViewController:(UIViewController*)vc adSize:(CGSize)size;
- (NSString *)biddingToken;
- (void)setDelegate:(id<ABU_BUNativeExpressBannerViewDelegate>)delegate;
- (void)loadAdData;
- (void)setMopubAdMarkUp:(NSString *)adm;
- (NSDictionary *)mediaExt;
@end

@protocol ABU_BUNativeExpressBannerViewDelegate <NSObject>
- (void)nativeExpressBannerAdViewDidLoad:(UIView <ABU_BUNativeExpressBannerView>*)bannerAdView;
- (void)nativeExpressBannerAdView:(UIView <ABU_BUNativeExpressBannerView>*)bannerAdView didLoadFailWithError:(NSError *_Nullable)error;
- (void)nativeExpressBannerAdViewRenderSuccess:(UIView <ABU_BUNativeExpressBannerView>*)bannerAdView;
- (void)nativeExpressBannerAdViewRenderFail:(UIView <ABU_BUNativeExpressBannerView>*)bannerAdView error:(NSError *__nullable)error;
- (void)nativeExpressBannerAdViewWillBecomVisible:(UIView <ABU_BUNativeExpressBannerView>*)bannerAdView;
- (void)nativeExpressBannerAdViewDidClick:(UIView <ABU_BUNativeExpressBannerView>*)bannerAdView;
- (void)nativeExpressBannerAdView:(UIView <ABU_BUNativeExpressBannerView>*)bannerAdView dislikeWithReason:(NSArray<id<ABUPangle_ABUDislikeWords>> *_Nullable)filterwords;
- (void)nativeExpressBannerAdViewDidCloseOtherController:(UIView <ABU_BUNativeExpressBannerView>*)bannerAdView interactionType:(NSInteger)interactionType;
- (void)nativeExpressBannerAdViewDidRemoved:(UIView <ABU_BUNativeExpressBannerView>*)nativeExpressAdView;
@end

NS_ASSUME_NONNULL_END
