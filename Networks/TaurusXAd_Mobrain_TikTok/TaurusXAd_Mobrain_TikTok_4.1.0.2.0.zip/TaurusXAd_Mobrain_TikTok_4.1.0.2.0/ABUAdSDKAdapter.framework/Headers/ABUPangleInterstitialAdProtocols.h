//
//  ABURewardedVideoAdProtocols.h
//  ABUAdSDK
//
//  Created by bytedance on 2021/7/14.
//

#import <Foundation/Foundation.h>
#import "ABUPangleCommonProtocols.h"

NS_ASSUME_NONNULL_BEGIN
@protocol ABUPangle_BUNativeExpressInterstitialAd;
@protocol ABUPangle_BUNativeExpressInterstitialAdDelegate <NSObject>
- (void)nativeExpresInterstitialAdDidLoad:(id<ABUPangle_BUNativeExpressInterstitialAd>)interstitialAd;
- (void)nativeExpresInterstitialAd:(id<ABUPangle_BUNativeExpressInterstitialAd>)interstitialAd didFailWithError:(NSError * __nullable)error;
- (void)nativeExpresInterstitialAdRenderSuccess:(id<ABUPangle_BUNativeExpressInterstitialAd>)interstitialAd;
- (void)nativeExpresInterstitialAdRenderFail:(id<ABUPangle_BUNativeExpressInterstitialAd>)interstitialAd error:(NSError * __nullable)error;
- (void)nativeExpresInterstitialAdWillVisible:(id<ABUPangle_BUNativeExpressInterstitialAd>)interstitialAd;
- (void)nativeExpresInterstitialAdDidClick:(id<ABUPangle_BUNativeExpressInterstitialAd>)interstitialAd;
- (void)nativeExpresInterstitialAdWillClose:(id<ABUPangle_BUNativeExpressInterstitialAd>)interstitialAd;
- (void)nativeExpresInterstitialAdDidClose:(id<ABUPangle_BUNativeExpressInterstitialAd>)interstitialAd;
- (void)nativeExpresInterstitialAdDidCloseOtherController:(id<ABUPangle_BUNativeExpressInterstitialAd>)interstitialAd interactionType:(NSInteger)interactionType;
@end

@protocol ABUPangle_BUNativeExpressInterstitialAd <NSObject>
- (instancetype)initWithSlotID:(NSString *)slotID adSize:(CGSize)adSize;
- (instancetype)initWithSlot:(id<ABUPangleSlot>)slot adSize:(CGSize)adSize;
- (instancetype)initWithSlotID:(NSString *)slotID adloadSeq:(NSInteger)loadSeq primeRit:(NSString *)primeRit adSize:(CGSize)adSize;
- (NSDictionary *)mediaExt;
- (void)loadAdData;
- (NSString *)biddingToken;
- (void)setDelegate:(id)delegate;
- (void)setMopubAdMarkUp:(NSString *)markUp;
- (BOOL)showAdFromRootViewController:(UIViewController *)viewController;
@property (nonatomic, weak, nullable) id<ABUPangle_BUNativeExpressInterstitialAdDelegate> delegate;
@end

NS_ASSUME_NONNULL_END

