//
//  ABURewardedVideoAdProtocols.h
//  ABUAdSDK
//
//  Created by bytedance on 2021/7/14.
//

#import <Foundation/Foundation.h>
#import "ABUPangleCommonProtocols.h"

NS_ASSUME_NONNULL_BEGIN
@protocol ABU_BUFullscreenVideoAd, ABU_BUNativeExpressFullscreenVideoAd;

@protocol ABU_BUNativeExpressFullscreenVideoAdDelegate <NSObject>
- (void)nativeExpressFullscreenVideoAdDidLoad:(id<ABU_BUNativeExpressFullscreenVideoAd>)fullscreenVideoAd;
- (void)nativeExpressFullscreenVideoAd:(id<ABU_BUNativeExpressFullscreenVideoAd>)fullscreenVideoAd didFailWithError:(NSError *_Nullable)error;
- (void)nativeExpressFullscreenVideoAdViewRenderSuccess:(id<ABU_BUNativeExpressFullscreenVideoAd>)rewardedVideoAd;
- (void)nativeExpressFullscreenVideoAdViewRenderFail:(id<ABU_BUNativeExpressFullscreenVideoAd>)rewardedVideoAd error:(NSError *_Nullable)error;
- (void)nativeExpressFullscreenVideoAdDidDownLoadVideo:(id<ABU_BUNativeExpressFullscreenVideoAd>)fullscreenVideoAd;
- (void)nativeExpressFullscreenVideoAdWillVisible:(id<ABU_BUNativeExpressFullscreenVideoAd>)fullscreenVideoAd;
- (void)nativeExpressFullscreenVideoAdDidVisible:(id<ABU_BUNativeExpressFullscreenVideoAd>)fullscreenVideoAd;
- (void)nativeExpressFullscreenVideoAdDidClick:(id<ABU_BUNativeExpressFullscreenVideoAd>)fullscreenVideoAd;
- (void)nativeExpressFullscreenVideoAdDidClickSkip:(id<ABU_BUNativeExpressFullscreenVideoAd>)fullscreenVideoAd;
- (void)nativeExpressFullscreenVideoAdWillClose:(id<ABU_BUNativeExpressFullscreenVideoAd>)fullscreenVideoAd;
- (void)nativeExpressFullscreenVideoAdDidClose:(id<ABU_BUNativeExpressFullscreenVideoAd>)fullscreenVideoAd;
- (void)nativeExpressFullscreenVideoAdDidPlayFinish:(id<ABU_BUNativeExpressFullscreenVideoAd>)fullscreenVideoAd didFailWithError:(NSError *_Nullable)error;
- (void)nativeExpressFullscreenVideoAdCallback:(id<ABU_BUNativeExpressFullscreenVideoAd>)fullscreenVideoAd withType:(NSInteger) nativeExpressVideoAdType;
- (void)nativeExpressFullscreenVideoAdDidCloseOtherController:(id<ABU_BUNativeExpressFullscreenVideoAd>)fullscreenVideoAd interactionType:(NSInteger)interactionType;
@end

@protocol ABU_BUFullscreenVideoAdDelegate <NSObject>
- (void)fullscreenVideoMaterialMetaAdDidLoad:(id<ABU_BUFullscreenVideoAd>)fullscreenVideoAd;
- (void)fullscreenVideoAd:(id<ABU_BUFullscreenVideoAd>)fullscreenVideoAd didFailWithError:(NSError *_Nullable)error;
- (void)fullscreenVideoAdVideoDataDidLoad:(id<ABU_BUFullscreenVideoAd>)fullscreenVideoAd;
- (void)fullscreenVideoAdWillVisible:(id<ABU_BUFullscreenVideoAd>)fullscreenVideoAd;
- (void)fullscreenVideoAdDidVisible:(id<ABU_BUFullscreenVideoAd>)fullscreenVideoAd;
- (void)fullscreenVideoAdDidClick:(id<ABU_BUFullscreenVideoAd>)fullscreenVideoAd;
- (void)fullscreenVideoAdWillClose:(id<ABU_BUFullscreenVideoAd>)fullscreenVideoAd;
- (void)fullscreenVideoAdDidClose:(id<ABU_BUFullscreenVideoAd>)fullscreenVideoAd;
- (void)fullscreenVideoAdDidPlayFinish:(id<ABU_BUFullscreenVideoAd>)fullscreenVideoAd didFailWithError:(NSError *_Nullable)error;
- (void)fullscreenVideoAdDidClickSkip:(id<ABU_BUFullscreenVideoAd>)fullscreenVideoAd;
- (void)fullscreenVideoAdCallback:(id<ABU_BUFullscreenVideoAd>)fullscreenVideoAd withType:(NSInteger)fullscreenVideoAdType;
@end

@protocol ABU_BUFullscreenVideoAd <NSObject>
- (instancetype)initWithSlotID:(NSString *)slotID;
- (instancetype)initWithSlot:(id<ABUPangleSlot>)slot;
- (instancetype)initWithSlotID:(NSString *)slotID adloadSeq:(NSInteger)adloadSeq primeRit:(NSString *)primeRit;
- (void)loadAdData;
- (NSString *)biddingToken;
- (NSDictionary *)mediaExt;
- (BOOL)showAdFromRootViewController:(UIViewController *)rootViewController ritSceneDescribe:(NSString *_Nullable)sceneDescirbe;
- (void)setMopubAdMarkUp:(NSString *)markUp;
@property (nonatomic, weak, nullable) id<ABU_BUFullscreenVideoAdDelegate> delegate;
// 是否是预加载
- (BOOL)materialMetaIsFromPreload;
@end

@protocol ABU_BUNativeExpressFullscreenVideoAd <NSObject>
- (instancetype)initWithSlotID:(NSString *)slotID;
- (instancetype)initWithSlot:(id<ABUPangleSlot>)slot;
- (instancetype)initWithSlotID:(NSString *)slotID adloadSeq:(NSInteger)adloadSeq primeRit:(NSString *)primeRit;
- (void)loadAdData;
- (NSString *)biddingToken;
- (NSDictionary *)mediaExt;
- (void)setMopubAdMarkUp:(NSString *)markUp;
- (BOOL)showAdFromRootViewController:(UIViewController *)rootViewController ritSceneDescribe:(NSString *_Nullable)sceneDescirbe;
@property (nonatomic, weak, nullable) id<ABU_BUNativeExpressFullscreenVideoAdDelegate> delegate;
// 是否是预加载
- (BOOL)materialMetaIsFromPreload;
@end

NS_ASSUME_NONNULL_END

