//
// Created by bytedance on 2021/6/25.
//

#import <Foundation/Foundation.h>
#import <ABUAdSDK/ABUAdSDK.h>

@interface ABUPangleFullscreenVideoAdapter : NSObject <ABUCustomFullscreenVideoAdapter>

@end