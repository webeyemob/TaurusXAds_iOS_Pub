//
//  ABURewardedVideoAdProtocols.h
//  ABUAdSDK
//
//  Created by bytedance on 2021/7/14.
//

#import <Foundation/Foundation.h>
#import "ABUPangleCommonProtocols.h"

NS_ASSUME_NONNULL_BEGIN

@protocol ABU_BURewardedVideoModel <NSObject>
@optional
- (void)setUserId:(NSString *)userId;
- (void)setRewardName:(NSString *)rewardName;
- (void)setRewardAmount:(NSInteger)rewardAmount;
- (void)setExtra:(NSString *)extra;
@end

#pragma mark - protocol express
@protocol ABU_BUNativeExpressRewardedVideoAd;
@protocol ABU_BUNativeExpressRewardedVideoAdDelegate <NSObject>
@optional
- (void)nativeExpressRewardedVideoAdDidLoad:(id <ABU_BUNativeExpressRewardedVideoAd>)rewardedVideoAd;
- (void)nativeExpressRewardedVideoAd:(id <ABU_BUNativeExpressRewardedVideoAd>)rewardedVideoAd didFailWithError:(NSError *_Nullable)error;
- (void)nativeExpressRewardedVideoAdDidDownLoadVideo:(id <ABU_BUNativeExpressRewardedVideoAd>)rewardedVideoAd;
- (void)nativeExpressRewardedVideoAdViewRenderSuccess:(id <ABU_BUNativeExpressRewardedVideoAd>)rewardedVideoAd;
- (void)nativeExpressRewardedVideoAdViewRenderFail:(id <ABU_BUNativeExpressRewardedVideoAd>)rewardedVideoAd error:(NSError *_Nullable)error;
- (void)nativeExpressRewardedVideoAdWillVisible:(id <ABU_BUNativeExpressRewardedVideoAd>)rewardedVideoAd;
- (void)nativeExpressRewardedVideoAdDidVisible:(id <ABU_BUNativeExpressRewardedVideoAd>)rewardedVideoAd;
- (void)nativeExpressRewardedVideoAdWillClose:(id <ABU_BUNativeExpressRewardedVideoAd>)rewardedVideoAd;
- (void)nativeExpressRewardedVideoAdDidClose:(id <ABU_BUNativeExpressRewardedVideoAd>)rewardedVideoAd;
- (void)nativeExpressRewardedVideoAdDidClick:(id <ABU_BUNativeExpressRewardedVideoAd>)rewardedVideoAd;
- (void)nativeExpressRewardedVideoAdDidClickSkip:(id <ABU_BUNativeExpressRewardedVideoAd>)rewardedVideoAd;
- (void)nativeExpressRewardedVideoAdDidPlayFinish:(id <ABU_BUNativeExpressRewardedVideoAd>)rewardedVideoAd didFailWithError:(NSError *_Nullable)error;
- (void)nativeExpressRewardedVideoAdServerRewardDidSucceed:(id <ABU_BUNativeExpressRewardedVideoAd>)rewardedVideoAd verify:(BOOL)verify;
- (void)nativeExpressRewardedVideoAdServerRewardDidFail:(id <ABU_BUNativeExpressRewardedVideoAd>)rewardedVideoAd;
- (void)nativeExpressRewardedVideoAdDidCloseOtherController:(id <ABU_BUNativeExpressRewardedVideoAd>)rewardedVideoAd interactionType:(NSInteger)interactionType;
@end

@protocol ABU_BUNativeExpressRewardedVideoAd <NSObject>
@property (nonatomic, strong) id<ABU_BURewardedVideoModel> rewardedVideoModel;
@property (nonatomic, weak, nullable) id<ABU_BUNativeExpressRewardedVideoAdDelegate> delegate;
@property (nonatomic, getter=isAdValid, readonly) BOOL adValid;
- (instancetype)initWithSlotID:(NSString *)slotID rewardedVideoModel:(id <ABU_BURewardedVideoModel>)model;
- (instancetype)initWithSlot:(id<ABUPangleSlot>)slot rewardedVideoModel:(id<ABU_BURewardedVideoModel>)model;
- (instancetype)initWithSlotID:(NSString *)slotID adloadSeq:(NSInteger)adloadSeq primeRit:(NSString *)primeRit;
- (NSDictionary *)mediaExt;
- (void)loadAdData;
- (NSString *)biddingToken;
- (void)setMopubAdMarkUp:(NSString *)markUp;
- (BOOL)showAdFromRootViewController:(UIViewController *)rootViewController ritScene:(NSInteger)ritSceneType ritSceneDescribe:(NSString *_Nullable)sceneDescirbe;
// 是否是预加载
- (BOOL)materialMetaIsFromPreload;
@end

#pragma mark - protocol normal
@protocol ABU_BURewardedVideoAd;
@protocol ABU_BURewardedVideoAdDelegate <NSObject>
@optional
- (void)rewardedVideoAdDidLoad:(id<ABU_BURewardedVideoAd>)rewardedVideoAd;
- (void)rewardedVideoAdVideoDidLoad:(id<ABU_BURewardedVideoAd>)rewardedVideoAd;
- (void)rewardedVideoAdDidVisible:(id<ABU_BURewardedVideoAd>)rewardedVideoAd;
- (void)rewardedVideoAdDidClose:(id<ABU_BURewardedVideoAd>)rewardedVideoAd;
- (void)rewardedVideoAdDidClick:(id<ABU_BURewardedVideoAd>)rewardedVideoAd;
- (void)rewardedVideoAdDidClickSkip:(id<ABU_BURewardedVideoAd>)rewardedVideoAd;
- (void)rewardedVideoAdDidClickDownload:(id<ABU_BURewardedVideoAd>)rewardedVideoAd;
- (void)rewardedVideoAd:(id<ABU_BURewardedVideoAd>)rewardedVideoAd didFailWithError:(NSError *)error;
- (void)rewardedVideoAdDidPlayFinish:(id<ABU_BURewardedVideoAd>)rewardedVideoAd didFailWithError:(NSError *)error;
- (void)rewardedVideoAdServerRewardDidSucceed:(id<ABU_BURewardedVideoAd>)rewardedVideoAd verify:(BOOL)verify;
- (void)rewardedVideoAdServerRewardDidFail:(id<ABU_BURewardedVideoAd>)rewardedVideoAd;
@end

@protocol ABU_BURewardedVideoAd<NSObject>
@property (nonatomic, strong) id<ABU_BURewardedVideoModel> rewardedVideoModel;
@property (nonatomic, weak, nullable) id<ABU_BURewardedVideoAdDelegate> delegate;
@property (nonatomic, getter=isAdValid, readonly) BOOL adValid;
- (NSDictionary *)mediaExt;
- (instancetype)initWithSlotID:(NSString *)slotID rewardedVideoModel:(id<ABU_BURewardedVideoModel>)model;
- (instancetype)initWithSlot:(id<ABUPangleSlot>)slot rewardedVideoModel:(id<ABU_BURewardedVideoModel>)model;
- (instancetype)initWithSlotID:(NSString *)slotID adloadSeq:(NSInteger)adloadSeq primeRit:(NSString *)primeRit;
- (void)loadAdData;
- (NSString *)biddingToken;
- (void)setMopubAdMarkUp:(NSString *)markUp;
- (BOOL)showAdFromRootViewController:(UIViewController *)rootViewController ritScene:(NSInteger)ritSceneType ritSceneDescribe:(NSString *_Nullable)sceneDescirbe;
// 是否是预加载
- (BOOL)materialMetaIsFromPreload;
@end

NS_ASSUME_NONNULL_END
