//
//  ABUAdmobError.h
//  Pods
//
//  Created by Makaiwen on 2021/5/31.
//

#ifndef ABUKsError_h
#define ABUKsError_h
#import <Foundation/Foundation.h>

static inline
NSError *ABUAdmobError(int code, NSString *reason) {
    return [NSError errorWithDomain:@"com.bytedance.GroMore.admob.adapter" code:code userInfo:@{
        NSLocalizedDescriptionKey : reason ?: @"Unknow error",
        NSLocalizedFailureReasonErrorKey : reason ?: @"Unknow error"}];
}

static inline
NSError *ABUAdmobError_Setup_Failed() {
    return ABUAdmobError(-1, @"Failed to set up ad.");
}

#endif /* ABUKsError_h */
