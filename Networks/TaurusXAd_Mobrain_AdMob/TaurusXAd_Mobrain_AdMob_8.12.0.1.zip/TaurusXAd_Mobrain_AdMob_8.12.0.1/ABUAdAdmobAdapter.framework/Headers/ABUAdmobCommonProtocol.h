//
//  ABUAdmobCommonProtocol.h
//  ABUAdSDK
//
//  Created by bytedance on 2021/9/15.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

#if __has_attribute(objc_boxable)  // Available starting in Xcode 7.3.
#define ABU_GAD_BOXABLE __attribute__((objc_boxable))
#else
#error "Use latest Xcode version."
#endif  // __has_attribute(objc_boxable)

typedef struct ABU_GAD_BOXABLE ABU_GADAdSize ABU_GADAdSize;

struct ABU_GAD_BOXABLE ABU_GADAdSize {
  /// The ad size. Don't modify this value directly.
  CGSize size;
  /// Reserved.
  NSUInteger flags;
};

CG_EXTERN ABU_GADAdSize GADAdSizeFromCGSize(CGSize size);


@protocol ABUAdmob_GADRequest <NSObject>

@end

@protocol ABUAdmob_GADRequestClass <NSObject>
- (id<ABUAdmob_GADRequest>)request;
@end

typedef NSObject<ABUAdmob_GADRequest> GADRequest;


@protocol ABUAdmob_GADMobileAds <NSObject>
- (void)startWithCompletionHandler:(void(^)(id status))completionHandler;
- (NSString *)sdkVersion;
@end

@protocol ABUAdmob_GADMobileAdsClass <NSObject>
- (id<ABUAdmob_GADMobileAds>)sharedInstance;
@end

@protocol GADFullScreenPresentingAd <NSObject>

@end

@protocol ABUAdmob_GADFullScreenContentDelegate <NSObject>

@optional

/// Tells the delegate that an impression has been recorded for the ad.
- (void)adDidRecordImpression:(nonnull id<GADFullScreenPresentingAd>)ad;

/// Tells the delegate that a click has been recorded for the ad.
- (void)adDidRecordClick:(nonnull id<GADFullScreenPresentingAd>)ad;

/// Tells the delegate that the ad failed to present full screen content.
- (void)ad:(nonnull id<GADFullScreenPresentingAd>)ad
    didFailToPresentFullScreenContentWithError:(nonnull NSError *)error;

/// Tells the delegate that the ad presented full screen content.
- (void)adDidPresentFullScreenContent:(nonnull id<GADFullScreenPresentingAd>)ad;

/// Tells the delegate that the ad will dismiss full screen content.
- (void)adWillDismissFullScreenContent:(nonnull id<GADFullScreenPresentingAd>)ad;

/// Tells the delegate that the ad dismissed full screen content.
- (void)adDidDismissFullScreenContent:(nonnull id<GADFullScreenPresentingAd>)ad;

@end

NS_ASSUME_NONNULL_END
