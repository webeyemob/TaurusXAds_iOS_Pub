//
//  ABUAdmobNativeData.h
//  ABUAdSDK
//
//  Created by bytedance on 2021/9/23.
//

#import <Foundation/Foundation.h>
#import <ABUAdSDK/ABUAdSDK.h>
#import "ABUAdmobProtocols.h"

NS_ASSUME_NONNULL_BEGIN

@interface ABUAdmobNativeData : NSObject <ABUMediatedNativeAdData, ABUMediatedNativeAdViewCreator>

- (instancetype)initWithOriginData:(GADNativeAd *)data andView:(GADNativeAdView *)view delegate:(id<ABUAdmob_GADVideoControllerDelegate>)delegate;

@end

NS_ASSUME_NONNULL_END
