//
//  ABUAdmobNativeProtocols.h
//  ABUAdSDK
//
//  Created by bytedance on 2021/9/22.
//

#import <Foundation/Foundation.h>
#import "ABUAdmobCommonProtocol.h"

NS_ASSUME_NONNULL_BEGIN

CG_EXTERN NSString * _Nonnull const kGADAdLoaderAdTypeNative;

@protocol ABUAdmob_GADVideoControllerDelegate;

@protocol ABUAdmob_GADVideoController <NSObject>

/// Delegate for receiving video notifications.
@property(nonatomic, weak, nullable) id<ABUAdmob_GADVideoControllerDelegate> delegate;
@end

typedef NSObject<ABUAdmob_GADVideoController> GADVideoController;

@protocol ABUAdmob_GADVideoControllerDelegate <NSObject>


/// Tells the delegate that the video controller has began or resumed playing a video.
- (void)videoControllerDidPlayVideo:(nonnull GADVideoController *)videoController;

/// Tells the delegate that the video controller has paused video.
- (void)videoControllerDidPauseVideo:(nonnull GADVideoController *)videoController;

/// Tells the delegate that the video controller's video playback has ended.
- (void)videoControllerDidEndVideoPlayback:(nonnull GADVideoController *)videoController;

/// Tells the delegate that the video controller has muted video.
- (void)videoControllerDidMuteVideo:(nonnull GADVideoController *)videoController;

/// Tells the delegate that the video controller has unmuted video.
- (void)videoControllerDidUnmuteVideo:(nonnull GADVideoController *)videoController;

@end

@protocol ABUAdmob_GADMediaContent <NSObject>

/// Indicates whether the media content has video content.
@property(nonatomic, readonly) BOOL hasVideoContent;

/// The video's duration in seconds or 0 if there's no video or the duration is unknown.
@property(nonatomic, readonly) NSTimeInterval duration;

/// Controls the media content's video.
@property(nonatomic, readonly, nonnull) GADVideoController *videoController;
@end

typedef NSObject<ABUAdmob_GADMediaContent> GADMediaContent;


@interface GADNativeAdImage : NSObject

/// The image. If image autoloading is disabled, this property will be nil.
@property(nonatomic, readonly, strong, nullable) UIImage *image;

/// The image's URL.
@property(nonatomic, readonly, copy, nullable) NSURL *imageURL;

/// The image's scale.
@property(nonatomic, readonly, assign) CGFloat scale;

@end

@protocol ABUAdmob_GADAdLoaderDelegate;

/// Ad loader options base class. See each ad type's header for available GADAdLoaderOptions
/// subclasses.
@protocol ABUAdmob_GADAdLoaderOptions <NSObject>
@end

typedef NSObject<ABUAdmob_GADAdLoaderOptions> GADAdLoaderOptions;

/// Ad loader options for requesting multiple ads. Requesting multiple ads in a single request is
/// currently only available for native app install ads and native content ads.
@protocol ABUAdmob_GADMultipleAdsAdLoaderOptions <ABUAdmob_GADAdLoaderOptions>

/// Number of ads the GADAdLoader should attempt to return for the request. By default, numberOfAds
/// is one. Requests are invalid and will fail if numberOfAds is less than one. If numberOfAds
/// exceeds the maximum limit (5), only the maximum number of ads are requested.
///
/// The ad loader makes at least one and up to numberOfAds calls to the "ad received" and
/// -didFailToReceiveAdWithError: methods found in GADAdLoaderDelegate and its extensions, followed
/// by a single call to -adLoaderDidFinishLoading: once loading is finished.
@property(nonatomic) NSInteger numberOfAds;

@end

typedef NSObject<ABUAdmob_GADMultipleAdsAdLoaderOptions> GADMultipleAdsAdLoaderOptions;

/// Video ad options.
@protocol ABUAdmob_GADVideoOptions <ABUAdmob_GADAdLoaderOptions>

/// Indicates whether videos should start muted. By default this property value is YES.
@property(nonatomic, assign) BOOL startMuted;

/// Indicates whether the requested video should have custom controls enabled for
/// play/pause/mute/unmute.
@property(nonatomic, assign) BOOL customControlsRequested;

/// Indicates whether the requested video should have the click to expand behavior.
@property(nonatomic, assign) BOOL clickToExpandRequested;

@end

typedef NSObject<ABUAdmob_GADVideoOptions> GADVideoOptions;


/// Loads ads. See GADAdLoaderAdTypes.h for available ad types.
@protocol ABUAdmob_GADAdLoader <NSObject>

/// Object notified when an ad request succeeds or fails. Must conform to requested ad types'
/// delegate protocols.
@property(nonatomic, weak, nullable) id<ABUAdmob_GADAdLoaderDelegate> delegate;

/// The ad loader's ad unit ID.
@property(nonatomic, readonly, nonnull) NSString *adUnitID;

/// Indicates whether the ad loader is loading.
@property(nonatomic, getter=isLoading, readonly) BOOL loading;

/// Returns an initialized ad loader configured to load the specified ad types.
///
/// @param rootViewController The root view controller is used to present ad click actions.
/// @param adTypes An array of ad types. See GADAdLoaderAdTypes.h for available ad types.
/// @param options An array of GADAdLoaderOptions objects to configure how ads are loaded, or nil
/// to use default options. See each ad type's header for available GADAdLoaderOptions subclasses.
- (nonnull instancetype)initWithAdUnitID:(nonnull NSString *)adUnitID
                      rootViewController:(nullable UIViewController *)rootViewController
                                 adTypes:(nonnull NSArray<NSString *> *)adTypes
                                 options:(nullable NSArray<GADAdLoaderOptions *> *)options;

/// Loads the ad and informs the delegate of the outcome.
- (void)loadRequest:(nullable GADRequest *)request;

@end
typedef NSObject<ABUAdmob_GADAdLoader> GADAdLoader;


@protocol ABUAdmob_GADAdLoaderDelegate <NSObject>

/// Called when adLoader fails to load an ad.
- (void)adLoader:(nonnull GADAdLoader *)adLoader
    didFailToReceiveAdWithError:(nonnull NSError *)error;

@optional

/// Called after adLoader has finished loading.
- (void)adLoaderDidFinishLoading:(nonnull GADAdLoader *)adLoader;


@end

@protocol ABUAdmob_GADNativeAdDelegate;
@protocol ABUAdmob_GADNativeAd <NSObject>

/// Optional delegate to receive state change notifications.
@property(nonatomic, weak, nullable) id<ABUAdmob_GADNativeAdDelegate> delegate;

/// Array of GADNativeAdImage objects.
@property(nonatomic, readonly, strong, nullable) NSArray<GADNativeAdImage *> *images;

/// Icon image.
@property(nonatomic, readonly, strong, nullable) GADNativeAdImage *icon;

/// Headline.
@property(nonatomic, readonly, copy, nullable) NSString *headline;

/// Description.
@property(nonatomic, readonly, copy, nullable) NSString *body;

/// The app store name. For example, "App Store".
@property(nonatomic, readonly, copy, nullable) NSString *store;

/// Text that encourages user to take some action with the ad. For example "Install".
@property(nonatomic, readonly, copy, nullable) NSString *callToAction;

/// Media content. Set the associated media view's mediaContent property to this object to display
/// this content.
@property(nonatomic, readonly, nonnull) GADMediaContent *mediaContent;

/// App store rating (0 to 5).
@property(nonatomic, readonly, copy, nullable) NSDecimalNumber *starRating;

/// String representation of the app's price.
@property(nonatomic, readonly, copy, nullable) NSString *price;
/// Identifies the advertiser. For example, the advertiser’s name or visible URL.
@property(nonatomic, readonly, copy, nullable) NSString *advertiser;
/// Media content. Set the associated media view's mediaContent property to this object to display

@end
typedef NSObject<ABUAdmob_GADNativeAd> GADNativeAd;

@protocol ABUAdmob_GADNativeAdDelegate <NSObject>

#pragma mark - Ad Lifecycle Events

/// Called when an impression is recorded for an ad. Only called for Google ads and is not supported
/// for mediated ads.
- (void)nativeAdDidRecordImpression:(nonnull GADNativeAd *)nativeAd;

/// Called when a click is recorded for an ad. Only called for Google ads and is not supported for
/// mediated ads.
- (void)nativeAdDidRecordClick:(nonnull GADNativeAd *)nativeAd;

#pragma mark - Click-Time Lifecycle Notifications

/// Called before presenting the user a full screen view in response to an ad action. Use this
/// opportunity to stop animations, time sensitive interactions, etc.
///
/// Normally the user looks at the ad, dismisses it, and control returns to your application with
/// the nativeAdDidDismissScreen: message. However, if the user hits the Home button or clicks on an
/// App Store link, your application will be backgrounded. The next method called will be the
/// applicationWillResignActive: of your UIApplicationDelegate object.
- (void)nativeAdWillPresentScreen:(nonnull GADNativeAd *)nativeAd;

/// Called before dismissing a full screen view.
- (void)nativeAdWillDismissScreen:(nonnull GADNativeAd *)nativeAd;

/// Called after dismissing a full screen view. Use this opportunity to restart anything you may
/// have stopped as part of nativeAdWillPresentScreen:.
- (void)nativeAdDidDismissScreen:(nonnull GADNativeAd *)nativeAd;

#pragma mark - Mute This Ad

/// Used for Mute This Ad feature. Called after the native ad is muted. Only called for Google ads
/// and is not supported for mediated ads.
- (void)nativeAdIsMuted:(nonnull GADNativeAd *)nativeAd;


@end

@protocol ABUAdmob_GADNativeAdLoaderDelegate <NSObject>

/// Called when a native ad is received.
- (void)adLoader:(nonnull GADAdLoader *)adLoader didReceiveNativeAd:(nonnull GADNativeAd *)nativeAd;

@end

@protocol ABUAdmob_GADMediaView <NSObject>
@property(nonatomic, nullable) GADMediaContent *mediaContent;
@end

typedef UIView<ABUAdmob_GADMediaView> GADMediaView;

@protocol ABUAdmob_GADNativeAdView <NSObject>

/// This property must point to the native ad object rendered by this ad view.
@property(nonatomic, strong, nullable) GADNativeAd *nativeAd;

/// Weak reference to your ad view's headline asset view.
@property(nonatomic, weak, nullable) IBOutlet UIView *headlineView;
/// Weak reference to your ad view's call to action asset view.
@property(nonatomic, weak, nullable) IBOutlet UIView *callToActionView;
/// Weak reference to your ad view's icon asset view.
@property(nonatomic, weak, nullable) IBOutlet UIView *iconView;
/// Weak reference to your ad view's body asset view.
@property(nonatomic, weak, nullable) IBOutlet UIView *bodyView;
/// Weak reference to your ad view's store asset view.
@property(nonatomic, weak, nullable) IBOutlet UIView *storeView;
/// Weak reference to your ad view's price asset view.
@property(nonatomic, weak, nullable) IBOutlet UIView *priceView;
/// Weak reference to your ad view's image asset view.
@property(nonatomic, weak, nullable) IBOutlet UIView *imageView;
/// Weak reference to your ad view's star rating asset view.
@property(nonatomic, weak, nullable) IBOutlet UIView *starRatingView;
/// Weak reference to your ad view's advertiser asset view.
@property(nonatomic, weak, nullable) IBOutlet UIView *advertiserView;
/// Weak reference to your ad view's media asset view.
@property(nonatomic, weak, nullable) IBOutlet GADMediaView *mediaView;
/// Weak reference to your ad view's AdChoices view. Must set adChoicesView before setting
/// nativeAd, otherwise AdChoices will be rendered according to the preferredAdChoicesPosition
/// defined in GADNativeAdViewAdOptions.
@property(nonatomic, weak, nullable) IBOutlet UIView *adChoicesView;

@end
typedef UIView<ABUAdmob_GADNativeAdView> GADNativeAdView;


NS_ASSUME_NONNULL_END
