//
//  NATAExpressAd.h
//  NathAdsTemplateAd
//
//  Created by zena.tang on 2020/4/23.
//  Copyright © 2020 nathads. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "NATAError.h"
#import "NATAAdCreative.h"

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, NATA_CUSTOM_EVENT) {
    NATA_CUSTOM_EVENT_VIDEO_START         = 2001, // 'videoStart';
    NATA_CUSTOM_EVENT_VIDEO_COMPLETE      = 2002, // 'videoComplete';
    NATA_CUSTOM_EVENT_VIDEO_FIRST_QUARTILE = 2003,// 'videoFirstQuartile';
    NATA_CUSTOM_EVENT_VIDEO_MIDDLE        = 2004, // 'videoMid';
    NATA_CUSTOM_EVENT_VIDEO_THIRD_QUARTILE = 2005,//  'videoThirdQuartile';
    NATA_CUSTOM_EVENT_VIDEO_SKIP          = 2006, // 'videoSkip'; // 1006
    NATA_CUSTOM_EVENT_VIDEO_ERROR         = 2007, // 'videoError'; // 1007
    NATA_CUSTOM_EVENT_AUDIO_MUTE          = 2008, // 'audioMute'; // 1008
    NATA_CUSTOM_EVENT_AUDIO_UNMUTE        = 2009, // 'audioUnmute'; // 1009
    NATA_CUSTOM_EVENT_ERROR_REPORT        = 2010, // 'errorReport'; // 2010
    NATA_CUSTOM_EVENT_REPORT              = 2011, // 'eventReport'; // 2011
    NATA_CUSTOM_EVENT_REQUEST             = 2012, // 'sendRequest'; // 2012
    
    
    //自定义
    NATA_CUSTOM_EVENT_VIDEO_PAUSE        = 2080, // 'pause'; // 2080
    NATA_CUSTOM_EVENT_VIDEO_RESUME       = 2081, // 'resume'; // 2081
};

typedef NS_ENUM(NSInteger, NATA_CLICK_EVENT_TYPE) {
    //自定义
    NATA_CLICK_EVENT_TYPE_OPEN, // '点击'
    NATA_CLICK_EVENT_TYPE_CLOSE, // '关闭'
    NATA_CLICK_EVENT_TYPE_SKIP, // '跳过'
    NATA_CLICK_EVENT_TYPE_MUTE, // '静音'
    NATA_CLICK_EVENT_TYPE_UNMUTE, // '取消静音'
    NATA_CLICK_EVENT_TYPE_VIDEO // '视频'
};

typedef NS_ENUM(NSInteger, NATA_EVENT_TRACK_EID) {
    NATA_EVENT_TRACK_VIDEO_EXPRESS_GETTPL_SUCCESS    = 70000,   //获取模板成功
    NATA_EVENT_TRACK_VIDEO_EXPRESS_GETTPL_FAILED     = 70001,   //获取模板失败
    NATA_EVENT_TRACK_VIDEO_EXPRESS_GETGLOBAL_SUCCESS = 70002,   //获取appglobal成功
    NATA_EVENT_TRACK_VIDEO_EXPRESS_GETGLOBAL_FAILED  = 70003,   //获取appglobal失败
    
    
    NATA_EVENT_TRACK_VIDEO_EXPRESS_RENDER_SUCCESS    = 70100,   //模板视频渲染成功
    NATA_EVENT_TRACK_VIDEO_EXPRESS_RENDER_FAILED     = 70101,   //模板视频渲染失败
    NATA_EVENT_TRACK_VIDEO_EXPRESS_FETCH_TIME        = 70102,   //模板 FETCH 花费时间
    NATA_EVENT_TRACK_VIDEO_EXPRESS_DOM_TIME          = 70103,   //模板 DOM 渲染时间
    
    NATA_EVENT_TRACK_VIDEO_EXPRESS_SKIP              = 70104,   //模板视频点击跳过
    NATA_EVENT_TRACK_VIDEO_EXPRESS_CLOSE             = 70105,   //模板视频点击关闭
    NATA_EVENT_TRACK_VIDEO_EXPRESS_MUTE              = 70106,   //模板视频点击静音
    NATA_EVENT_TRACK_VIDEO_EXPRESS_UNMUTE            = 70107,   //模板视频点击取消静音
    NATA_EVENT_TRACK_VIDEO_EXPRESS_VIDEO_CLICK       = 70108,   //模板视频点击视频
    NATA_EVENT_TRACK_VIDEO_EXPRESS_CTA_CLICK         = 70109,   //模板视频点击button

    
    NATA_EVENT_TRACK_VIDEO_EXPRESS_IMP               = 70110,   //模板视频广告展示
    NATA_EVENT_TRACK_VIDEO_EXPRESS_START             = 70111,   //模板视频广告开始播放
    NATA_EVENT_TRACK_VIDEO_EXPRESS_COMPLETE          = 70112,   //模板视频广告播放结束
    NATA_EVENT_TRACK_VIDEO_EXPRESS_PLAY_ERROR        = 70113,   //模板视频广告播放出错
    
    
    NATA_EVENT_TRACK_VIDEO_EXPRESS_REPORT_ERROR         = 70201,   //模板JS异常出错
    NATA_EVENT_TRACK_VIDEO_EXPRESS_PACKAGE_PARSER_ERROR = 70202,   //package.json解析出错
    NATA_EVENT_TRACK_VIDEO_EXPRESS_GLOBAL_PARSER_ERROR  = 70203,   //appglobal解析出错
};

typedef NS_ENUM(NSInteger, NATA_REQUEST_EVENT_METHID) {
    NATA_REQUEST_EVENT_METHID_GET       = 0, // get
    NATA_REQUEST_EVENT_METHID_POST      = 1 //post
};

@class NATAExpressAd;

@protocol NATAExpressAdDelegate  <NSObject>

@optional
- (void)ExpressAdRenderDidFinish:(NATAExpressAd *)ad;
- (void)expressAd:(NATAExpressAd *)ad didRenderFailWithError:(NATAError * _Nullable)error;

//- (void)ExpressAdRenderReady:(NATAExpressAd *)ad message: (NSDictionary * _Nullable)message;

- (void)ExpressAdOnClick:(NATAExpressAd *)ad clickType: (NATA_CLICK_EVENT_TYPE)clickType;

- (void)ExpressAdCustomEvent: (NATAExpressAd *)ad eventID: (NATA_CUSTOM_EVENT)eventID message: (NSDictionary * _Nullable)message;

- (void)ExpressAdReportEvent: (NATAExpressAd *)ad message: (NSDictionary *)message;
- (void)ExpressAdRequestEvent: (NATAExpressAd *)ad method: (NATA_REQUEST_EVENT_METHID)method host: (NSString *)host param: (NSDictionary * _Nullable)param needGlobalParam: (BOOL)needGlobalParam;

@end

@interface NATAExpressAd : UIView

@property (nonatomic, weak) id<NATAExpressAdDelegate> delegate;

+ (instancetype) renderAdUnit: (NSString *)adunitID adData: (NATAAdCreative *)adData viewFrame: (CGRect) viewFrame delegate: (id<NATAExpressAdDelegate>)delegate;

- (instancetype)initWithAdUnit: (NSString *)adunitID adData: (NATAAdCreative *)adData viewFrame: (CGRect) viewFrame delegate: (id<NATAExpressAdDelegate>)delegate;

- (void)startRender;

- (void)playVideo;
- (void)pauseVideo;
- (void)resumeVideo:(NSTimeInterval) duarion;
- (void)completeVideo;

- (void)noUseExpressAd;

- (void)bringWebViewToFront;
@end

NS_ASSUME_NONNULL_END
