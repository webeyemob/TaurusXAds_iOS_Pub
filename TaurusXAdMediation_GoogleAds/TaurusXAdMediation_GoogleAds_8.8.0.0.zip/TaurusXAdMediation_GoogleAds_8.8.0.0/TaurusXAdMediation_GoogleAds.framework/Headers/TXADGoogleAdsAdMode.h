//
//  TXADGoogleAdsAdMode.h
//  TaurusXAdMediation_GoogleAds
//
//  Created by TaurusXAds on 2020/3/2.
//  Copyright © 2020 TaurusXAds. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSUInteger, TXADGoogleAdsBannerMode) {
    TXAD_GOOGLEADS_BANNER_NORMAL = 0, // Normal Banner
    TXAD_GOOGLEADS_BANNER_ADAPTIVE = 1 // Adaptive Banner
};

typedef NS_ENUM(NSUInteger, TXADGoogleAdsSplashOrientation) {
    TXAD_GOOGLEADS_SPLASH_ORIENTATION_PORTRAIT = 0, // Portrait
    TXAD_GOOGLEADS_SPLASH_ORIENTATION_LANDSCAPE = 1 // Landscape
};

typedef NS_ENUM(NSUInteger, TXADGoogleAdsRewardedVideoMode) {
    TXAD_GOOGLEADS_REWARDEDVIDEO_NORMAL = 0, // Rewarded Video
    TXAD_GOOGLEADS_REWARDEDVIDEO_INTERSTITIAL = 1 // Rewarded Interstitial
};
