//
//  TXADGoogleAdsAdMode.h
//  TaurusXAdMediation_GoogleAds
//
//  Created by TaurusXAds on 2020/3/2.
//  Copyright © 2020 TaurusXAds. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSUInteger, TXADGoogleAdsBannerMode) {
    TXAD_GOOGLEADS_BANNER_NORMAL = 0, // Normal Banner
    TXAD_GOOGLEADS_BANNER_ADAPTIVE = 1 // Adaptive Banner
};
