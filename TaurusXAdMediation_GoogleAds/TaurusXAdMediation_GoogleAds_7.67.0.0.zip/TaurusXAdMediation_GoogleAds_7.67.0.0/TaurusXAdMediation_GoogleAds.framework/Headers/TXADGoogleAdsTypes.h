//
//  TXADGoogleAdsType.h
//  TaurusXAdMediation_GoogleAds
//
//  Created by TaurusXAds on 2020/3/3.
//  Copyright © 2020 TaurusXAds. All rights reserved.
//

/// Orientation for an adaptive banner.
typedef NS_ENUM(NSUInteger, TXADGoogleAdsBannerOrientation) {
    kGoogleAdsBannerOrientationCurrent = 0,    ///< Current Orientation.
    kGoogleAdsBannerOrientationLandscape = 1,  ///< Landscape.
    kGoogleAdsBannerOrientationPortrait = 2,   ///< Portrait.
};
