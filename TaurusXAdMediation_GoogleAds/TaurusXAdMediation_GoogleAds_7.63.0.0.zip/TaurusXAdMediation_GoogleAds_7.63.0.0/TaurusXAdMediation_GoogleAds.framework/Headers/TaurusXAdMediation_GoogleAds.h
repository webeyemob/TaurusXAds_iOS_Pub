//
//  TaurusXAdMediation_GoogleAds.h
//  TaurusXAdMediation_GoogleAds
//
//  Created by TaurusXAds on 2018/9/13.
//

#import <UIKit/UIKit.h>

//! Project version number for TaurusXAdMediation_GoogleAds.
FOUNDATION_EXPORT double TaurusXAdMediation_GoogleAdsVersionNumber;

//! Project version string for TaurusXAdMediation_GoogleAds.
FOUNDATION_EXPORT const unsigned char TaurusXAdMediation_GoogleAdsVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TaurusXAdMediation_GoogleAds/PublicHeader.h>

#import <TaurusXAdMediation_GoogleAds/TXADAdMobBannerConfig.h>
#import <TaurusXAdMediation_GoogleAds/TXADAdMobGlobalConfig.h>

#import <TaurusXAdMediation_GoogleAds/TXADDFPBannerConfig.h>
#import <TaurusXAdMediation_GoogleAds/TXADDFPGlobalConfig.h>

#import <TaurusXAdMediation_GoogleAds/TXADGoogleAdsAdMode.h>

#import <TaurusXAdMediation_GoogleAds/GADAdSize_Preview.h>
