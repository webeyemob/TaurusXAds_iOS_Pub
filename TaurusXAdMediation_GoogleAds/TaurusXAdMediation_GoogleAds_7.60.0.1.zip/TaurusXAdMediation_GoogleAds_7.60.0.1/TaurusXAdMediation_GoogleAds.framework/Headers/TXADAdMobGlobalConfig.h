//
//  TXADAdMobGlobalConfig.h
//  TaurusXAdMediation_GoogleAds
//
//  Created by TaurusXAds on 2020/6/1.
//  Copyright © 2020 TaurusXAds. All rights reserved.
//

#import <TaurusXAds/TaurusXAds.h>

NS_ASSUME_NONNULL_BEGIN

@interface TXADAdMobGlobalConfig : TXADNetworkConfig

@property(nonatomic, strong) NSArray<NSString *> *testDeviceIdentifiers;

@end

NS_ASSUME_NONNULL_END
