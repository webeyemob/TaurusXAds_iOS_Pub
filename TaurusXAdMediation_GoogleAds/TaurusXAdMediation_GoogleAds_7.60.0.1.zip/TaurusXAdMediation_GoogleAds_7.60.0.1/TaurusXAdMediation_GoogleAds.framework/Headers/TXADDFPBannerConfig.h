//
//  TXADDFPBannerConfig.h
//  TaurusXAdMediation_GoogleAds
//
//  Created by TaurusXAds on 2020/3/2.
//  Copyright © 2020 TaurusXAds. All rights reserved.
//

#import <TaurusXAds/TaurusXAds.h>
#import <GoogleMobileAds/GADAdSize.h>
#import "TXADGoogleAdsTypes.h"

@interface TXADDFPBannerConfig : TXADNetworkConfig

@property(nonatomic, assign) GADAdSize adaptiveBannerAdSize;
+ (GADAdSize) getDefaultAdaptiveBannerAdSize;

// For Unity
- (void)setAdaptiveBannerSize:(CGFloat)width orientation:(TXADGoogleAdsBannerOrientation)orientation;

@end
