//
//  ABUAdKsAdapter.h
//  ABUAdKsAdapter
//
//  Created by XuQingJia on 2020/10/13.
//

#import <Foundation/Foundation.h>

//! Project version number for ABUAdKsAdapter.
FOUNDATION_EXPORT double ABUAdKsAdapterVersionNumber;

//! Project version string for ABUAdKsAdapter.
FOUNDATION_EXPORT const unsigned char ABUAdKsAdapterVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ABUAdKsAdapter/PublicHeader.h>


