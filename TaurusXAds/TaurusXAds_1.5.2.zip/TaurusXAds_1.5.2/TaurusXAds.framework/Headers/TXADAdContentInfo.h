//
//  TXADAdContentInfo.h
//  TaurusXAds
//
//  Created by TaurusXAds on 2019/11/28.
//  Copyright © 2019年 TaurusXAds. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef NS_ENUM(int, TXADAdIsApp) {
    TXAD_AD_ISAPP_YES = 0,      //yes
    TXAD_AD_ISAPP_NO = 1,        //no
    TXAD_AD_ISAPP_UNKNOWN = 2,  // unknown
};

typedef NS_ENUM(int, TXADAdContentType) {
    TXAD_AD_CONTENT_TYPE_UNKNOWN = 0,          // unknown
    TXAD_AD_CONTENT_TYPE_LARGE_IMAGE = 1,      //large image
    TXAD_AD_CONTENT_TYPE_SMALL_IMAGE = 2,      //small image
    TXAD_AD_CONTENT_TYPE_SMALL_IMAGE_VERTICAL = 3, //small image vertical
    TXAD_AD_CONTENT_TYPE_GROUP_IMAGE = 4,       //group image
    TXAD_AD_CONTENT_TYPE_VIDEO                  //video
};

@interface TXADAdContentInfo : NSObject

@property(nonatomic, strong) NSString *title;
@property(nonatomic, strong) NSString *subTitle;
@property(nonatomic, strong) NSString *body;
@property(nonatomic, strong) NSString *advertiser;
@property(nonatomic, strong) NSString *callToAction;

@property(nonatomic) TXADAdIsApp isApp;
@property(nonatomic) TXADAdContentType contentType;

@property(nonatomic, strong) NSString *iconUrl;
@property(nonatomic, strong) NSString *imageUrl;
@property(nonatomic, strong) NSString *videoUrl;
@property(nonatomic, strong) NSString *clickUrl;

@property(nonatomic, strong) NSString *rating;
@property(nonatomic, strong) NSString *store;
@property(nonatomic, strong) NSString *price;

@end


@interface TXADBannerData : TXADAdContentInfo

@end

@interface TXADNativeData : TXADAdContentInfo

@end

@interface TXADInterstitialData : TXADAdContentInfo

@end

@interface TXADRewardedVideoData : TXADAdContentInfo

@end

@interface TXADFeedData : TXADAdContentInfo

@end

@interface TXADSplashData : TXADAdContentInfo

@end
