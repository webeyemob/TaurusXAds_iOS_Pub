//
//  TXADAdLoader.h
//  TaurusXAds
//
//  Created by TXAD on 2020/1/9.
//  Copyright © 2020 TaurusXAds. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "TXADBannerView.h"
#import "TXADFeedList.h"
#import "TXADInterstitialAd.h"
#import "TXADMixViewAd.h"
#import "TXADMixFullScreenAd.h"
#import "TXADNativeAd.h"
#import "TXADRewardedVideoAd.h"
#import "TXADSplashAd.h"

NS_ASSUME_NONNULL_BEGIN

/*!
Class contains API for adLoader
*/
@interface TXADAdLoader : NSObject

+ (TXADBannerView *)getBannerAdView:(NSString *)adUnitId rootViewController: (UIViewController *)viewController;
+ (TXADNativeAd *)getNativeAd:(NSString *)adUnitId;
+ (TXADInterstitialAd *)getInterstitialAd:(NSString *)adUnitId;
+ (TXADRewardedVideoAd *)getRewardedVideoAd:(NSString *)adUnitId;
+ (TXADFeedList *)getFeedListAd:(NSString *)adUnitId;
+ (TXADSplashAd *)getSplashAd:(NSString *)adUnitId uiWindow: (UIWindow *)window;
+ (TXADMixViewAd *)getMixViewAd:(NSString *)adUnitId rootViewController: (UIViewController *)viewController;
+ (TXADMixFullScreenAd *)getMixFullScreenAd:(NSString *)adUnitId;

+ (void)destoryAd:(NSString *)adUnitId;


/**
* BannerAdView.
*/
+ (void)loadBanner:(NSString *)adUnitId rootViewController: (UIViewController *)viewController;

+ (void)loadBanner:(NSString *)adUnitId rootViewController: (UIViewController *)viewController withDelegate:(_Nullable id<TXADBannerViewDelegate> )delegate;

+ (BOOL) isBannerReady:(NSString *)adUnitId;

+ (void)showBanner: (NSString *)adUnitId viewContainer: (UIView *)viewContainer;

+ (void)showBanner: (NSString *)adUnitId viewContainer: (UIView *)viewContainer withDelegate:(_Nullable id<TXADBannerViewDelegate>)delegate;

+ (void)setBanner:(NSString *)adUnitId withDelegate:(_Nullable id<TXADBannerViewDelegate>)delegate;


/**
* NativeAdView.
*/
+ (void)loadNativeAd:(NSString *)adUnitId;

+ (void)loadNativeAd:(NSString *)adUnitId withDelegate:(_Nullable id<TXADNativeAdDelegate> )delegate;

+ (void)loadNativeAd:(NSString *)adUnitId withLayout:(TXADNativeAdLayout *)layout;

+ (void)loadNativeAd:(NSString *)adUnitId withLayout:(nullable TXADNativeAdLayout *)layout andDelegate:(_Nullable id<TXADNativeAdDelegate> )delegate;

+ (BOOL) isNativeAdReady:(NSString *)adUnitId;

+ (void)showNativeAd: (NSString *)adUnitId viewContainer: (UIView *)viewContainer;

+ (void)showNativeAd: (NSString *)adUnitId viewContainer: (UIView *)viewContainer withLayout:(TXADNativeAdLayout *)layout;

+ (void)showNativeAd: (NSString *)adUnitId viewContainer: (UIView *)viewContainer withDelegate:(_Nullable id<TXADNativeAdDelegate>)delegate;

+ (void)showNativeAd: (NSString *)adUnitId viewContainer: (UIView *)viewContainer withLayout:(nullable TXADNativeAdLayout *)layout andDelegate:(_Nullable id<TXADNativeAdDelegate>)delegate;

+ (void)setNativeAd:(NSString *)adUnitId withDelegate:(_Nullable id<TXADNativeAdDelegate>)delegate;

+ (void)setNativeAd:(NSString *)adUnitId withLayout:(TXADNativeAdLayout *)layout;

/**
* InterstitialAd.
*/
+ (void)loadInterstitialAd:(NSString *)adUnitId;

+ (void)loadInterstitialAd:(NSString *)adUnitId withDelegate:(_Nullable id<TXADInterstitialAdDelegate> )delegate;


+ (BOOL) isInterstitialAdReady:(NSString *)adUnitId;

+ (void)showInterstitialAd: (NSString *)adUnitId viewController: (nullable UIViewController *)viewController;


+ (void)showInterstitialAd: (NSString *)adUnitId viewController: (nullable UIViewController *)viewController withDelegate:(_Nullable id<TXADInterstitialAdDelegate>)delegate;

+ (void)setInterstitialAd:(NSString *)adUnitId withDelegate:(_Nullable id<TXADInterstitialAdDelegate>)delegate;

/**
* RewardedVideoAd.
*/
+ (void)loadRewardedVideoAd:(NSString *)adUnitId;
+ (void)loadRewardedVideoAd:(NSString *)adUnitId withDelegate:(_Nullable id<TXADRewardedVideoAdDelegate> )delegate;
+ (BOOL) isRewardedVideoAdReady:(NSString *)adUnitId;
+ (void)showRewardedVideoAd: (NSString *)adUnitId viewController: (nullable UIViewController *)viewController;
+ (void)showRewardedVideoAd: (NSString *)adUnitId viewController: (nullable UIViewController *)viewController withDelegate:(_Nullable id<TXADRewardedVideoAdDelegate>)delegate;
+ (void)setRewardedVideoAd:(NSString *)adUnitId withDelegate:(_Nullable id<TXADRewardedVideoAdDelegate>)delegate;

/**
* FeedListAd.
*/
+ (void)loadFeedListAd:(NSString *)adUnitId;
+ (void)loadFeedListAd:(NSString *)adUnitId count: (int)count;

+ (void)loadFeedListAd:(NSString *)adUnitId withDelegate:(_Nullable id<TXADFeedListDelegate> )delegate;

+ (void)loadFeedListAd:(NSString *)adUnitId count: (int)count withDelegate:(_Nullable id<TXADFeedListDelegate> )delegate;

+ (BOOL) isFeedListAdReady:(NSString *)adUnitId;

+ (NSArray<TXADFeed *> *)getFeedListAds:(NSString *)adUnitId;

+ (NSArray<TXADFeed *> *)getFeedListAds:(NSString *)adUnitId withDelegate:(_Nullable id<TXADFeedListDelegate> )delegate;

+ (void)setFeedListAd:(NSString *)adUnitId withDelegate:(_Nullable id<TXADFeedListDelegate>)delegate;

/**
* SplashAd.
*/
+ (void)loadSplashAd:(NSString *)adUnitId uiWindow:(UIWindow *)uiWindow;
+ (void)loadSplashAd:(NSString *)adUnitId uiWindow:(UIWindow *)uiWindow withDelegate:(_Nullable id<TXADSplashAdDelegate> )delegate;
+ (BOOL) isSplashAdReady:(NSString *)adUnitId;
+ (void)setSplashAd:(NSString *)adUnitId withDelegate:(_Nullable id<TXADSplashAdDelegate>)delegate;


/**
* MixViewAd.
*/
+ (void)loadMixViewAd:(NSString *)adUnitId rootViewController: (UIViewController *)viewController;

+ (void)loadMixViewAd:(NSString *)adUnitId rootViewController: (UIViewController *)viewController withDelegate:(_Nullable id<TXADMixViewAdDelegate> )delegate;

+ (void)loadMixViewAd:(NSString *)adUnitId rootViewController: (UIViewController *)viewController withLayout:(TXADNativeAdLayout *)layout;

+ (void)loadMixViewAd:(NSString *)adUnitId rootViewController: (UIViewController *)viewController withLayout:(nullable TXADNativeAdLayout *)layout andDelegate:(_Nullable id<TXADMixViewAdDelegate> )delegate;

+ (BOOL) isMixViewAdReady:(NSString *)adUnitId;

+ (void)showMixViewAd: (NSString *)adUnitId viewContainer: (UIView *)viewContainer;

+ (void)showMixViewAd: (NSString *)adUnitId viewContainer: (UIView *)viewContainer withLayout:(TXADNativeAdLayout *)layout;

+ (void)showMixViewAd: (NSString *)adUnitId viewContainer: (UIView *)viewContainer withDelegate:(_Nullable id<TXADMixViewAdDelegate>)delegate;

+ (void)showMixViewAd: (NSString *)adUnitId viewContainer: (UIView *)viewContainer withLayout:(nullable TXADNativeAdLayout *)layout andDelegate:(_Nullable id<TXADMixViewAdDelegate>)delegate;

+ (void)setMixViewAd:(NSString *)adUnitId withDelegate:(_Nullable id<TXADMixViewAdDelegate>)delegate;

+ (void)setMixViewAd:(NSString *)adUnitId withLayout:(TXADNativeAdLayout *)layout;

/**
* MixFullScreenAd.
*/
+ (void)loadMixFullScreenAd:(NSString *)adUnitId;

+ (void)loadMixFullScreenAd:(NSString *)adUnitId withLayout:(TXADNativeAdLayout *)layout;

+ (void)loadMixFullScreenAd:(NSString *)adUnitId withDelegate:(id<TXADMixFullScreenAdDelegate> )delegate;

+ (void)loadMixFullScreenAd:(NSString *)adUnitId withLayout:(nullable TXADNativeAdLayout *)layout andDelegate:(_Nullable id<TXADMixFullScreenAdDelegate> )delegate;

+ (BOOL) isMixFullScreenAdReady:(NSString *)adUnitId;

+ (void)showMixFullScreenAd: (NSString *)adUnitId viewController: (UIViewController *)viewController;

+ (void)showMixFullScreenAd: (NSString *)adUnitId viewController: (UIViewController *)viewController withLayout:(TXADNativeAdLayout *)layout;


+ (void)showMixFullScreenAd: (NSString *)adUnitId viewController: (UIViewController *)viewController withDelegate:(_Nullable id<TXADMixFullScreenAdDelegate>)delegate;

+ (void)showMixFullScreenAd: (NSString *)adUnitId viewController: (UIViewController *)viewController withLayout:(nullable TXADNativeAdLayout *)layout andDelegate:(_Nullable id<TXADMixFullScreenAdDelegate>)delegate;

+ (void)setMixFullScreenAd:(NSString *)adUnitId withDelegate:(_Nullable id<TXADMixFullScreenAdDelegate>)delegate;
+ (void)setMixFullScreenAd:(NSString *)adUnitId withLayout:(TXADNativeAdLayout *)layout;


@end

NS_ASSUME_NONNULL_END
