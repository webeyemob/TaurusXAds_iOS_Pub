//
//  TXADNetworkConfig.h
//  TXADSdk
//
//  Created by Matthew on 2019/10/8.
//  Copyright © 2019年 TXAD. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TXADNetworkConfig : NSObject

-(void)log:(NSString *)message;

@end
