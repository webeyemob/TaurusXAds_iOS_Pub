//
//  TXADLineItemFilter.h
//  TaurusXAds
//
//  Created by TaurusXAds on 2020/6/29.
//  Copyright © 2020 TaurusXAds. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "TXADILineItem.h"

NS_ASSUME_NONNULL_BEGIN

/**
 过滤 LineItem 的接口。
 用于方便本地测试时，单独测试 AdUnit 里面的某些 LineItem，比如某个 Network、AdType 等。
 */
@protocol TXADLineItemFilter<NSObject>

@required
- (BOOL)txAdAcceptLineItem:(TXADILineItem *)lineItem;

@end

NS_ASSUME_NONNULL_END
