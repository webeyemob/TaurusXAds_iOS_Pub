//
//  TXADNetwork.h
//  Created by TaurusXAds on 2019/6/15.
//

#import <Foundation/Foundation.h>

/*!
Id of Network supported by SDK.
 */
typedef NS_ENUM(NSInteger, TXADNetworkId) {
    TXAD_NETWORK_UNKNOWN = 0,
    TXAD_NETWORK_ADCOLONY = 1,
    TXAD_NETWORK_ADMOB = 2,
    TXAD_NETWORK_APPLOVIN = 3,
    TXAD_NETWORK_CHARTBOOST = 4,
    TXAD_NETWORK_FACEBOOK = 5,
    TXAD_NETWORK_IRON_SOURCE = 6,
    TXAD_NETWORK_MOPUB = 7,
    TXAD_NETWORK_UNITY = 8,
    TXAD_NETWORK_MARKETPLACE = 9,
    TXAD_NETWORK_FYBER = 10,
    TXAD_NETWORK_INMOBI = 11,
    TXAD_NETWORK_VUNGLE = 12,
    TXAD_NETWORK_DFP = 13,
    TXAD_NETWORK_CREATIVE = 14,
    TXAD_NETWORK_DAP = 15,
    TXAD_NETWORK_BAIDU = 16,
    TXAD_NETWORK_DISPLAYIO = 17,
    TXAD_NETWORK_TOUTIAO = 18,
    TXAD_NETWORK_GDT = 19,
    TXAD_NETWORK_AMAZON = 20,
    TXAD_NETWORK_FLURRY = 21,
    TXAD_NETWORK_TAPJOY = 22,
    TXAD_NETWORK_360 = 23,
    TXAD_NETWORK_XIAOMI = 24,
    TXAD_NETWORK_4399 = 25,
    TXAD_NETWORK_OPPO = 26,
    TXAD_NETWORK_VIVO = 27,
    TXAD_NETWORK_MOBVISTA = 28,
    TXAD_NETWORK_NEND = 29,
    TXAD_NETWORK_ADGENERATION = 30,
    TXAD_NETWORK_MAIO = 31,
    TXAD_NETWORK_ALIGAMES = 32,
    TXAD_NETWORK_CRITEO = 33,
    TXAD_NETWORK_ZHONGHUI_ADS = 34,
    TXAD_NETWORK_TMS = 35,
    TXAD_NETWORK_FIVE = 36,
    TXAD_NETWORK_KUAISHOU = 37,
    TXAD_NETWORK_IMOBILE = 38,
    TXAD_NETWORK_PANGLE = 39
};

/*!
 Network supported by SDK.
 */
@interface TXADNetwork : NSObject

/*!
 @brief Id of Network.
 @see TXADNetworkId
 */
@property int mid;

/*!
 @brief Name of Network.
 */
@property NSString *name;

+(TXADNetwork *)fromId: (int) networkId;
+(NSString *)getName: (int)networkId;

@end
