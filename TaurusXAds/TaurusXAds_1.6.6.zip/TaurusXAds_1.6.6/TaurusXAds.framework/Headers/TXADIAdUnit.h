//
//  TXADIAdUnit.h
//  TaurusXAds
//
//  Created by TaurusXAds on 2020/2/1.
//  Copyright © 2020 TaurusXAds. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface TXADIAdUnit : NSObject

-(NSString *)getName;
-(NSString *)getId;

@end

NS_ASSUME_NONNULL_END
