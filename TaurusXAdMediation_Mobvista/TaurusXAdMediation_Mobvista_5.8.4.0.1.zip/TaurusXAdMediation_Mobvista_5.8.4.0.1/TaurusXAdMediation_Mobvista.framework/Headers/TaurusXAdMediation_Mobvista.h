//
//  TaurusXAdMediation_Mobvista.h
//  TaurusXAdMediation_Mobvista
//
//  Created by 汤正 on 2019/11/13.
//  Copyright © 2019 TaurusXAds. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for TaurusXAdMediation_Mobvista.
FOUNDATION_EXPORT double TaurusXAdMediation_MobvistaVersionNumber;

//! Project version string for TaurusXAdMediation_Mobvista.
FOUNDATION_EXPORT const unsigned char TaurusXAdMediation_MobvistaVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TaurusXAdMediation_Mobvista/PublicHeader.h>

#import <TaurusXAdMediation_Mobvista/TXADMobvistaRewardedVideoConfig.h>


