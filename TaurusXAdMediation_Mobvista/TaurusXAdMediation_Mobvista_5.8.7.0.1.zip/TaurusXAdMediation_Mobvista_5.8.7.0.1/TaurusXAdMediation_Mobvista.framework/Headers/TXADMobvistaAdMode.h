//
//  TXADMobvistaAdMode.h
//  TaurusXAdMediation_Mobvista
//
//  Created by TaurusXAds on 2020/2/3.
//  Copyright © 2020 TaurusXAds. All rights reserved.
//

typedef NS_ENUM(NSUInteger, TXADMobvistaInterstitialMode) {
    TXAD_MOBVISTA_INTERSTITIAL_NORMAL = 0, // 插屏
    TXAD_MOBVISTA_INTERSTITIAL_VIDEO = 1 // video插屏
};

typedef NS_ENUM(NSUInteger, TXADMobvistaRewardedVideoMode) {
    TXAD_MOBVISTA_REWARDEDVIDEO_NORMAL = 0, // 激励视频
    TXAD_MOBVISTA_REWARDEDVIDEO_INTERACTIVE = 1 // 交互式广告
};
