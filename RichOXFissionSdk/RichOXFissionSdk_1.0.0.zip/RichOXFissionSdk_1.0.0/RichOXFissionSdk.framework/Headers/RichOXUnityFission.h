//
//  RichOXUnityFission.h
//  RichOXFission_Moblink
//
//  Created by richox on 2021/6/29.
//  Copyright © 2021 richox. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RichOXFissionTypes.h"

NS_ASSUME_NONNULL_BEGIN

@interface RichOXUnityFission : NSObject

+ (RichOXUnityFission *)sharedInstance;

@property(nonatomic, assign) RichOXFissionTypeClientRef _Nullable* _Nullable fissionClient;


// 获取分享数据后，回调到 Unity 的接口
@property(nonatomic, assign) RichOXFissionGetInstallParamsCallback getInstallParamsCallback;


- (void)start;

@end

NS_ASSUME_NONNULL_END
