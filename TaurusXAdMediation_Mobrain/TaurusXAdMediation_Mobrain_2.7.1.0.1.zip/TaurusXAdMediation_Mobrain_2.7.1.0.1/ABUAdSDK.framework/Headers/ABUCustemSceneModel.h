//
//  ABURitSceneModel.h
//  ABUAdSDK
//
//  Created by wangchao on 2020/2/24.
//  Copyright © 2020 bytedance. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ABUAdSDKDefines.h"

@interface ABUCustemSceneModel : NSObject

@property (nonatomic, assign) NSInteger ritSceneType;
@property (nonatomic, copy) NSString *sceneDescirbe;

@end
