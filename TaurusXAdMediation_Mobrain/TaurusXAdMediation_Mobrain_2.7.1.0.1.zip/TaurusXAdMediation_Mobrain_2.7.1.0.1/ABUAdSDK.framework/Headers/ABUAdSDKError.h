//
//  ABUAdSDKError.h
//  BUAdSDK
//
//  Copyright © 2017年 bytedance. All rights reserved.
//

#import <Foundation/Foundation.h>

extern NSErrorDomain ABUErrorDomain;

typedef NS_ENUM (NSInteger, ABUErrorCode) {
    ABUErrorCodeLoadAdNoSetting                   = 40040, // load ad no setting
    ABUErrorCodeAdUnitIDInvalid                   = 40006, // adUnitID invalid
};
