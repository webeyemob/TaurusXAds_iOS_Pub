//
//  ABUDislikeWords.h
//  ABUAdSDK
//
//  Created by bytedance on 2021/9/29.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

/// 用户主动关闭广告原因，由自定义adapter开发者透传，内容不限，GroMore不对该数据进行处理[兼容旧版本]
//@interface ABUDislikeWords : NSDictionary
//
//@end

typedef NSDictionary ABUDislikeWords;

NS_ASSUME_NONNULL_END
