//
//  ABUAdSDKManager.h
//  ABUAdSDK
//
//  Created by wangchao on 2020/2/23.
//  Copyright © 2020 bytedance. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "ABUAdSDKDefines.h"



/// ABUAdSDKManager
@interface ABUAdSDKManager : NSObject

///SDKVersion
@property (nonatomic, copy, readonly, class) NSString *SDKVersion;

/**
 Register the App key that’s already been applied before requesting an ad from TikTok Audience Network.
 @param appID : the unique identifier of the App
 */
+ (void)setAppID:(NSString *)appID;


/// extra device data for ABUAdSDK
/// @param extraDeviceStr  eg:@"[{\"publisher_did\":\"62271333038\"}]"
+ (void)setExtDeviceData:(NSString *)extraDeviceStr;

/// Configure development mode.
/// @param level default BUAdSDKLogLevelNone
/// @param language default ABUAdSDKLogLanguageCH
+ (void)setLoglevel:(ABUAdSDKLogLevel)level language:(ABUAdSDKLogLanguage)language;

/// get appID
+ (NSString *)appID;

@end


