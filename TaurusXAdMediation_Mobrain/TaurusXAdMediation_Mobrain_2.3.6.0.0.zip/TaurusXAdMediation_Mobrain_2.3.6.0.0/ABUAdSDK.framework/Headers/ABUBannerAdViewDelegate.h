//
//  ABUBannerAdViewDelegate.h
//  ABUAdSDK
//
//  Created by wangchao on 2020/2/25.
//  Copyright © 2020 bytedance. All rights reserved.
//


#import "ABUDislikeWords.h"
#import "ABUMaterialMeta.h"


@class ABUBannerAdView;

@protocol ABUBannerAdViewDelegate <NSObject>

@optional

/**
 This method is called when bannerAdView ad slot loaded successfully.
 @param bannerAdView : view for bannerAdView
 */
- (void)bannerAdViewDidLoad:(ABUBannerAdView *_Nonnull)bannerAdView;

/**
 This method is called when bannerAdView ad slot failed to load.
 @param error : the reason of error
 */
- (void)bannerAdView:(ABUBannerAdView *_Nonnull)bannerAdView didLoadFailWithError:(NSError *_Nullable)error;

/**
This method is called when bannerAdView ad slot success to show.
*/
 - (void)bannerAdViewDidBecomVisible:(ABUBannerAdView *_Nonnull)bannerAdView;

/**
 * This method is called when FullScreen modal has been presented.Include appstore jump.
 *  弹出详情广告页
 */
- (void)bannerAdViewWillPresentFullScreenModal:(ABUBannerAdView *_Nonnull)bannerAdView;

/**
 ** This method is called when FullScreen modal has been dismissed.Include appstore jump.
 *  详情广告页将要关闭
 */
- (void)bannerAdViewWillDismissFullScreenModal:(ABUBannerAdView *_Nonnull)bannerAdView;

/**
 This method is called when bannerAdView is clicked.
 */
- (void)bannerAdViewDidClick:(ABUBannerAdView *_Nonnull)bannerAdView;

/**
 This method is called when the user clicked dislike button and chose dislike reasons.
 @param filterwords : the array of reasons for dislike.
*/

- (void)bannerAdViewDidClosed:(ABUBannerAdView *_Nonnull)bannerAdView dislikeWithReason:(NSArray<ABUDislikeWords *> *_Nullable)filterwords;


@end

