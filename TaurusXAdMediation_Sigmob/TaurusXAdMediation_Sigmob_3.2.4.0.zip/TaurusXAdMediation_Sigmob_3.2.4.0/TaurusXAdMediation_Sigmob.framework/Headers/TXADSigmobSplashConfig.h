//
//  TXADSigmobSplashConfig.h
//  TaurusXAdMediation_Sigmob
//
//  Created by TaurusXAds on 2020/3/6.
//  Copyright © 2020年 TaurusXAds. All rights reserved.
//

#import <TaurusXAds/TaurusXAds.h>

@interface TXADSigmobSplashConfig : TXADNetworkConfig

@property (nonatomic, strong) NSString *title;
@property (nonatomic, strong) NSString *desc;

@end
