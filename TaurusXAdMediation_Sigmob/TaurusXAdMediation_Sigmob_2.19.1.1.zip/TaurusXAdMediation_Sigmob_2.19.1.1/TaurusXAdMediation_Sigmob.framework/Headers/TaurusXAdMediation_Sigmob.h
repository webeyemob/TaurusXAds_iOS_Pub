//
//  TaurusXAdMediation_Sigmob.h
//  TaurusXAdMediation_Sigmob
//
//  Created by TaurusXAds on 2020/3/6.
//  Copyright © 2020 TaurusXAds. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for TaurusXAdMediation_Sigmob.
FOUNDATION_EXPORT double TaurusXAdMediation_SigmobVersionNumber;

//! Project version string for TaurusXAdMediation_Sigmob.
FOUNDATION_EXPORT const unsigned char TaurusXAdMediation_SigmobVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TaurusXAdMediation_Sigmob/PublicHeader.h>

#import <TaurusXAdMediation_Sigmob/TXADSigmobSplashConfig.h>


