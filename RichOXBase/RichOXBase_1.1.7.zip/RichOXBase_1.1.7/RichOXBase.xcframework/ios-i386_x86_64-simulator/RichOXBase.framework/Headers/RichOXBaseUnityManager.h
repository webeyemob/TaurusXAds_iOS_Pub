//
//  RichOXBaseUnityManager.h
//  RichOXBase
//
//  Created by RichOX on 2021/6/28.
//  Copyright © 2021 richox. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RichOXBaseTypes.h"

NS_ASSUME_NONNULL_BEGIN

@interface RichOXBaseUnityManager : NSObject

+ (RichOXBaseUnityManager *)sharedInstance;

@property(nonatomic, assign) RichOXBaseTypeManagerClientRef _Nullable* _Nullable managerClient;

@property(nonatomic, assign) RichOXBaseEventCallback eventCallback;

- (void)startWithAppId:(NSString *)appId initSuccess:(RichOXBaseInitSuccessCallback)initSuccess;

- (void)queryAppEventValue:(NSString *)eventName callback:(RichOXBaseAPPEventValueCallback)callback;

@end

NS_ASSUME_NONNULL_END
