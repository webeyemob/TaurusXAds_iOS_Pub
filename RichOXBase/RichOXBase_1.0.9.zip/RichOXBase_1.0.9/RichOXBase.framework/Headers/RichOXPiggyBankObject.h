//
//  RichOXPiggyBankObject.h
//  RichOXBase
//
//  Created by richox on 2021/6/25.
//  Copyright © 2021 richox. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface RichOXPiggyBankObject : NSObject

@property (nonatomic, strong, readonly) NSString *piggyBankId;             //储蓄罐id
@property (nonatomic, strong, readonly) NSString *appId;                   //应用id
@property (nonatomic, strong, readonly) NSString *piggyBankName;           //储蓄罐名称
@property (nonatomic, strong, readonly) NSString *userId;                  //用户id
@property (nonatomic, strong, readonly) NSString *toAssetName;             //提取资产的名称
@property (nonatomic, readonly) int srcPrizeAmount;                        //资产提取。储蓄罐值，源资产值。和to_prize_amount 一起决定储蓄罐值和目的资产的提取比率。
@property (nonatomic, readonly) int toPrizeAmount;                         //资产提取。储蓄罐值，目的资产值。和src_prize_amount 一起决定储蓄罐值和目的资产的提取比率。
@property (nonatomic, readonly) double prizeAmount;                        //资产值，最多支持小数点2位
@property (nonatomic, readonly) long updateTime;                           //毫秒，用户上次做任务的时间(unix时间戳). 如果没做做去过任务，则为0
@property (nonatomic, readonly) long lastWithdrawTime;                     //最近提取时间. 如果没有提取过，则为0


- (instancetype) initWithResponse:(NSDictionary *)dic;

@end

NS_ASSUME_NONNULL_END
