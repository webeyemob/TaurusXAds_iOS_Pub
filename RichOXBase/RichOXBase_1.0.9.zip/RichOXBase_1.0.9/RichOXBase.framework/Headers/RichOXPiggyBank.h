//
//  RichOXPiggyBank.h
//  RichOXBase
//
//  Created by richox on 2021/6/25.
//  Copyright © 2021 richox. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RichOXError.h"
#import "RichOXPiggyBankObject.h"

NS_ASSUME_NONNULL_BEGIN

typedef void (^RichOXQueryPiggyBankListBlock)(NSArray<RichOXPiggyBankObject *> *piggyBanks);

@interface RichOXPiggyBank : NSObject

/*!
@method queryPiggyBankList:failure
@abstract 此接口用于获取app内的储蓄罐信息
@param success 成功的block，参数是应用内的储蓄罐列表信息
@param failure 失败的block
*/
+ (void)queryPiggyBankList:(RichOXQueryPiggyBankListBlock)success failure:(RichOXFailureBlock _Nullable)failure;

/*!
@method piggyBankWithdraw:success:failure
@abstract 此接口用于q提取储蓄罐
@param piggyBankId 储蓄罐ID
@param success 成功的block，参数无
@param failure 失败的block
*/
+ (void)piggyBankWithdraw:(NSString *)piggyBankId success:(RichOXCommonSuccessBlock)success failure:(RichOXFailureBlock _Nullable)failure;


@end

NS_ASSUME_NONNULL_END
