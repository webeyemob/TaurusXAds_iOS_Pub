//
//  RichOXBaseType.h
//  RichOXBase
//
//  Created by zena.tang on 2020/12/14.
//  Copyright © 2020 richox. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface RichOXBaseType : NSObject

typedef NS_ENUM(NSInteger, RICHOX_BASE_MISSION_LIMITTYPE) {
    RICHOX_BASE_MISSION_LIMITTYPE_NONE               = 0, //无限制
    RICHOX_BASE_MISSION_LIMITTYPE_GLOBAL             = 1, //全局次数限制
    RICHOX_BASE_MISSION_LIMITTYPE_DAILY              = 2, //每日次数限制
    RICHOX_BASE_MISSION_LIMITTYPE_INTERVAL_DAYS      = 3, //最小间隔天数
    RICHOX_BASE_MISSION_LIMITTYPE_INTERVAL_MINUTES   = 4  //最小间隔分钟数
};


typedef NS_ENUM(NSInteger, RICHOX_BASE_MISSION_BONUSTYPE) {
    RICHOX_BASE_MISSION_BONUSTYPE_COIN               = 0, //金币
    RICHOX_BASE_MISSION_BONUSTYPE_CASH               = 1  //现金
};

typedef NS_ENUM(NSInteger, RICHOX_BASE_MISSION_COSTTYPE) {
    RICHOX_BASE_MISSION_COSTTYPE_NONE               = 0, //无
    RICHOX_BASE_MISSION_COSTTYPE_COIN               = 1, //金币
    RICHOX_BASE_MISSION_COSTTYPE_CASH               = 2  //现金
};

+ (RICHOX_BASE_MISSION_LIMITTYPE)matchLimieType:(NSString *)limitType;
+ (RICHOX_BASE_MISSION_BONUSTYPE)matchBounsType:(NSString *)bonusType;
+ (RICHOX_BASE_MISSION_COSTTYPE)matchCostType:(NSString *)costType;

@end

NS_ASSUME_NONNULL_END
