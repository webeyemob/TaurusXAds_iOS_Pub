//
//  RichOXEventManager.h
//  RichOX
//
//  Created by zena.tang on 2020/7/6.
//  Copyright © 2020 RichOX. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface RichOXEventManager : NSObject

+ (void)OnEvent:(NSString *)eventName eid:(NSUInteger)eid customParam: (NSDictionary * _Nullable)customParam;

@end

NS_ASSUME_NONNULL_END
