//
//  RichOXWithdrawInfo.h
//  RichOX
//
//  Created by zena.tang on 2021/1/13.
//  Copyright © 2021 richox. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface RichOXWithdrawInfo : NSObject

@property (nonatomic, strong, readonly) NSString * payMark;  //pay_remark
@property (nonatomic, strong) NSString *comment;             //备注
@property (nonatomic, strong) NSString *realName;            //用户真实姓名
@property (nonatomic, strong) NSString *idCard;              //用户身份证号
@property (nonatomic, strong) NSString *phoneNo;             //用户手机号，根据系统开关，如果当前提现通道需要提供手机号，则必须传入
@property (nonatomic, strong) NSString *withdrawChannel;     //提现通道标识，传入当前系统配置的提现通道标识。

- (instancetype)initWithPayremark:(NSString *)payMark;

@end

NS_ASSUME_NONNULL_END
