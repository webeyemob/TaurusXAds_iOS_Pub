//
//  RichOXUserExternalInfo.h
//  RichOXBase
//
//  Created by richox on 2021/9/14.
//  Copyright © 2021 richox. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface RichOXUserExternalInfo : NSObject

@property (nonatomic, strong, readonly) NSArray <NSString *> *payMethods;   // @"12101":wx  @"12102":ap
@property (nonatomic, readonly) BOOL isBindWX;                             //YES: has bind, NO: not bind
@property (nonatomic, strong, readonly) NSString *wxNickName;               //微信昵称，可能没有名称，显示空
@property (nonatomic, readonly) BOOL isBindAP;                             //YES: has bind, NO: not bind
@property (nonatomic, strong, readonly) NSString *apNickName;               //ap昵称，可能没有名称，显示空

- (instancetype) initWithData:(NSDictionary *)dic;

@end

NS_ASSUME_NONNULL_END
