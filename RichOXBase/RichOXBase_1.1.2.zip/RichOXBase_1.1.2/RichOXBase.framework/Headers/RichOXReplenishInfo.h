//
//  RichOXReplenishInfo.h
//  RichOXBase
//
//  Created by richox on 2021/6/8.
//  Copyright © 2021 richox. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface RichOXReplenishInfo : NSObject

@property (nonatomic, strong) NSString *phoneNo;             //充值手机号
@property (nonatomic, strong) NSString *productCode;         //手机充值产品码，产值产品唯一标识。（一般通过手机运营商、国家码、充值面值来决定充值产品码）


@end

NS_ASSUME_NONNULL_END
