//
//  RichOXUserManager.h
//  RichOXBase
//
//  Created by RichOX on 2021/5/11.
//  Copyright © 2021 richox. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RichOXError.h"
#import "RichOXUserObject.h"

NS_ASSUME_NONNULL_BEGIN

@interface RichOXUserManager : NSObject

typedef void (^RichOXUserGetUserInfoSuccessBlock)(RichOXUserObject *userData);

typedef void (^RichOXGetInviterInfoSuccessBlock)(RichOXUserBaseObject *data);

/*!
@method registerUserId:initInfo:success:failure
@abstract 此接口用于新安装用户获取游客身份
@param success 成功的block，参数是用户信息
@param failure 失败的block
*/
+ (void)registerUserId:(RichOXUserGetUserInfoSuccessBlock)success failure:(RichOXFailureBlock _Nullable)failure;

/*!
@method registerByFacebook:accessToken:success:failure:
@abstract 此接口用于新安装用户直接使用Facebook注册
@param openId  facebook用户的open_id
@param accessToken facebook用户的授权码token
@param success 成功的block，参数是绑定之后的用户信息
@param failure 失败的block
*/
+ (void)registerByFacebook:(NSString *)openId accessToken:(NSString *)accessToken success:(RichOXUserGetUserInfoSuccessBlock)success failure:(RichOXFailureBlock _Nullable)failure;

/*!
@method registerByGoogle:success:failure:
@abstract 此接口用于新安装用户直接使用Google账号注册
@param idToken  google用户的id_token
@param success 成功的block，参数是绑定之后的用户信息
@param failure 失败的block
*/
+ (void)registerByGoogle:(NSString *)idToken success:(RichOXUserGetUserInfoSuccessBlock)success failure:(RichOXFailureBlock _Nullable)failure;

/*!
@method registerByApple:appleToken:success:failure:
@abstract 此接口用于新安装用户直接使用Apple注册
@param appleName  apple用户名，可为nil
@param appleToken Apple用户登录后获取的token
@param success 成功的block，参数是绑定之后的用户信息
@param failure 失败的block
*/
+ (void)registerByApple:(NSString * _Nullable)appleName appleToken:(NSString *)appleToken success:(RichOXUserGetUserInfoSuccessBlock)success failure:(RichOXFailureBlock _Nullable)failure;

/*!
@method registerByWeChat:wxCode:success:failure:
@abstract 此接口用于新安装用户直接使用微信账号注册
@param wxAppId  微信开放平台应用id
@param wxCode 微信绑定code
@param success 成功的block，参数是绑定之后的用户信息
@param failure 失败的block
*/
+ (void)registerByWeChat:(NSString *)wxAppId wxCode:(NSString *)wxCode success:(RichOXUserGetUserInfoSuccessBlock)success failure:(RichOXFailureBlock _Nullable)failure;

/*!
@method bindUser:bindType:bindCode:success:failure:
@abstract 社交账号绑定
@param appId  google用户该值为google id 微信用户是微信应用的app_id, facebook用户是facebook用户的open_id, apple用户是apple user Id，微信用户是微信开放平台应用id
@param bindType 社交账号类型，参见RICHOX_BASE_BINDTYPE
@param bindCode 微信用户为微信绑定code, Facebook用户为 facebook用户的授权码token, google用户为用户的id_token, Apple用户是登录后获取的token，微信用户是微信绑定code
@param success 成功的block，参数是绑定之后的用户信息
@param failure 失败的block
*/
+ (void)bindUser: (NSString *)appId bindType:(RICHOX_BASE_BINDTYPE)bindType bindCode:(NSString *)bindCode success:(RichOXUserGetUserInfoSuccessBlock)success failure:(RichOXFailureBlock _Nullable)failure;

/*!
@method getUserInfo:success:failure:
@abstract 此接口用于获取指定用户昵称、头像、金币数等信息
@param userId 指定用户Id
@param success 成功的block，参数是用户信息
@param failure 失败的block
*/
+ (void)getUserInfo:(NSString *)userId success:(RichOXUserGetUserInfoSuccessBlock)success failure:(RichOXFailureBlock _Nullable)failure;

/*!
@method getUserInfo:failure:
@abstract 此接口用于获取当前用户昵称、头像、金币数等信息
@param success 成功的block，参数是用户信息
@param failure 失败的block
*/
+ (void)getUserInfo:(RichOXUserGetUserInfoSuccessBlock)success failure:(RichOXFailureBlock _Nullable)failure;

/*!
@method logOutUser:failure
@abstract 此接口用于注销指定用户，用户注销成功后，该用户设备将无法再次使用产品
@param success 成功的block，参数无
@param failure 失败的block
*/
+ (void)logOutUser:(RichOXCommonSuccessBlock)success failure:(RichOXFailureBlock _Nullable)failure;

/*!
@method getInviter:failure
@abstract 此接口用于获取当前用户的邀请人
@param success 成功的block，参数邀请人信息
@param failure 失败的block
*/
+ (void)getInviter:(RichOXGetInviterInfoSuccessBlock)success failure:(RichOXFailureBlock _Nullable)failure;

/*!
@method bindInviter:successfailure:
@abstract 此接口用于异步绑定邀请者, (为避免师徒关系出现环，后端会检测调用此接口的用户不能有徒弟，否则绑定失败)
@param inviterId  师傅ID
@param success 成功的block，参数是邀请记录
@param failure 失败的block
*/
+ (void)bindInviter:(NSString *)inviterId success: (RichOXCommonSuccessBlock)success failure:(RichOXFailureBlock _Nullable)failure;

@end

NS_ASSUME_NONNULL_END
