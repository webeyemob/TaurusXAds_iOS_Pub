//
//  RichOXUserObject.h
//  RichOXBase
//
//  Created by RichOX on 2021/5/11.
//  Copyright © 2021 richox. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RichOXSocialAccount.h"

NS_ASSUME_NONNULL_BEGIN


@interface RichOXUserBaseObject : NSObject

@property (nonatomic, strong, readonly) NSString *userId;             //用户唯一标识
@property (nonatomic, strong, readonly) NSString *name;               //用户昵称自动生成，绑定facebook后更新为facebook用户的name
@property (nonatomic, strong, readonly) NSString *avatar;             //头像URL,绑定微信后设置
@property (nonatomic, readonly) long createdAt;                       //用户注册时间戳，毫秒
@property (nonatomic, readonly) long serverNow;                       //当前服务器时间戳，毫秒


- (instancetype) initWithResponse:(NSDictionary *)dic;

@end

@interface RichOXUserObject : RichOXUserBaseObject

@property (nonatomic, strong, readonly) NSString *deviceId;           //设备唯一id
@property (nonatomic, strong, readonly) NSString *countryCode;        //用户注册时的两位国家码

@property (nonatomic, readonly) BOOL hasWithdrawn;                    //是否提现过

@property (nonatomic, readonly) long installAt;                       //安装时间时间戳，毫秒
@property (nonatomic, strong, readonly) NSString *inviterId;          //邀请者ID（师傅）
@property (nonatomic, strong, readonly) NSString *invitationCode;     //邀请码

@property (nonatomic, readonly) BOOL isNew;                           //是否新创建用户


@property (nonatomic, strong, readonly) RichOXAppleAccount *appleAccountInfo;     //Apple账号信息
@property (nonatomic, strong, readonly) RichOXGoogleAccount *googleAccountInfo;   //Google账号信息
@property (nonatomic, strong, readonly) RichOXFacebookAccount *fbAccountInfo;     //FB账号信息

@property (nonatomic, strong, readonly) RichOXWechatAccount *wxAccountInfo;       //微信账号信息

@property (nonatomic, strong, readonly) RichOXAPAccount *apAccountInfo;         //AP账号信息

- (instancetype) initWithResponse:(NSDictionary *)dic;

@end

NS_ASSUME_NONNULL_END
