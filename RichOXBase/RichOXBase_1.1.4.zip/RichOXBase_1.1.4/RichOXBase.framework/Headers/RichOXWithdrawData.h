//
//  RichOXWithdrawData.h
//  RichOX
//
//  Created by RichOX on 2020/12/14.
//  Copyright © 2020 richox. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RichOXBaseType.h"

NS_ASSUME_NONNULL_BEGIN


@interface RichOXWithdrawMissionData : NSObject

@property (nonatomic, strong, readonly) NSString *missionId;            //提现任务ID
@property (nonatomic, readonly) RICHOX_BASE_MISSION_COSTTYPE costType;   //提现申请costType
@property (nonatomic, readonly) float amount;                           //数量
@property (nonatomic, readonly) int limit;                              //限制
@property (nonatomic, strong, readonly) NSString *text;                 //提现文本
@property (nonatomic, strong, readonly) NSString *desc;                 //提现描述
@property (nonatomic, readonly) BOOL needConfirm;                       //提现申请是否需要确认
@property (nonatomic, strong, readonly) NSString *scene;                //提现场景
@property (nonatomic, readonly) BOOL isFree;                            //提现申请是否需要确认


@property (nonatomic, readonly) float minCash;                           //最小现金 cash_range_missions 有
@property (nonatomic, readonly) float maxCash;                           //最大现金 cash_range_missions 有

- (instancetype) initWithWithdrawMission:(NSDictionary *)mission;

@end

typedef NS_ENUM(NSInteger, RICHOX_BASE_WITHDRAW_STATUS) {
    RICHOX_BASE_WITHDRAW_STATUS_UNKNOWN                           = 0, //未知
    RICHOX_BASE_WITHDRAW_STATUS_AUDIT_WAIT                        = 1, //等待审核
    RICHOX_BASE_WITHDRAW_STATUS_AUDIT_PASS                        = 2, //审核通过
    RICHOX_BASE_WITHDRAW_STATUS_AUDIT_UNPASS                      = 3, //审核驳回
    RICHOX_BASE_WITHDRAW_STATUS_PAYING                            = 4, //正在打款
    RICHOX_BASE_WITHDRAW_STATUS_PAY_FAILTURE                      = 5, //提现失败
    RICHOX_BASE_WITHDRAW_STATUS_PAY_SUCCESS                       = 6 //提现成功
};

@interface RichOXWithdrawRecordData : NSObject

@property (nonatomic, strong, readonly) NSString *withdrawId;            //提现ID
@property (nonatomic, strong, readonly) NSString *userId;                //用户ID
@property (nonatomic, strong, readonly) NSString *missionId;             //任务ID
@property (nonatomic, readonly) float amount;                            //提现申请costType
@property (nonatomic, readonly) int coin;                                //金币数
@property (nonatomic, strong, readonly) NSString *payRemark;            //提现通道标识
@property (nonatomic, strong, readonly) NSString *requestDay;           //申请日期
@property (nonatomic, strong, readonly) NSString *withdrawChannel;      //提现通道标识
@property (nonatomic, readonly) RICHOX_BASE_WITHDRAW_STATUS status;      //审核状态

@property (nonatomic, strong, readonly) NSString *statusComment;        //提现通道标识
@property (nonatomic, readonly) BOOL isRefunded;                         //是否退款

- (instancetype) initWithWithdrawRecord:(NSDictionary *)record;

@end

@interface RichOXWithdrawData : NSObject

@property (nonatomic, readonly) int exchangeRate;  //今日提现汇率
@property (nonatomic, strong, readonly) NSString *withdrawChannel; //当前提现通道标识
@property (nonatomic, readonly) BOOL offerPhone;   //提现申请是否必须提供手机号

@property (nonatomic, strong, readonly) NSArray <RichOXWithdrawMissionData *>*missions;  //提现任务列表

@property (nonatomic, strong, readonly) NSArray <RichOXWithdrawMissionData *>*cashMissions;  //提现现金任务列表
@property (nonatomic, strong, readonly) NSArray <RichOXWithdrawMissionData *>*cashRangeMissions;  //提现现金范围任务列表

@property (nonatomic, strong, readonly) NSArray <RichOXWithdrawRecordData *>*records;   //用户提现记录列表

- (instancetype) initWithResponse:(NSDictionary *)dic;

@end

NS_ASSUME_NONNULL_END
