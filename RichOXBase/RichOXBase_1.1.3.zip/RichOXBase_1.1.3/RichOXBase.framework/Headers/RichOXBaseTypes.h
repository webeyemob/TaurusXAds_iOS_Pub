//
//  RichOXBaseTypes.h
//  RichOXBase
//
//  Created by RichOX on 2021/6/28.
//  Copyright © 2020 RichOX. All rights reserved.
//

/// Common
typedef const void *RichOXBaseTypeRef;

//RichOXError
typedef const void *RichOXErrorTypeRef;
typedef void (*RichOXUnityCommonSuccessCallback)(void);
typedef void (*RichOXUnityFailureCallback)(long code, char *message);

/// RichOXBaseManager
typedef const void *RichOXBaseTypeManagerClientRef;
typedef const void *RichOXBaseTypeManagerRef;

// init callback
typedef void (*RichOXBaseInitSuccessCallback)(RichOXBaseTypeManagerClientRef *managerClientRef);

// Event
typedef void (*RichOXBaseEventCallback)(RichOXBaseTypeManagerClientRef *managerClientRef,
                                 char *eventName, char *value, char *param);

// APP Event
typedef void (*RichOXBaseAPPEventValueCallback)(RichOXBaseTypeManagerClientRef *managerClientRef,
                                char *eventName, char *value);



//RichOXUser
typedef const void *RichOXTypeUserDataRef;
typedef const void *RichOXTypeUserBindResultRef;
typedef const void *RichOXTypeUserSocalAccountInfoRef;
typedef const void *RichOXTypeUserBasicDataInfoRef;
typedef const void *RichOXTypeUserBasicDataArrayRef;

typedef const void *RichOXTypeInitUserDataRef;


typedef void (*RichOXUserGetUserDataSuccessCallback)(RichOXTypeUserDataRef userData);
typedef void (*RichOXUserBindUserSuccessCallback)(RichOXTypeUserBindResultRef bindResult);
typedef void (*RichOXUserGetUsersBasicDataSuccessCallback)(RichOXTypeUserBasicDataArrayRef dataList);


//RichOXUserManager
typedef const void *RichOXTypeUserObjectRef;
typedef const void *RichOXTypeUserBasicObjectRef;
typedef const void *RichOXTypeAppleAccountRef;
typedef const void *RichOXTypeFacebookAccountRef;
typedef const void *RichOXTypeGoogleAccountRef;
typedef const void *RichOXTypeWechatAccountRef;

typedef void (*RichOXUserGetUserInfoSuccessCallback)(RichOXTypeUserObjectRef userObject);
typedef void (*RichOXUserGetInviterInfoSuccessCallback)(RichOXTypeUserBasicObjectRef userBasicObject);

//RichOXWithdraw
typedef const void *RichOXTypeWithdrawInfoRef;

//NSMutableDictionary
typedef const void *RichOXTypeMutableDictionaryRef;

//RichOXReplenishInfo
typedef const void *RichOXTypeReplenishInfoRef;


//RichOXUserExternalInfo
typedef const void *RichOXTypeUserExternalInfoRef;

typedef void (*RichOXUserGetUserExternalInfoSuccessCallback)(RichOXTypeUserExternalInfoRef userExtInfoRef);

//NSArray
typedef const void *RichOXTypeArrayRef;
