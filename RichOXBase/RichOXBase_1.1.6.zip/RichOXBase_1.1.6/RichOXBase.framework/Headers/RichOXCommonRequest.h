//
//  RichOXCommonRequest.h
//  RichOXBase
//
//  Created by RichOX on 2021/1/27.
//  Copyright © 2021 richox. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RichOXError.h"

NS_ASSUME_NONNULL_BEGIN

typedef void (^RichOXCommonRequestSuccess)(NSDictionary * responseDic);

@interface RichOXCommonRequest : NSObject

+ (NSString *)sceneConfigUrl;
+ (NSString *)stragegyUrl;
+ (NSString *)apiUrl;

+ (NSString *)ruleCustomDomain;
+ (NSString *)strategyDomain;
+ (NSString *)apiDomain;
+ (NSString *)toolKitDomain;

+ (NSDictionary *)customServices;

//和fission服务器的请求
+ (void) sendGetRequest:(NSString *)hostUrl param: (NSDictionary * _Nullable)param success:(RichOXCommonRequestSuccess)success failure: (RichOXFailureBlock)failure;
+ (void) sendPostRequest:(NSString *)hostUrl param: (NSDictionary * _Nullable)param success:(RichOXCommonRequestSuccess)success failure: (RichOXFailureBlock)failure;

//和richOX服务器的请求
+ (void) sendPostRequestToRichOX:(NSString *)hostUrl param: (NSDictionary * _Nullable)param success:(RichOXCommonRequestSuccess)success failure: (RichOXFailureBlock)failure;

+ (void) sendGetRequestToRichOX:(NSString *)hostUrl param: (NSDictionary * _Nullable)param success:(RichOXCommonRequestSuccess)success failure: (RichOXFailureBlock)failure;

//通用请求
+ (void) sendCommonPostRequest:(NSString *)hostUrl param: (NSDictionary * _Nullable)param success:(RichOXCommonRequestSuccess)success failure: (RichOXFailureBlock)failure;

+ (void) sendCommonGetRequest:(NSString *)hostUrl param: (NSDictionary * _Nullable)param success:(RichOXCommonRequestSuccess)success failure: (RichOXFailureBlock)failure;

@end

NS_ASSUME_NONNULL_END
