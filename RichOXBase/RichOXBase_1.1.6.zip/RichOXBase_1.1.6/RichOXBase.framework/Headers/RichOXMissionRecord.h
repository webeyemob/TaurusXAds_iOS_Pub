//
//  RichOXMissionRecord.h
//  RichOX
//
//  Created by RichOX on 2020/12/14.
//  Copyright © 2020 richox. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RichOXBaseType.h"

NS_ASSUME_NONNULL_BEGIN

@interface RichOXMissionRecord : NSObject

@property (nonatomic, strong, readonly) NSString *recordId;
@property (nonatomic, strong, readonly) NSString *userId;
@property (nonatomic, strong, readonly) NSString *missionId;

@property (nonatomic, readonly) RICHOX_BASE_MISSION_BONUSTYPE bonusType;
@property (nonatomic, readonly) float bonus;

@property (nonatomic, readonly) int multiply;

@property (nonatomic, readonly) RICHOX_BASE_MISSION_COSTTYPE costType;
@property (nonatomic, readonly) float cost;

@property (nonatomic, strong, readonly) NSString *executedAt;

@property (nonatomic, strong, readonly) NSString *multiplyAt;

- (instancetype) initWithResponse:(NSDictionary *)dic;

@end


@interface RichOXMissionSubmitResult : NSObject

@property (nonatomic, strong, readonly) RichOXMissionRecord *record;

@property (nonatomic, readonly) int coinDelta;                                  //金币变动
@property (nonatomic, readonly) float cashDelta;                                //现金变动
@property (nonatomic, readonly) int currentCoin;                                //当前金币
@property (nonatomic, readonly) float currentCash;                              //当前现金

- (instancetype) initWithResponse:(NSDictionary *)dic;

@end

@interface RichOXMissionQueryResult : NSObject

@property (nonatomic, strong, readonly) NSArray <RichOXMissionRecord *>* records;

@property (nonatomic, readonly) int total;                                     //总数
@property (nonatomic, readonly) int pageIndex;                                 //记录开始index
@property (nonatomic, readonly) int pageSize;                                  //记录每页的大小
@property (nonatomic, strong, readonly) NSString *begin;                       //开始时间
@property (nonatomic, strong, readonly) NSString *end;                         //结束时间

- (instancetype) initWithResponse:(NSDictionary *)dic;

@end

@interface RichOXMissionQueryCountResult : NSObject


@property (nonatomic, strong, readonly) NSString *missionId;                   //总数
@property (nonatomic, readonly) int count;                                     //数量
@property (nonatomic, strong, readonly) NSString *begin;                       //开始时间
@property (nonatomic, strong, readonly) NSString *end;                         //结束时间

- (instancetype) initWithResponse:(NSDictionary *)dic;

@end

@interface RichOXMissionTodayCoinsResult : NSObject


@property (nonatomic, strong, readonly) NSString *userId;                      //用户ID
@property (nonatomic, strong, readonly) NSString *day;                         //日期
@property (nonatomic, strong, readonly) NSString *version;                     //版本
@property (nonatomic, readonly) int coin;                                      //金币数
@property (nonatomic, readonly) int count;                                     //数量

- (instancetype) initWithResponse:(NSDictionary *)dic;

@end

NS_ASSUME_NONNULL_END
