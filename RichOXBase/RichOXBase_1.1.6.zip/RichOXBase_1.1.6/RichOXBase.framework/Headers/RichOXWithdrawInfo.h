//
//  RichOXWithdrawInfo.h
//  RichOX
//
//  Created by RichOX on 2021/1/13.
//  Copyright © 2021 richox. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface RichOXWithdrawInfo : NSObject

@property (nonatomic, strong, readonly) NSString * payMark;  //pay_remark
@property (nonatomic, strong) NSString *comment;             //备注
@property (nonatomic, strong) NSString *realName;            //用户真实姓名
@property (nonatomic, strong) NSString *idCard;              //用户身份证号
@property (nonatomic, strong) NSString *phoneNo;             //用户手机号，根据系统开关，如果当前提现通道需要提供手机号，则必须传入
@property (nonatomic, strong) NSString *withdrawChannel;     //提现通道标识，传入当前系统配置的提现通道标识。
@property (nonatomic) double withdrawAmount;                 //当任务为范围提现时，客户端设置的提现金额, 精确到小数后两位

@property (nonatomic, strong) NSString *withdrawWay;         //外部兑付渠道，'11101'， '11102'，'12101'，'12102
@property (nonatomic, strong) NSDictionary *extParam;         //当使用外部兑付渠道时，需要根据不同的兑付方式，传递对应的附加参数

- (instancetype)initWithPayremark:(NSString * _Nullable)payMark;

@end

NS_ASSUME_NONNULL_END
