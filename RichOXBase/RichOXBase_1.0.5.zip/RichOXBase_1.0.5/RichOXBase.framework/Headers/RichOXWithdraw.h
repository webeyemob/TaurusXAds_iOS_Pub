//
//  RichOXWithdraw.h
//  RichOX
//
//  Created by zena.tang on 2020/12/14.
//  Copyright © 2020 richox. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RichOXWithdrawData.h"
#import "RichOXError.h"
#import "RichOXWithdrawInfo.h"


NS_ASSUME_NONNULL_BEGIN

@interface RichOXWithdrawResult : NSObject

@property (nonatomic, readonly) int coinDelta;                                  //金币变动
@property (nonatomic, readonly) float cashDelta;                                //现金变动
@property (nonatomic, readonly) int currentCoin;                                //当前金币
@property (nonatomic, readonly) float currentCash;                              //当前现金

- (instancetype) initWithResponse:(NSDictionary *)dic;

@end


@interface RichOXWithdrawSetting : NSObject

@property (nonatomic, readonly) int minCoin;                                    //金币最小限制
@property (nonatomic, readonly) int minVersion;                                 //最小版本限制
@property (nonatomic, readonly) BOOL isFree;                                    //是否免费
@property (nonatomic, readonly) float amount;                                     //数量
@property (nonatomic, readonly) int limit;                                      //限制
@property (nonatomic, readonly) int consecutiveDays;                            //连续天数

- (instancetype) initWithResponse:(NSDictionary *)dic;

@end



typedef void (^RichOXGetWithdrawSuccessBlock)(RichOXWithdrawData *data);
typedef void (^RichOXRequestWithdrawSuccessBlock)(RichOXWithdrawResult *data);

/*!
包含提现 API.的类
*/
@interface RichOXWithdraw : NSObject

/*!
@method getWithdrawInfo
@abstract 此接口用于获取提现任务信息，以及用户提现记录，当日汇率等
@param success 成功的block，参数是RichOXWithdrawData
@param failure 失败的block
*/
+ (void)getWithdrawInfo:(RichOXGetWithdrawSuccessBlock)success failure:(RichOXFailureBlock)failure;

/*!
@method requestWithdraw
@abstract 此接口用于发起提现请求，客户端需根据当前系统配置的提现通道传入相关参数
@param missionId 激励任务ID
@param info 提现信息
@param success 成功的block，参数是提现结果
@param failure 失败的block
*/
+ (void)requestWithdraw:(NSString *)missionId info:(RichOXWithdrawInfo *)info success: (RichOXRequestWithdrawSuccessBlock)success failure:(RichOXFailureBlock)failure;


/*!
@method requestWeChatPay
@abstract 此接口用于发起微信企业付款提现请求，目前仅支持极速提现的场景
@param missionId 激励任务ID
@param payRemark 支付备注，将显示在微信红包中，20字符（10汉字）内，禁止特殊字符
@param comment 客户端备注信息,可为nil。
@param success 成功的block，参数是提现结果
@param failure 失败的block
*/
+ (void)requestWeChatPay:(NSString *)missionId  payRemark:(NSString *)payRemark comment:(NSString * _Nullable)comment success: (RichOXRequestWithdrawSuccessBlock)success failure:(RichOXFailureBlock)failure;


@end

NS_ASSUME_NONNULL_END
