//
//  RichOXError.h
//  RichOXBase
//
//  Created by zena.tang on 2020/12/14.
//  Copyright © 2020 richox. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, RichOXErrorCode) {
    RICHOX_ERRORCODE_ERR                         = -1, // 操作失败
    RICHOX_ERRORCODE_PARAM                       = -2, //参数错误
    RICHOX_ERRORCODE_SIGN                        = -3, //签名错误
    RICHOX_ERRORCODE_SERVER                      = -4, //服务器错误
    RICHOX_ERRORCODE_UNIMPLEMENTED               = -5, //功能未实现
    RICHOX_ERRORCODE_DEVICE_ID_NOT_MATCH         = -6, //设备ID不匹配
    
    RICHOX_ERRORCODE_MISSION_GLOBAL_COUNT        = -7, //超出全局次数限制
    RICHOX_ERRORCODE_MISSION_DAILY_COUNT         = -8, //超出每日次数限制
    RICHOX_ERRORCODE_MISSION_DAYS_INTERVAL       = -9, //超出最短天数间隔限制
    RICHOX_ERRORCODE_MISSION_MINUTES_INTERVAL    = -10, //超出最短分钟数间隔限制
    RICHOX_ERRORCODE_MISSION_DAILY_BONUS         = -11, //超出当日任务奖励限额
    RICHOX_ERRORCODE_MISSION_BONUS_MAX           = -12, //超出任务单次奖励限制
    RICHOX_ERRORCODE_MULTIPLY_TWICE              = -13, //已经翻倍过
    RICHOX_ERRORCODE_MULTIPLY_TIMEOUT            = -14, //已过可翻倍时间
    RICHOX_ERRORCODE_MULTIPLY_UNSUPPORTED        = -15, //任务不支持翻倍
    RICHOX_ERRORCODE_MULTIPLY_TOO_BIG            = -16, //翻倍倍数过大
    RICHOX_ERRORCODE_MULTIPLY_ZERO_BONUS         = -17, //奖励为0不可翻倍
    RICHOX_ERRORCODE_WECHAT_ALREADY_BOUND        = -18, //此微信已绑定过其他账号
    RICHOX_ERRORCODE_USER_BOUND_OTHER_WECHAT     = -19, //此用户已经绑定过其他微信账号
    RICHOX_ERRORCODE_UNSUPPORTED_SNS_TYPE        = -20, //暂不支持绑定此类社交账户
    RICHOX_ERRORCODE_CLIENT_OUTDATED             = -21, //请升级到最新版本
    RICHOX_ERRORCODE_INSUFFICIENT_COIN           = -22, //金币不足
    RICHOX_ERRORCODE_INSUFFICIENT_CASH           = -23, //现金不足
    
    RICHOX_ERRORCODE_ACCESS_FACEBOOK_FAILED      = -24, //获取facebook用户信息失败
    RICHOX_ERRORCODE_FACEBOOK_ALREADY_BOUND      = -25, //此facebook账号已绑定其他用户
    RICHOX_ERRORCODE_USER_BOUND_OTHER_FACEBOOK   = -26, //此用户已经绑定其他facebook账号
    RICHOX_ERRORCODE_ACCESS_GOOGLE_FAILED        = -27, //获取google用户信息失败
    RICHOX_ERRORCODE_GOOGLE_ALREADY_BOUND        = -28, //此google账号已绑定其他用户
    RICHOX_ERRORCODE_USER_BOUND_OTHER_GOOGLE     = -29, //此用户已经绑定其他google账号
    
    RICHOX_ERRORCODE_INVITEE_OUTDATED_BY_TIME    = -30, //您已经是老用户啦，无法被邀请
    RICHOX_ERRORCODE_INVITEE_OUTDATED_BY_COIN    = -31, //您已经是老用户啦，无法被邀请
    RICHOX_ERRORCODE_INVITEE_NO_WECHAT           = -32, //请先绑定微信
    RICHOX_ERRORCODE_INVITEE_ALREADY_INVITED     = -33, //您已被邀请过了
    RICHOX_ERRORCODE_INVITATION_CODE_INVALID     = -34, //无效的邀请码
    RICHOX_ERRORCODE_INVITATION_SELF             = -35, //不能邀请自己
    RICHOX_ERRORCODE_INVITATION_OVER_LIMIT       = -36, //邀请者当日邀请数量超出限制
    RICHOX_ERRORCODE_INVITER_NO_WECHAT           = -37, //邀请者需先绑定微信
    RICHOX_ERRORCODE_INVITEE_OUTDATED_BY_INVITATION      = -38, //您已经是老用户啦，无法被邀请
    
    RICHOX_ERRORCODE_ACTIVITY_NOT_EXISTS                        = -50, //活动不存在
    RICHOX_ERRORCODE_ACTIVITY_NOT_STARTED                       = -51, //活动未开始
    RICHOX_ERRORCODE_ACTIVITY_ENDED                             = -52, //活动已结束
    RICHOX_ERRORCODE_ACTIVITY_DRAW_NO_CHANCE                    = -53, //抽奖机会已用完
    RICHOX_ERRORCODE_ACTIVITY_DRAW_NOT_STARTED                  = -54, //未到抽奖时间
    RICHOX_ERRORCODE_ACTIVITY_DRAW_ENDED                        = -55, //抽奖时间已过
    RICHOX_ERRORCODE_ACTIVITY_DRAW_OVER_DAILY_COUNT_LIMIT       = -56, //您今天已经抽奖太多次了
    RICHOX_ERRORCODE_ACTIVITY_DRAW_OVER_TOTAL_COUNT_LIMIT       = -57, //你已经抽奖太多次了
    RICHOX_ERRORCODE_ACTIVITY_WITHDRAW_NOT_STARTED              = -58, //未到提现时间
    RICHOX_ERRORCODE_ACTIVITY_WITHDRAW_ENDED                    = -59, //提现时间已过
    RICHOX_ERRORCODE_ACTIVITY_WITHDRAW_INSUFFICIENT_CASH        = -60, //余额不足
    RICHOX_ERRORCODE_ACTIVITY_WITHDRAW_OVER_TOTAL_COUNT_LIMIT   = -61, //提现次数已用完
    RICHOX_ERRORCODE_ACTIVITY_WITHDRAW_OVER_DAILY_COUNT_LIMIT   = -62, //今日已提现过
    RICHOX_ERRORCODE_ACTIVITY_WITHDRAW_TOO_FREQUENT             = -63, //操作太频繁
    RICHOX_ERRORCODE_ACTIVITY_WITHDRAW_INVALID_CASH             = -64, //账户余额无效
    RICHOX_ERRORCODE_ACTIVITY_WITHDRAW_LIMIT                    = -65, //活动提现额度已用完
    RICHOX_ERRORCODE_ACTIVITY_GIFT_NOT_STARTED                  = -66, //未到兑奖时间
    RICHOX_ERRORCODE_ACTIVITY_GIFT_ENDED                        = -67, //兑奖时间已过
    RICHOX_ERRORCODE_ACTIVITY_GIFT_OVER_LIMIT                   = -68, //兑奖次数已用完
    RICHOX_ERRORCODE_ACTIVITY_EXCHANGE_NOT_STARTED              = -69, //未到积分兑换时间
    RICHOX_ERRORCODE_ACTIVITY_EXCHANGE_ENDED                    = -70, //积分兑换时间已过
    RICHOX_ERRORCODE_ACTIVITY_EXCHANGE_INSUFFICIENT_COIN        = -71, //积分不足
    RICHOX_ERRORCODE_ACTIVITY_GIFT_LIMIT                        = -72, //活动奖品已领完
    RICHOX_ERRORCODE_ACTIVITY_MISMATCH_COIN_CONDITION           = -73, //不满足活动金币条件
    
    RICHOX_ERRORCODE_CARD_EXCEED_DAILY_LIMIT                    = -80, //此卡片今天已刮完
    RICHOX_ERRORCODE_CARD_EXCEED_EXTRA_CHANCES                  = -81, //今日立即冷却机会已用完
    RICHOX_ERRORCODE_CARD_NOT_REQUESTED                         = -82, //卡片未领取
    RICHOX_ERRORCODE_CARD_NOT_EXISTS                            = -83, //卡片不存在
    RICHOX_ERRORCODE_CARD_COOLING_DOWN                          = -84, //卡片正在冷却中
    RICHOX_ERRORCODE_CARD_ALREADY_OPENED                        = -85, //卡片重复刮开
    
    RICHOX_ERRORCODE_ACCESS_APPLE_FAILED                        = -87, //获取apple用户信息失败
    RICHOX_ERRORCODE_APPLE_ALREADY_BOUND                        = -88, //此apple账号已绑定其他用户
    RICHOX_ERRORCODE_USER_BOUND_OTHER_APPLE                     = -89, //此用户已经绑定其他apple账号
    
    RICHOX_ERRORCODE_DUIBA_OFF                                  = -100, //兑吧活动功能未开启
    RICHOX_ERRORCODE_DUIBA_ADD_TIMES                            = -101, //兑吧增加抽奖次数失败
    
    RICHOX_ERRORCODE_WITHDRAW_ID_CARD_ABNORMAL                  = -200, //用户身份信息异常,已用于其他设备提现
    RICHOX_ERRORCODE_WITHDRAW_TOO_MANY_REQUESTS_TODAY           = -201, //今日提现次数过多，请明日再试
    RICHOX_ERRORCODE_WITHDRAW_EXCEED_MISSION_LIMIT              = -202, //当前提现任务次数超出限制
    RICHOX_ERRORCODE_WITHDRAW_EXCEED_MISSION_GLOBAL_LIMIT       = -203, //当前提现任务总次数超出限制
    
    RICHOX_ERRORCODE_TICKET_NOT_EXISTS                          = -301, //优惠券不存在
    RICHOX_ERRORCODE_TICKET_NOT_STARTED                         = -302, //优惠券未到使用时间
    RICHOX_ERRORCODE_TICKET_EXPIRED                             = -303, //优惠券已过期
    RICHOX_ERRORCODE_TICKET_NO_STOCK                            = -304, //优惠券库存不足
    RICHOX_ERRORCODE_TICKET_WITHDRAW_FAILED                     = -305, //提现券使用失败
    RICHOX_ERRORCODE_TICKET_MISMATCH_INVITE_CONDITION           = -306, //不满足邀请人数条件
    
    RICHOX_ERRORCODE_FOREIGN_GIFT_CARD_NO_STOCK                 = -400, //礼品卡库存不足
    RICHOX_ERRORCODE_FOREIGN_GIFT_CARD_NOT_EXISTS               = -401, //礼品卡不存在
    RICHOX_ERRORCODE_FOREIGN_SNS_ACCOUNT_NOT_EXISTS             = -402, //用户未绑定社交账号
    RICHOX_ERRORCODE_EXCHANGE_EXCEED_GIFT_LIMIT                 = -403, //当前礼品卡兑换次数超出限制
    RICHOX_ERRORCODE_EXCHANGE_EXCEED_GIFT_GLOBAL_LIMIT          = -404, //当前礼品卡兑换总次数超出限制
    
    RICHOX_ERRORCODE_SIGN_IN_NOT_TODAY                          = -500, //仅支持当天签到
    RICHOX_ERRORCODE_SIGN_IN_WITHDRAW_DISABLED                  = -501, //签到提现已关闭
    RICHOX_ERRORCODE_SIGN_IN_WITHDRAW_INSUFFICIENT_COIN         = -502, //金币不足
    RICHOX_ERRORCODE_SIGN_IN_WITHDRAW_VERSION_TOO_LOW           = -503, //版本不兼容
    RICHOX_ERRORCODE_SIGN_IN_WITHDRAW_NOT_ENOUGH_DAYS           = -505, //未达到连续签到天数
    RICHOX_ERRORCODE_SIGN_IN_WITHDRAW_EXCEED_LIMIT              = -506, //签到提现次数过多
    RICHOX_ERRORCODE_SIGN_IN_ADDITIONAL_EXCEED_RANGE            = -507, //不在有效的补签天数范围内
    RICHOX_ERRORCODE_SIGN_IN_ADDITIONAL_EXCEED_LIMIT            = -508, //今日补签次数过多
    
    RICHOX_ERRORCODE_RED_PACKET_NOT_TODAY                       = -601, //仅能领取当天奖励
    RICHOX_ERRORCODE_RED_PACKET_CONFIG_NOT_EXISTS               = -602, //红包活动不存在
    RICHOX_ERRORCODE_RED_PACKET_EVENT_NOT_EXISTS                = -603, //事件不存在
    RICHOX_ERRORCODE_RED_PACKET_NO_USER                         = -604, //用户不存在
    RICHOX_ERRORCODE_RED_PACKET_USER_RECORD_NOT_EXISTS          = -605, //用户记录不存在
    RICHOX_ERRORCODE_RED_PACKET_ALREADY_DRAWN                   = -606, //今日已领取过
    RICHOX_ERRORCODE_RED_PACKET_EVENT_OVER_DAILY_LIMIT          = -607, //超出当日次数限制
    
    RICHOX_ERRORCODE_RANKING_LIST_NOT_EXISTS                    = -610, //排行榜不存在
    RICHOX_ERRORCODE_DEVICE_ID_IS_CANCELED                      = -611, //设备ID已注销
    RICHOX_ERRORCODE_DID_DEVICE_ID_UNSUITED                     = -612, //用户设备与did不一致
    
    RICHOX_ERRORCODE_LADDER_NOT_EXISTS                          = -620, //阶梯方案不存在
    RICHOX_ERRORCODE_LADDER_PACKET_CONF_NOT_EXISTS              = -621, //阶梯红包配置不存在
    RICHOX_ERRORCODE_LADDER_PACKET_NOT_EXISTS                   = -622, //阶梯红包不存在
    RICHOX_ERRORCODE_LADDER_PACKET_INVALID_CHECKSUM             = -623, //无效的checksum
    RICHOX_ERRORCODE_LADDER_MISSION_LIMIT                       = -624, //阶梯任务次数限制
    RICHOX_ERRORCODE_LADDER_MISSION_FINISHED                    = -625, //阶梯任务已完成
    RICHOX_ERRORCODE_LADDER_PRE_PACKET_NOT_WITHDRAW             = -626, //前置阶梯红包未完成提现
    RICHOX_ERRORCODE_LADDER_MISSION_NOT_FOUND                   = -627, //阶梯任务不存在
    RICHOX_ERRORCODE_LADDER_PACKET_PROGRESS_ABNORMAL            = -628, //用户进度异常
    RICHOX_ERRORCODE_LADDER_PACKET_PROGRESS_NOT_FINISH          = -629, //用户进度未满, 无法提现
    RICHOX_ERRORCODE_LADDER_PACKET_LOCKED                       = -630, //用户红包未解锁, 无法提现
    
    
    RICHOX_ERRORCODE_NETWORK_ERROR                              = -10000, //no code or response is nil
    RICHOX_ERRORCODE_INTERNAL                                   = -10001, //network error
    RICHOX_ERRORCODE_NO_USERID                                  = -10002, //用户ID为nil
    
    RICHOX_ERRORCODE_NOT_INITED                                 = -10004, //RichOX Base not inited
};

typedef void (^RichOXFailureBlock)(NSError *error);
typedef void (^RichOXCommonSuccessBlock)(void);


@interface RichOXError : NSObject

+ (NSError *)createError: (NSInteger)code message: (NSString * _Nullable)message;

@end

NS_ASSUME_NONNULL_END
