//
//  RichOXBaseManager.h
//  RichOXBase
//
//  Created by RichOX on 2020/12/12.
//  Copyright © 2020 richox. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef void (^RichOXThirdEventBlock)(NSString *eventName, NSDictionary * _Nullable param);

typedef void (^RichOXInitSuccessBlock)(void);

@interface RichOXBaseManager : NSObject

+ (void) initWithAppId: (NSString *)appId initSuccess:(RichOXInitSuccessBlock _Nullable)initSuccess;

+ (void) initWithAppId: (NSString *)appId __deprecated_msg("Use initWithAppId:initSuccess instead");

+ (void)setOverSea;
+ (BOOL)isOverSea;

+ (void) setHost:(NSString *)host key: (NSString *)key;

+ (NSString *)hostUrl;
+ (NSString *)keyStr;
+ (NSString *)deviceId;
+ (NSString *)fissionPlatform;
+ (NSString *)WDExtendInfo;

+ (NSInteger)appVersion;

+ (void) setTestMode:(BOOL)testMode;
+ (BOOL) isTestMode;

+ (void) setLogEnable:(BOOL)logEnable;
+ (BOOL)isLogEnable;

+ (NSString *)userId;

+ (void)cancelUser;

+ (void)setFissionPlatform: (NSString *)fissionPlatform;
+ (void)setAppVersion:(NSInteger)appVersion;

+ (void)saveUserId:(NSString *)userId;

//如果应用需要在不同的设备中共享账号需要设置该值，并保证同一个用户在不同的设备上一致
+ (void)setDeviceId: (NSString *)deviceId;

+ (int)getSdkVersionCode;
+ (NSString *)getSdkVersion;

+ (NSString *)appId;

+ (void)setEventBlock:(RichOXThirdEventBlock)block;
+ (void)setWDExtendInfo:(NSString *)extendInfo;

+ (void)reportAppEvent:(NSString *)eventName eventValue:(NSString * _Nullable)eventValue;

@end

NS_ASSUME_NONNULL_END
