//
//  RichOXBasePluginUtil.h

//
//  用于 Unity 的工具类。

#import <Foundation/Foundation.h>
#import "RichOXBaseTypes.h"

@interface RichOXBasePluginUtil : NSObject

/// 将 C 语言 UTF8 编码的 byte Array 转为 NSString；如果 bytes 为 NULL，返回 nil。
+ (NSString *)RichOXBaseStringFromUTF8String:(const char *)bytes;

@end
