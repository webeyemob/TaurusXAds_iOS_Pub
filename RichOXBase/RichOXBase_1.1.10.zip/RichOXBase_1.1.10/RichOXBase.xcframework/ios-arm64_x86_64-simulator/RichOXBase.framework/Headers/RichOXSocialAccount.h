//
//  RichOXSocialAccount.h
//  RichOX
//
//  Created by RichOX on 2020/12/14.
//  Copyright © 2020 richox. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, RICHOX_BASE_BINDTYPE) {
    RICHOX_BASE_BINDTYPE_WECHAT                      = 0, //微信
    RICHOX_BASE_BINDTYPE_FACEBOOK                    = 1,  // facebook
    RICHOX_BASE_BINDTYPE_GOOGLE                      = 2,  // google
    RICHOX_BASE_BINDTYPE_APPLE                       = 3,  // apple
    RICHOX_BASE_BINDTYPE_AP                          = 4,  // ap
};

typedef NS_ENUM(int, RICHOX_BASE_GENDER_TYPE) {
    RICHOX_BASE_GENDER_UNKNOWN                       = 0, //未知
    RICHOX_BASE_GENDER_MALE                          = 1,  // 男
    RICHOX_BASE_GENDER_FEMALE                        = 2   // 女
};


@interface RichOXSocialAccount : NSObject

- (instancetype) initWithAccountDic:(NSDictionary *)dic;

@end


@interface RichOXWechatAccount : RichOXSocialAccount

@property (nonatomic, strong, readonly) NSString *appId;               //用户唯一标识
@property (nonatomic, strong, readonly) NSString *openId;              //微信用户的open-id
@property (nonatomic, strong, readonly) NSString *unionId;             //微信用户的union-id
@property (nonatomic, strong, readonly) NSString *nickName;            //微信用户的昵称
@property (nonatomic, readonly) int sex;                                //性别
@property (nonatomic, strong, readonly) NSString *province;             //省份
@property (nonatomic, strong, readonly) NSString *city;                 //城市
@property (nonatomic, strong, readonly) NSString *country;              //国家
@property (nonatomic, strong, readonly) NSString *avatar;               //头像地址

@end

@interface RichOXGoogleAccount : RichOXSocialAccount

@property (nonatomic, strong, readonly) NSString *googleSub;        //google用户的
@property (nonatomic, strong, readonly) NSString *googleName;       //昵称
@property (nonatomic, strong, readonly) NSString *familyName;       //姓
@property (nonatomic, strong, readonly) NSString *givenName;        //名
@property (nonatomic, strong, readonly) NSString *email;            //email


@end

@interface RichOXFacebookAccount : RichOXSocialAccount

@property (nonatomic, strong, readonly) NSString *openId;           //facebook用户的唯一标识
@property (nonatomic, strong, readonly) NSString *fbName;             //昵称
@property (nonatomic, strong, readonly) NSString *firstName;        //名
@property (nonatomic, strong, readonly) NSString *lastName;         //姓
@property (nonatomic, strong, readonly) NSString *email;            //email

@end

@interface RichOXAppleAccount : RichOXSocialAccount

@property (nonatomic, strong, readonly) NSString *appleSub;           //apple用户的唯一标识
@property (nonatomic, strong, readonly) NSString *appleName;               // app name
@end

@interface RichOXAPAccount : RichOXSocialAccount

@property (nonatomic, strong, readonly) NSString *apyId;              //AP用户的唯一标识
@property (nonatomic, strong, readonly) NSString *apyName;            // AP用户名

@end


NS_ASSUME_NONNULL_END
