//
//  RichOXMissionData.h
//  RichOX
//
//  Created by RichOX on 2020/12/14.
//  Copyright © 2020 richox. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RichOXBaseType.h"

NS_ASSUME_NONNULL_BEGIN

@interface RichOXMissionData : NSObject

@property (nonatomic, strong, readonly) NSString *id;     //mission-id
@property (nonatomic, strong, readonly) NSString *name;   //name
@property (nonatomic, readonly) RICHOX_BASE_MISSION_LIMITTYPE limitType;   //限制类型：global，全局，每日，间隔
@property (nonatomic, readonly) int limit;                                //限制次数

@property (nonatomic, readonly) RICHOX_BASE_MISSION_BONUSTYPE bonusType;   //奖励类型：金币 or 现金
@property (nonatomic, readonly) float bonus;                                //奖励数
@property (nonatomic, readonly) float bonusMax;                             //最大奖励数

@property (nonatomic, readonly) RICHOX_BASE_MISSION_COSTTYPE costType;     //消耗类型：none。金币，现金
@property (nonatomic, readonly) float cost;                                 //消耗数

@property (nonatomic, readonly) BOOL supportMultiply;                     //是否支持翻倍
@property (nonatomic, readonly) BOOL supportclientControl;                //是否支持客户端控制

@property (nonatomic, readonly) int maxMultiply;                          //最大翻倍数
@property (nonatomic, readonly) int dailyBonusLimit;                      //每日奖励限制

- (instancetype) initWithResponse:(NSDictionary *)dic;

@end

NS_ASSUME_NONNULL_END
