//
//  RichOXError.h
//  RichOXBase
//
//  Created by RichOX on 2020/12/14.
//  Copyright © 2020 richox. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, RichOXErrorCode) {
    RICHOX_ERRORCODE_SUCCESS                                     = 0,   //成功
    
    //RichOX 服务端返回错误
    //系统级错误码
    RICHOX_ERRORCODE_ERR                         = 3001,             //-1, // 操作失败
    RICHOX_ERRORCODE_PARAM                       = 3002,             //-2, //参数错误
    RICHOX_ERRORCODE_SIGN                        = 3003,             //-3, //签名错误
    RICHOX_ERRORCODE_SERVER                      = 3004,             //-4, //服务器错误
    RICHOX_ERRORCODE_UNIMPLEMENTED               = 3005,             //-5, //功能未实现
    RICHOX_ERRORCODE_DEVICE_ID_NOT_MATCH         = 3006,             //-6, //设备ID不匹配
    RICHOX_ERRORCODE_REQUEST_INVALID             = 3013,             //请求时间戳超期
    RICHOX_ERRORCODE_APPID_INVALID               = 3017,             //应用id在广告平台未配置
    
    //用户接口错误码
    RICHOX_ERRORCODE_USER_NOTEXISTS                              = 3101, //用户不存在
    RICHOX_ERRORCODE_USER_DEVICEIS_CANCELED                      = 3102, //用户设备已注销
    RICHOX_ERRORCODE_USER_DIDNOTMATCHED                          = 3103, //用户设备与did不一致
    RICHOX_ERRORCODE_USER_NOTSUPPORTSNSBINDTYPE                  = 3104, //不支持的绑定社交账号类型
    RICHOX_ERRORCODE_USER_ACCESSFBUSERINFOFAILED                 = 3105, //获取facebook服务器信息失败
    RICHOX_ERRORCODE_USER_FBACCOUNTHASBINDBYOTHERUSER            = 3106, //fb账号已经被其他用户绑定
    RICHOX_ERRORCODE_USER_USERHASBINDOTHERFBACCOUNT              = 3107, //当前用户已经绑定了其他fb账号
    RICHOX_ERRORCODE_USER_ACCESSGOOGLEUSERINFOFAILED             = 3108, //获取google服务器信息失败
    RICHOX_ERRORCODE_USER_GOOGLEACCOUNTHASBINDBYOTHERUSER        = 3109, //google账号已经被其他用户绑定
    RICHOX_ERRORCODE_USER_USERHASBINDOTHERGOOGLEACCOUNT          = 3110, //当前用户已经绑定了其他google账号
    RICHOX_ERRORCODE_USER_ACCESSAPPLEUSERINFOFAILED              = 3111, //获取Apple服务器信息失败
    RICHOX_ERRORCODE_USER_APPLEACCOUNTHASBINDBYOTHERUSER         = 3112, //Apple账号已经被其他用户绑定
    RICHOX_ERRORCODE_USER_USERHASBINDOTHERAPPLEACCOUNT           = 3113, //当前用户已经绑定了其他Apple账号
    RICHOX_ERRORCODE_USER_USERNOTBINDWECHAT                      = 3114, //用户未绑定微信
    RICHOX_ERRORCODE_USER_ACCESSWXUSERINFOFAILED                 = 3115, //获取微信服务器信息失败
    RICHOX_ERRORCODE_USER_WXACCOUNTHASBINDBYOTHERUSER            = 3116, //微信账号已经被其他用户绑定
    RICHOX_ERRORCODE_USER_USERHASBINDOTHERWXACCOUNT              = 3117, //当前用户已经绑定了其他微信账号
    RICHOX_ERRORCODE_USER_INVITEENOTBINDSNS                      = 3124, //徒弟未绑定社交账号
    RICHOX_ERRORCODE_USER_INVITERNOTBINDSNS                      = 3125, //师傅未绑定社交账号
    RICHOX_ERRORCODE_USER_NOTHAVEINVITER                         = 3126, //当前用户没有师傅
    RICHOX_ERRORCODE_USER_INVITERNOTEXIST                        = 3127, //当前用户的师傅不存在
    
    //宗门接口错误码
    RICHOX_ERRORCODE_SECT_NOTENABLE                              = 3201, //宗门未启用
    RICHOX_ERRORCODE_SECT_NOTEXIST                               = 3202, //当前师傅的宗门信息不存在
    RICHOX_ERRORCODE_SECT_GETSETTINGFAILED                       = 3203, //获取宗门配置信息失败
    RICHOX_ERRORCODE_SECT_INVITERNOTSUFFICIENT                   = 3204, //宗门邀请人数不达标
    RICHOX_ERRORCODE_SECT_INVITERAWARDHASRECEIVED                = 3205, //宗门奖励已经领取
    RICHOX_ERRORCODE_SECT_INVITERAWARISINVALIED                  = 3206, //宗门邀请的人数不是有效的值
    RICHOX_ERRORCODE_SECT_TRANSFORMSTEPISINVALIED                = 3207, //宗门异变步骤无效
    RICHOX_ERRORCODE_SECT_TRANSFORMSTEPINOTSETTING               = 3208, //宗门异变步骤未配置
    RICHOX_ERRORCODE_SECT_TRANSFORMSTENOTENOUGH                  = 3209, //宗门异变贡献值不够
    RICHOX_ERRORCODE_SECT_NOTCREATED                             = 3210, //当前用户的宗门未创建
    RICHOX_ERRORCODE_SECT_HASBEINVITEDBYOTHERMASTER              = 3211, //当前用户已经被其他宗门师傅邀请
    RICHOX_ERRORCODE_SECT_CANNOTINVITEYOURSELF                   = 3212, //不能邀请自己加入自己的宗门
    RICHOX_ERRORCODE_SECT_BINDMASTERTIMEOUT                      = 3213, //绑定宗门师傅关系超时
    RICHOX_ERRORCODE_SECT_MASTERSECTNOTCREATED                   = 3214, //你的师傅宗门未创建
    RICHOX_ERRORCODE_SECT_HASSTUDENTALREADY                      = 3215, //你已经有宗门徒弟
    RICHOX_ERRORCODE_SECT_INTERNALERROR                          = 3299, //宗门接口内部错误
    
    //提现错误码
    RICHOX_ERRORCODE_WD_USERERROR                                = 3301, //异常用户, 无法提现
    RICHOX_ERRORCODE_WD_USERINVALIED                             = 3302, //用户身份信息异常,已用于其他设备提现
    RICHOX_ERRORCODE_WD_TOOMUCHTODAY                             = 3303, //今天提现次数已达上限
    RICHOX_ERRORCODE_WD_TOTALTOOMUCH                             = 3304, //提现任务的提现次数达到上限
    RICHOX_ERRORCODE_WD_GLOBALTIMESISOVERLIMITED                 = 3305, //当前提现任务的全局次数达到上限
    RICHOX_ERRORCODE_WD_EXTREMEBUDGETOUTDATED                    = 3306, //极速提现预算超期
    RICHOX_ERRORCODE_WD_CHANNELINVALIED                          = 3307, //请求的提现通道无效
    RICHOX_ERRORCODE_WD_TODAYOVERLIMITED                         = 3308, //当前提现任务的每天可用次数已超限
    RICHOX_ERRORCODE_WD_MISSIONTYPEINVALIED                      = 3309, //提现任务的类型不正确
    RICHOX_ERRORCODE_WD_MISSIONIDISEXISTS                        = 3310, //提现任务的类型不正确
    RICHOX_ERRORCODE_WD_MISSIONIDNOTFOUND                        = 3311, //提现任务的类型不正确
    RICHOX_ERRORCODE_WD_NOTSUPPORT                               = 3312, //不支持当前的提现方法
    RICHOX_ERRORCODE_WD_USERACCOUNTISABNORMAL                    = 3313, //用户账号已注销
    RICHOX_ERRORCODE_WD_CHANNELMERCHANTISABNORMAL                = 3314, //提现通道的商户号异常
    RICHOX_ERRORCODE_WD_CHANNELISABNORMAL                        = 3315, //提现通道异常
    RICHOX_ERRORCODE_WD_APPVERSIONTOOOLDER                       = 3316, //用户应用版本太低
    RICHOX_ERRORCODE_WD_INVALIEDPHONENUMBER                      = 3317, //无效的手机号码
    RICHOX_ERRORCODE_WD_INVALIEDAMOUNTTYPE                       = 3318, //无效的提现任务的付款类型
    RICHOX_ERRORCODE_WD_AMOUNTTYEERROR                           = 3319, //提现任务的付款类型错误
    RICHOX_ERRORCODE_WD_EXTREMEREJECT                            = 3320, //拒绝极速提现
    RICHOX_ERRORCODE_WD_OPERATEFAILED                            = 3321, //三方提现接口操作失败
    RICHOX_ERRORCODE_WD_CREDITPRODECTCODENOTEXIST                = 3322, //话费产品code不存在
    RICHOX_ERRORCODE_WD_CREDITPRODECTNOMINALINCONSISTENT         = 3323, //话费产品的面值和请求金额不一致
    RICHOX_ERRORCODE_WD_REQNOHASEXIST                            = 3324, //提现请求流水号已存在
    RICHOX_ERRORCODE_WD_NOTSUPPRTCOUNTRY                         = 3325, //不支持当前国家的话费提现
    RICHOX_ERRORCODE_WD_REQPARAMERROR                            = 3326, //提现订单查询接口参数不正确
    RICHOX_ERRORCODE_WD_ORDERNOTEXIST                            = 3327, //提现订单不存在
    RICHOX_ERRORCODE_WD_EXTREMEAMOUNTOVERLIMIT                   = 3328, //极速提现请求的金额超限
    RICHOX_ERRORCODE_WD_REALNAMEISBLANK                          = 3329, //用户实名信息为空
    RICHOX_ERRORCODE_WD_PHONENUMBEROVERLIMIT                     = 3330, //手机号可充值次数达到上限
    
    //策略接口错误码
    RICHOX_ERRORCODE_WRONGPARAMETER                              = 5400, //参数错误
    RICHOX_ERRORCODE_STRATEGY_NOTEXISTS                          = 5401, //策略不存在
    RICHOX_ERRORCODE_STRATEGY_ALREADYEND                         = 5402, //策略无效(还没有开始或者已经结束)
    RICHOX_ERRORCODE_STRATEGY_DISABLE                            = 5403, //策略已经禁用
    RICHOX_ERRORCODE_STRATEGY_PRIZEAMOUNTOVERLIMIT               = 5404, //任务值超限(如超过最大值)
    RICHOX_ERRORCODE_STRATEGY_DAILYFREQUENCYOVERLIMIT            = 5405, //策略任务每日频率超限
    RICHOX_ERRORCODE_STRATEGY_WEEKLYFREQUENCYOVERLIMIT           = 5406, //策略任务每周频率超限
    RICHOX_ERRORCODE_STRATEGY_GLOBALFREQUENCTOVERLIMIT           = 5407, //策略任务全局频率超限
    RICHOX_ERRORCODE_STRATEGY_DAILYASSETOVERLIMIT                = 5408, //策略任务每日资产超限
    RICHOX_ERRORCODE_STRATEGY_WEEKLYASSETOVERLIMIT               = 5409, //策略任务每周资产超限
    RICHOX_ERRORCODE_STRATEGY_GLOBALASSETOVERLIMIT               = 5410, //策略任务全局资产超限
    RICHOX_ERRORCODE_STRATEGY_TASKASSETOVERLIMIT                 = 5411, //任务资产超限
    RICHOX_ERRORCODE_STRATEGY_WITHDRAWTIMESOVERLIMIT             = 5412, //提现次数超限
    RICHOX_ERRORCODE_STRATEGY_WITHDRAWINVITEUSERNOTENOUGH        = 5413, //提现邀请用户数未达标
    RICHOX_ERRORCODE_STRATEGY_ASSETNOTENOUGH                     = 5414, //资产值未达标(如提现或者资产兑换)
    RICHOX_ERRORCODE_STRATEGY_WITHDRAWFREQENCUOVERLIMIT          = 5415, //提现频率超限
    RICHOX_ERRORCODE_STRATEGY_ASSETEXCHANGEDISABLE               = 5416, //资产兑换禁用
    RICHOX_ERRORCODE_STRATEGY_ASSETEXCHANGENOTEXISTS             = 5417, //资产兑换任务不存在
    RICHOX_ERRORCODE_STRATEGY_ASSETTASKNOTMEETCONDTION           = 5418, //资产任务未达到门槛
    RICHOX_ERRORCODE_STRATEGY_EXCEPTIONUSERABNORMAL              = 5419, //异常用户(如反作弊识别的异常码)
        
    RICHOX_ERRORCODE_STRATEGY_WITHDRAWEXCEPTIONUSERVARDABNORMAL  = 5420, //任务提现-用户身份异常(如用户在其它设备登录等)
    RICHOX_ERRORCODE_STRATEGY_WITHDRAWCHANNELEXCEPTION           = 5421, //任务提现-提现渠道异常(如提现商户号出现问题)
    RICHOX_ERRORCODE_STRATEGY_WITHDRAWVERSIONLIMIT               = 5422, //任务提现-版本不支持(如低版本被禁止提现，需要升级到最新版本)

    RICHOX_ERRORCODE_STRATEGY_DAILYALLUSERASSETOVERLIMIT         = 5423, //策略任务每日资产超限
    RICHOX_ERRORCODE_STRATEGY_WEEKLYALLUSERASSETOVERLIMIT        = 5424, //策略任务每周资产超限
    RICHOX_ERRORCODE_STRATEGY_GLOBALALLUSERASSETOVERLIMIT        = 5425, //策略任务所有用户资产超限

    //微信支付错误码
    RICHOX_ERRORCODE_STRATEGY_WITHDRAWNOAUTH                     = 5426, //应用微信提现权限未开通(fission -214 )
    RICHOX_ERRORCODE_STRATEGY_WITHDRAWAMOUNTLIMIT                = 5427, //单笔提现金额超过微信商户上限/下限(fission -215 )
    RICHOX_ERRORCODE_STRATEGY_WITHDRAWNAMEMISMATCH               = 5428, //该用户微信实名信息不正确(fission -216)
    RICHOX_ERRORCODE_STRATEGY_WITHDRAWV2ACCOUNTSIMPLEBAN         = 5429, //用户微信支付账户未实名，无法付款(fission -217)
    RICHOX_ERRORCODE_STRATEGY_WITHDRAWSENDNUMLIMIT               = 5430, //该用户今日付款次数超过限制,如有需要请进入【微信支付商户平台-产品中心-付款到零钱-产品设置】进行修改(fission -218)

    RICHOX_ERRORCODE_STRATEGY_WITHDRAWSENDMONEYLIMIT             = 5431, //已达到今日商户付款额度上限(fission -219)
    RICHOX_ERRORCODE_STRATEGY_WITHDRAWRECEIVEDMONEYLIMIT         = 5432, //已达到今日付款给此用户额度上限(fission -220)
    RICHOX_ERRORCODE_STRATEGY_WITHDRAWFINANCIALWRONGCONFIG       = 5433, //财务配置错误
    RICHOX_ERRORCODE_STRATEGY_WITHDRAWOVERLIMITFORONEPHONE       = 5434, //同一个手机号码提现超限
    RICHOX_ERRORCODE_STRATEGY_WITHDRAWNOTMEETCUSTOMRULE          = 5435, //提现未满足自定义规则
    RICHOX_ERRORCODE_STRATEGY_WITHDRAWDISABLEORGANICUSER         = 5436, //禁止自然量用户提现

    RICHOX_ERRORCODE_PIGGYBANK_BEFOREWITHDRAWTIME                = 5450, //储蓄罐值未达到提现时间
    
    RICHOX_ERRORCODE_APPOFFLINE                                  = 5451, //应用已下线
    RICHOX_ERRORCODE_STRATEGY_SERVERERROR                        = 5500, //服务端内部错误
    
    //SDK 内部错误
    RICHOX_ERRORCODE_NETWORK_ERROR                              = 5900, //network error
    RICHOX_ERRORCODE_INTERNAL                                   = 5901, //internal error
    RICHOX_ERRORCODE_RESPONSE_DATA_NULL                         = 5910, //response null
    RICHOX_ERRORCODE_RESPONSE_DATA_PARSER_ERROR                 = 5911, //response data error
    
    RICHOX_ERRORCODE_NO_USERID                                  = 5990, //用户ID为nil
    RICHOX_ERRORCODE_NOT_INITED                                 = 5991, //RichOX Base not inited
    

    //fission error
    RICHOX_ERRORCODE_MISSION_GLOBAL_COUNT        = -7, //超出全局次数限制
    RICHOX_ERRORCODE_MISSION_DAILY_COUNT         = -8, //超出每日次数限制
    RICHOX_ERRORCODE_MISSION_DAYS_INTERVAL       = -9, //超出最短天数间隔限制
    RICHOX_ERRORCODE_MISSION_MINUTES_INTERVAL    = -10, //超出最短分钟数间隔限制
    RICHOX_ERRORCODE_MISSION_DAILY_BONUS         = -11, //超出当日任务奖励限额
    RICHOX_ERRORCODE_MISSION_BONUS_MAX           = -12, //超出任务单次奖励限制
    RICHOX_ERRORCODE_MULTIPLY_TWICE              = -13, //已经翻倍过
    RICHOX_ERRORCODE_MULTIPLY_TIMEOUT            = -14, //已过可翻倍时间
    RICHOX_ERRORCODE_MULTIPLY_UNSUPPORTED        = -15, //任务不支持翻倍
    RICHOX_ERRORCODE_MULTIPLY_TOO_BIG            = -16, //翻倍倍数过大
    RICHOX_ERRORCODE_MULTIPLY_ZERO_BONUS         = -17, //奖励为0不可翻倍
    RICHOX_ERRORCODE_WECHAT_ALREADY_BOUND        = -18, //此微信已绑定过其他账号
    RICHOX_ERRORCODE_USER_BOUND_OTHER_WECHAT     = -19, //此用户已经绑定过其他微信账号
    RICHOX_ERRORCODE_UNSUPPORTED_SNS_TYPE        = -20, //暂不支持绑定此类社交账户
    RICHOX_ERRORCODE_CLIENT_OUTDATED             = -21, //请升级到最新版本
    RICHOX_ERRORCODE_INSUFFICIENT_COIN           = -22, //金币不足
    RICHOX_ERRORCODE_INSUFFICIENT_CASH           = -23, //现金不足
    
    RICHOX_ERRORCODE_ACCESS_FACEBOOK_FAILED      = -24, //获取facebook用户信息失败
    RICHOX_ERRORCODE_FACEBOOK_ALREADY_BOUND      = -25, //此facebook账号已绑定其他用户
    RICHOX_ERRORCODE_USER_BOUND_OTHER_FACEBOOK   = -26, //此用户已经绑定其他facebook账号
    RICHOX_ERRORCODE_ACCESS_GOOGLE_FAILED        = -27, //获取google用户信息失败
    RICHOX_ERRORCODE_GOOGLE_ALREADY_BOUND        = -28, //此google账号已绑定其他用户
    RICHOX_ERRORCODE_USER_BOUND_OTHER_GOOGLE     = -29, //此用户已经绑定其他google账号
    
    RICHOX_ERRORCODE_INVITEE_OUTDATED_BY_TIME    = -30, //您已经是老用户啦，无法被邀请
    RICHOX_ERRORCODE_INVITEE_OUTDATED_BY_COIN    = -31, //您已经是老用户啦，无法被邀请
    RICHOX_ERRORCODE_INVITEE_NO_WECHAT           = -32, //请先绑定微信
    RICHOX_ERRORCODE_INVITEE_ALREADY_INVITED     = -33, //您已被邀请过了
    RICHOX_ERRORCODE_INVITATION_CODE_INVALID     = -34, //无效的邀请码
    RICHOX_ERRORCODE_INVITATION_SELF             = -35, //不能邀请自己
    RICHOX_ERRORCODE_INVITATION_OVER_LIMIT       = -36, //邀请者当日邀请数量超出限制
    RICHOX_ERRORCODE_INVITER_NO_WECHAT           = -37, //邀请者需先绑定微信
    RICHOX_ERRORCODE_INVITEE_OUTDATED_BY_INVITATION      = -38, //您已经是老用户啦，无法被邀请
    
    RICHOX_ERRORCODE_ACTIVITY_NOT_EXISTS                        = -50, //活动不存在
    RICHOX_ERRORCODE_ACTIVITY_NOT_STARTED                       = -51, //活动未开始
    RICHOX_ERRORCODE_ACTIVITY_ENDED                             = -52, //活动已结束
    RICHOX_ERRORCODE_ACTIVITY_DRAW_NO_CHANCE                    = -53, //抽奖机会已用完
    RICHOX_ERRORCODE_ACTIVITY_DRAW_NOT_STARTED                  = -54, //未到抽奖时间
    RICHOX_ERRORCODE_ACTIVITY_DRAW_ENDED                        = -55, //抽奖时间已过
    RICHOX_ERRORCODE_ACTIVITY_DRAW_OVER_DAILY_COUNT_LIMIT       = -56, //您今天已经抽奖太多次了
    RICHOX_ERRORCODE_ACTIVITY_DRAW_OVER_TOTAL_COUNT_LIMIT       = -57, //你已经抽奖太多次了
    RICHOX_ERRORCODE_ACTIVITY_WITHDRAW_NOT_STARTED              = -58, //未到提现时间
    RICHOX_ERRORCODE_ACTIVITY_WITHDRAW_ENDED                    = -59, //提现时间已过
    RICHOX_ERRORCODE_ACTIVITY_WITHDRAW_INSUFFICIENT_CASH        = -60, //余额不足
    RICHOX_ERRORCODE_ACTIVITY_WITHDRAW_OVER_TOTAL_COUNT_LIMIT   = -61, //提现次数已用完
    RICHOX_ERRORCODE_ACTIVITY_WITHDRAW_OVER_DAILY_COUNT_LIMIT   = -62, //今日已提现过
    RICHOX_ERRORCODE_ACTIVITY_WITHDRAW_TOO_FREQUENT             = -63, //操作太频繁
    RICHOX_ERRORCODE_ACTIVITY_WITHDRAW_INVALID_CASH             = -64, //账户余额无效
    RICHOX_ERRORCODE_ACTIVITY_WITHDRAW_LIMIT                    = -65, //活动提现额度已用完
    RICHOX_ERRORCODE_ACTIVITY_GIFT_NOT_STARTED                  = -66, //未到兑奖时间
    RICHOX_ERRORCODE_ACTIVITY_GIFT_ENDED                        = -67, //兑奖时间已过
    RICHOX_ERRORCODE_ACTIVITY_GIFT_OVER_LIMIT                   = -68, //兑奖次数已用完
    RICHOX_ERRORCODE_ACTIVITY_EXCHANGE_NOT_STARTED              = -69, //未到积分兑换时间
    RICHOX_ERRORCODE_ACTIVITY_EXCHANGE_ENDED                    = -70, //积分兑换时间已过
    RICHOX_ERRORCODE_ACTIVITY_EXCHANGE_INSUFFICIENT_COIN        = -71, //积分不足
    RICHOX_ERRORCODE_ACTIVITY_GIFT_LIMIT                        = -72, //活动奖品已领完
    RICHOX_ERRORCODE_ACTIVITY_MISMATCH_COIN_CONDITION           = -73, //不满足活动金币条件
    
    RICHOX_ERRORCODE_CARD_EXCEED_DAILY_LIMIT                    = -80, //此卡片今天已刮完
    RICHOX_ERRORCODE_CARD_EXCEED_EXTRA_CHANCES                  = -81, //今日立即冷却机会已用完
    RICHOX_ERRORCODE_CARD_NOT_REQUESTED                         = -82, //卡片未领取
    RICHOX_ERRORCODE_CARD_NOT_EXISTS                            = -83, //卡片不存在
    RICHOX_ERRORCODE_CARD_COOLING_DOWN                          = -84, //卡片正在冷却中
    RICHOX_ERRORCODE_CARD_ALREADY_OPENED                        = -85, //卡片重复刮开
    
    RICHOX_ERRORCODE_ACCESS_APPLE_FAILED                        = -87, //获取apple用户信息失败
    RICHOX_ERRORCODE_APPLE_ALREADY_BOUND                        = -88, //此apple账号已绑定其他用户
    RICHOX_ERRORCODE_USER_BOUND_OTHER_APPLE                     = -89, //此用户已经绑定其他apple账号
    
    RICHOX_ERRORCODE_DUIBA_OFF                                  = -100, //兑吧活动功能未开启
    RICHOX_ERRORCODE_DUIBA_ADD_TIMES                            = -101, //兑吧增加抽奖次数失败
    
    RICHOX_ERRORCODE_WITHDRAW_ID_CARD_ABNORMAL                  = -200, //用户身份信息异常,已用于其他设备提现
    RICHOX_ERRORCODE_WITHDRAW_TOO_MANY_REQUESTS_TODAY           = -201, //今日提现次数过多，请明日再试
    RICHOX_ERRORCODE_WITHDRAW_EXCEED_MISSION_LIMIT              = -202, //当前提现任务次数超出限制
    RICHOX_ERRORCODE_WITHDRAW_EXCEED_MISSION_GLOBAL_LIMIT       = -203, //当前提现任务总次数超出限制
    
    RICHOX_ERRORCODE_TICKET_NOT_EXISTS                          = -301, //优惠券不存在
    RICHOX_ERRORCODE_TICKET_NOT_STARTED                         = -302, //优惠券未到使用时间
    RICHOX_ERRORCODE_TICKET_EXPIRED                             = -303, //优惠券已过期
    RICHOX_ERRORCODE_TICKET_NO_STOCK                            = -304, //优惠券库存不足
    RICHOX_ERRORCODE_TICKET_WITHDRAW_FAILED                     = -305, //提现券使用失败
    RICHOX_ERRORCODE_TICKET_MISMATCH_INVITE_CONDITION           = -306, //不满足邀请人数条件
    
    RICHOX_ERRORCODE_FOREIGN_GIFT_CARD_NO_STOCK                 = -400, //礼品卡库存不足
    RICHOX_ERRORCODE_FOREIGN_GIFT_CARD_NOT_EXISTS               = -401, //礼品卡不存在
    RICHOX_ERRORCODE_FOREIGN_SNS_ACCOUNT_NOT_EXISTS             = -402, //用户未绑定社交账号
    RICHOX_ERRORCODE_EXCHANGE_EXCEED_GIFT_LIMIT                 = -403, //当前礼品卡兑换次数超出限制
    RICHOX_ERRORCODE_EXCHANGE_EXCEED_GIFT_GLOBAL_LIMIT          = -404, //当前礼品卡兑换总次数超出限制
    
    RICHOX_ERRORCODE_SIGN_IN_NOT_TODAY                          = -500, //仅支持当天签到
    RICHOX_ERRORCODE_SIGN_IN_WITHDRAW_DISABLED                  = -501, //签到提现已关闭
    RICHOX_ERRORCODE_SIGN_IN_WITHDRAW_INSUFFICIENT_COIN         = -502, //金币不足
    RICHOX_ERRORCODE_SIGN_IN_WITHDRAW_VERSION_TOO_LOW           = -503, //版本不兼容
    RICHOX_ERRORCODE_SIGN_IN_WITHDRAW_NOT_ENOUGH_DAYS           = -505, //未达到连续签到天数
    RICHOX_ERRORCODE_SIGN_IN_WITHDRAW_EXCEED_LIMIT              = -506, //签到提现次数过多
    RICHOX_ERRORCODE_SIGN_IN_ADDITIONAL_EXCEED_RANGE            = -507, //不在有效的补签天数范围内
    RICHOX_ERRORCODE_SIGN_IN_ADDITIONAL_EXCEED_LIMIT            = -508, //今日补签次数过多
    
    RICHOX_ERRORCODE_RED_PACKET_NOT_TODAY                       = -601, //仅能领取当天奖励
    RICHOX_ERRORCODE_RED_PACKET_CONFIG_NOT_EXISTS               = -602, //红包活动不存在
    RICHOX_ERRORCODE_RED_PACKET_EVENT_NOT_EXISTS                = -603, //事件不存在
    RICHOX_ERRORCODE_RED_PACKET_NO_USER                         = -604, //用户不存在
    RICHOX_ERRORCODE_RED_PACKET_USER_RECORD_NOT_EXISTS          = -605, //用户记录不存在
    RICHOX_ERRORCODE_RED_PACKET_ALREADY_DRAWN                   = -606, //今日已领取过
    RICHOX_ERRORCODE_RED_PACKET_EVENT_OVER_DAILY_LIMIT          = -607, //超出当日次数限制
    
    RICHOX_ERRORCODE_RANKING_LIST_NOT_EXISTS                    = -610, //排行榜不存在
    RICHOX_ERRORCODE_DEVICE_ID_IS_CANCELED                      = -611, //设备ID已注销
    RICHOX_ERRORCODE_DID_DEVICE_ID_UNSUITED                     = -612, //用户设备与did不一致
    
    RICHOX_ERRORCODE_LADDER_NOT_EXISTS                          = -620, //阶梯方案不存在
    RICHOX_ERRORCODE_LADDER_PACKET_CONF_NOT_EXISTS              = -621, //阶梯红包配置不存在
    RICHOX_ERRORCODE_LADDER_PACKET_NOT_EXISTS                   = -622, //阶梯红包不存在
    RICHOX_ERRORCODE_LADDER_PACKET_INVALID_CHECKSUM             = -623, //无效的checksum
    RICHOX_ERRORCODE_LADDER_MISSION_LIMIT                       = -624, //阶梯任务次数限制
    RICHOX_ERRORCODE_LADDER_MISSION_FINISHED                    = -625, //阶梯任务已完成
    RICHOX_ERRORCODE_LADDER_PRE_PACKET_NOT_WITHDRAW             = -626, //前置阶梯红包未完成提现
    RICHOX_ERRORCODE_LADDER_MISSION_NOT_FOUND                   = -627, //阶梯任务不存在
    RICHOX_ERRORCODE_LADDER_PACKET_PROGRESS_ABNORMAL            = -628, //用户进度异常
    RICHOX_ERRORCODE_LADDER_PACKET_PROGRESS_NOT_FINISH          = -629, //用户进度未满, 无法提现
    RICHOX_ERRORCODE_LADDER_PACKET_LOCKED                       = -630, //用户红包未解锁, 无法提现
};

typedef void (^RichOXFailureBlock)(NSError *error);
typedef void (^RichOXCommonSuccessBlock)(void);


@interface RichOXError : NSObject

+ (NSError *)createError: (NSInteger)code message: (NSString * _Nullable)message;

@end

NS_ASSUME_NONNULL_END
